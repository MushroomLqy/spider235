Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.getPrivacyPolicyInfo = getPrivacyPolicyInfo;

var _http = require("../utils/http");

/* ------------------------------------ */ function getPrivacyPolicyInfo() {
    return (0, _http.get)("PRIVACY_POLICY");
}