Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.getAbTest = getAbTest;

exports.collectFormId = collectFormId;

exports.getMineInfo = getMineInfo;

exports.editMineInfo = editMineInfo;

exports.getQrCode = getQrCode;

exports.postRecord = postRecord;

exports.getShareCode = getShareCode;

var _http = require("../utils/http");

function getAbTest(params) {
    return (0, _http.get)("AB_TEST", {
        params: params
    });
}

function collectFormId() {
    return new Promise(function(resolve) {
        resolve();
    });
}

function getMineInfo() {
    return (0, _http.get)("MINE_INFO_DETAIL");
}

function editMineInfo() {
    var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var key = options.key, value = options.value;
    return (0, _http.post)("EDIT_MINE_INFO", {
        key: key,
        value: value
    }, {
        transform: true,
        header: {
            "Content-Type": "application/x-www-form-urlencoded"
        }
    });
}

function getQrCode() {
    var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0, _http.get)("GER_MP_QRCODE_URL", {
        params: options,
        transform: true
    });
}

function postRecord() {
    var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0, _http.post)("RECORD_PLATFORM_SOURCE", options, {});
}

function getShareCode() {
    var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0, _http.post)("GET_SHARE_CODE", options, {});
}