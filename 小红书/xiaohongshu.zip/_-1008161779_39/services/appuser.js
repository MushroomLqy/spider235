Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.mapPage = exports.DEFAULT_DATA = undefined;

exports.getSearchFromKeyword = getSearchFromKeyword;

exports.followUser = followUser;

exports.unfollowUser = unfollowUser;

exports.getFollowings = getFollowings;

exports.getFollowers = getFollowers;

exports.triggerFollow = triggerFollow;

var _http = require("../utils/http");

var _api = require("../utils/api");

var _api2 = _interopRequireDefault(_api);

var _page = require("../utils/page");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

var DEFAULT_META = {};

var DEFAULT_DATA = exports.DEFAULT_DATA = Object.assign({}, DEFAULT_META, {
    users: []
});

var mapPage = exports.mapPage = function mapPage() {
    var oldList = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var newList = arguments[1];
    var _ref = arguments[2];
    var page = _ref.page, pageSize = _ref.pageSize;
    var _commonMapPage = (0, _page.mapPage)(oldList.users, newList.users, {
        page: page,
        pageSize: pageSize
    }), list = _commonMapPage.list, pagination = _commonMapPage.pagination;
    return {
        users: list,
        pagination: pagination
    };
};

function getSearchFromKeyword(_ref2) {
    var keyword = _ref2.keyword, pagination = _ref2.pagination;
    return (0, _http.get)("SEARCH_USERS_FROM_KEYWORD", {
        params: {
            keyword: keyword,
            page: pagination.page,
            pageSize: pagination.pageSize
        }
    });
}

function followUser(_ref3) {
    var userId = _ref3.userId;
    return (0, _http.post)("FOLLOW", {}, {
        resourceParams: {
            userId: userId
        }
    });
}

function unfollowUser(_ref4) {
    var userId = _ref4.userId;
    return (0, _http.post)("UNFOLLOW", {}, {
        resourceParams: {
            userId: userId
        }
    });
}

function getFollowings(_ref5) {
    var userId = _ref5.userId, _ref5$start = _ref5.start, start = _ref5$start === undefined ? "" : _ref5$start;
    return (0, _http.get)("SNS_USER_FOLLOWINGS", {
        resourceParams: {
            id: userId
        },
        params: {
            start: start
        },
        transform: true
    });
}

function getFollowers(_ref6) {
    var userId = _ref6.userId, _ref6$start = _ref6.start, start = _ref6$start === undefined ? "" : _ref6$start;
    return (0, _http.get)("SNS_USER_FOLLOWERS", {
        resourceParams: {
            id: userId
        },
        params: {
            start: start
        },
        transform: true
    });
}

function triggerFollow() {
    var item = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var isFollow = false;
    if (item && item.hasOwnProperty("followed") && !item.followed) {
        isFollow = true;
    }
    if (item && !item.hasOwnProperty("followed") && [ "follows", "both" ].indexOf(item.fstatus) === -1) {
        isFollow = true;
    }
    return new Promise(function(resolve, reject) {
        if (isFollow) {
            followUser({
                userId: item.userid || item.id
            }).then(function() {
                if (item.hasOwnProperty("followed")) {
                    item.followed = true;
                } else {
                    item.fstatus = "follows";
                }
                resolve(item);
            }).catch(function() {
                reject();
            });
        } else {
            _api2.default.showModal({
                title: "是否取消关注",
                confirmText: "确认",
                cancelText: "取消",
                success: function success(data) {
                    if (data.confirm) {
                        unfollowUser({
                            userId: item.userid || item.id
                        }).then(function() {
                            if (item.hasOwnProperty("followed")) {
                                item.followed = false;
                            } else {
                                item.fstatus = "none";
                            }
                            resolve(item);
                        }).catch(function() {
                            reject();
                        });
                    }
                }
            });
        }
    });
}