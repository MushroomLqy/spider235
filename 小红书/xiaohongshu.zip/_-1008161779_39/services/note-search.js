Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.getHotSearch = getHotSearch;

exports.getSearchRecommend = getSearchRecommend;

exports.getNotesPlaceholder = getNotesPlaceholder;

exports.hasValue = hasValue;

exports.removeEleBaseIndex = removeEleBaseIndex;

var _http = require("../utils/http");

var parseHotSearch = function parseHotSearch(data) {
    var tempData = data || [];
    // data.map(item => {
    //   if (item.type === 'normal') {
    //     tempData.push({
    //       name: item.title
    //     })
    //   }
    // })
        return tempData;
};

var parsePlaceholderSearch = function parsePlaceholderSearch(data) {
    var pages = getCurrentPages();
    //eslint-disable-line
    // console.log('><><<<<<<<<<<<??>><>', pages[pages.length - 1].route)
        if (pages[pages.length - 1].route === "pages/main/home/index") {
        return data.home;
    } else if (pages[pages.length - 1].route === "pages/main/store/index") {
        // console.log('>>>>>>>>>>>>>>store', data.store)
        return data.store;
    }
};

function getHotSearch() {
    return (0, _http.get)("NOTES_HOT_SEARCH", {
        transform: true
    }).then(parseHotSearch);
}

var parseRecommendNotes = function parseRecommendNotes(data) {
    return data.map(function(item) {
        return {
            name: item.text,
            description: item.desc,
            searchType: item.searchType
        };
    });
};

function getSearchRecommend(_ref) {
    var keyword = _ref.keyword;
    return (0, _http.get)("SEARCH_NOTES_AUTO_COMPLETE", {
        transform: true,
        params: {
            keyword: keyword
        }
    }).then(parseRecommendNotes);
}

function getNotesPlaceholder(_ref2) {
    var openid = _ref2.openid;
    return (0, _http.get)("SEARCH_NOTES_PLACEHOLDER", {
        transform: true,
        params: {
            openid: openid
        }
    }).then(parsePlaceholderSearch);
}

function hasValue(value) {
    var flag = false;
    var indx = -1;
    this.data.historys.forEach(function(history, index) {
        if (history.name === value) {
            flag = true;
            indx = index;
        }
    });
    return {
        flag: flag,
        index: indx
    };
}

function removeEleBaseIndex(index) {
    if (index > -1) {
        this.data.historys.splice(index, 1);
    }
}