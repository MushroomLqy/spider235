Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.getJumpPageUrl = getJumpPageUrl;

exports.getAdsQrCodeUrl = getAdsQrCodeUrl;

var _http = require("../utils/http");

function getJumpPageUrl(_ref) {
    var pathId = _ref.pathId;
    return (0, _http.get)("QR_LINK", {
        transform: true,
        params: {
            pathId: pathId
        }
    });
}

function getAdsQrCodeUrl() {
    return (0, _http.get)("ADS_QR_LINK", {
        transform: true
    });
}