Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.postVideoPacket = postVideoPacket;

exports.checkRedPacket = checkRedPacket;

exports.postBrandPacket = postBrandPacket;

exports.getBrandPacketPrepare = getBrandPacketPrepare;

exports.followBrandUser = followBrandUser;

var _http = require("../utils/http");

/* ------------------------------------ */ function postVideoPacket(noteId) {
    return (0, _http.post)("VIDEO_PACKET_OPEN", {
        noteId: noteId
    }, {
        transform: true,
        params: {
            noteId: noteId
        }
    });
    // return Promise.resolve({
    //   type: 'coupon',
    //   cash: '2.30',
    //   coupon: {
    //     amount: '20',
    //     type: 0,
    //     trail: true,
    //     expire: '11月12日 09:59',
    //     shopName: '有光2',
    //   },
    //   wish: '才貌双全buff 你看行不行',
    //   card: 'slim'
    // })
    // // 现金
    // return Promise.resolve({
    //   type: 'cash',
    //   cash: {
    //     amount: '2.3'
    //   },
    //   coupon: {
    //     amount: '20',
    //     type: '店铺券',
    //     trail: true,
    //     expire: '11月12日 09:59',
    //     shopName: '有光',
    //   },
    //   wish: '才貌双全buff 你看行不行',
    //   card: 'slim'
    // })
    // // 体验卡
    // return Promise.resolve({
    //   type: 'red_card',
    //   cash: '2.30',
    //   coupon: {
    //     amount: '20',
    //     type: '店铺券',
    //     trail: true,
    //     expire: '11月12日 09:59',
    //     shopName: '有光',
    //   },
    //   wish: '才貌双全buff 你看行不行',
    //   card: 'slim'
    // })
    // // 祝福语
    // return Promise.resolve({
    //   type: 'wish',
    //   cash: '2.30',
    //   coupon: {
    //     amount: '20',
    //     type: '店铺券',
    //     trail: true,
    //     expire: '11月12日 09:59',
    //     shopName: '有光',
    //   },
    //   wish: '才貌双全buff 你看行不行',
    //   card: 'slim'
    // })
    // // 已玩过
    // return Promise.resolve({
    //   type: 'done',
    //   cash: '2.30',
    //   coupon: {
    //     amount: '20',
    //     type: '店铺券',
    //     trail: true,
    //     expire: '11月12日 09:59',
    //     shopName: '有光',
    //   },
    //   wish: '才貌双全buff 你看行不行',
    //   card: 'slim'
    // })
}

/* eslint camelcase: false */ function checkRedPacket(noteId) {
    return (0, _http.get)("VIDEO_PACKET_CHECK_RED_PACKET", {
        transform: true,
        params: {
            noteId: noteId
        },
        resourceParams: {
            noteId: noteId
        }
    });
    // return Promise.resolve({
    //   hasRedPacket: true,
    //   redPacketType: 'normal'
    // })
}

function postBrandPacket(noteId, brandId, brandUserId) {
    return (0, _http.post)("BRAND_PACKET_OPEN", {
        noteId: noteId,
        brandId: brandId,
        brandUserId: brandUserId
    }, {
        transform: true,
        params: {
            noteId: noteId,
            brandId: brandId,
            brandUserId: brandUserId
        }
    });
}

function getBrandPacketPrepare(noteId, redPacketType) {
    return (0, _http.get)("BRAND_PACKET_PREPARE", {
        transform: true,
        params: {
            noteId: noteId,
            redPacketType: redPacketType
        }
    });
}

function followBrandUser(userId) {
    return (0, _http.post)("BRAND_PACKET_FOLLOW", {
        userId: userId
    }, {
        transform: true,
        params: {
            userId: userId
        }
    });
}