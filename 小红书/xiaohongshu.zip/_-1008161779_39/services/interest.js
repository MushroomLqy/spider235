Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.getTags = getTags;

exports.likeTags = likeTags;

var _http = require("../utils/http");

var _enum = require("../utils/enum");

var _parseUrl = require("../utils/parse-url");

/* ------------------------------------ */ function getTags() {
    return (0, _http.get)("INTEREST_TAGS", {
        transform: true
    });
}

/* eslint camelcase: false */ function likeTags(tags) {
    return (0, _http.post)("INTEREST_TAGS", {
        tags: tags
    }, {
        transform: true
    });
}