Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.sendVertifyCode = sendVertifyCode;

exports.initGeeTest = initGeeTest;

var _http = require("../utils/http");

/* ------------------------------------ */ function sendVertifyCode(postData) {
    return (0, _http.post)("VERTIFICATION_CODE", postData, {
        params: {}
    });
}

function initGeeTest() {
    return (0, _http.post)("INIT_GEETEST");
}