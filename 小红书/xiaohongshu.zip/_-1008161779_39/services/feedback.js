Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.sendFeedback = sendFeedback;

exports.getUploadToken = getUploadToken;

var _http = require("../utils/http");

/* ------------------------------------ */ function sendFeedback(_ref) {
    var sid = _ref.sid, content = _ref.content, type = _ref.type, deviceinfo = _ref.deviceinfo, imageList = _ref.imageList;
    return (0, _http.post)("FEEDBACK", {
        content: content,
        type: type,
        deviceinfo: deviceinfo,
        imageList: imageList,
        sid: sid
    }, {
        transform: true
    });
}

function getUploadToken() {
    return (0, _http.get)("CI_TOKEN", {
        extractData: false
    });
}