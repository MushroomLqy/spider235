Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.getGoodsShareInfo = getGoodsShareInfo;

var _http = require("../utils/http");

// 获取商品分享信息
function getGoodsShareInfo(goodsId) {
    return (0, _http.get)("GOODS_SHARE", {
        transform: false,
        params: {
            goods_id: goodsId
        }
    });
}