Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.createData = exports.mapPage = exports.DEFAULT_DATA = undefined;

exports.filterGoods = filterGoods;

exports.getSearchFromKeyword = getSearchFromKeyword;

var _http = require("../utils/http");

var _parseUrl = require("../utils/parse-url");

var _page = require("../utils/page");

var _string = require("../utils/string");

var DEFAULT_META = {};

var DEFAULT_DATA = exports.DEFAULT_DATA = Object.assign({}, DEFAULT_META, {
    goods: []
});

var parseSearchFromKeyword = function parseSearchFromKeyword(data) {
    var items = data.items.slice();
    var goods = [];
    items.forEach(function(item) {
        // if (/立减/.test(item.promotionText)) {
        //   return
        // }
        var promotionTag = item.promotionText ? [ {
            name: item.promotionText
        } ] : [];
        goods.push({
            id: item.id,
            image: (0, _parseUrl.transUriToSafe)(item.image),
            title: item.title,
            desc: item.desc,
            discountPrice: item.discountPrice,
            price: item.price,
            vendorIcon: (0, _parseUrl.transUriToSafe)(item.vendorIcon),
            newArriving: item.newArriving || false,
            promotionTag: promotionTag,
            promotionText: item.promotionText
        });
    });
    return {
        totalCount: data.totalCount,
        goods: goods
    };
};

function filterGoods(goods) {
    var items = goods.slice();
    var output = [];
    items.forEach(function(item) {
        if (/立减/.test(item.promotionText) || /选/.test(item.promotionText)) {
            return;
        }
        output.push(item);
    });
    return output;
}

function getSearchFromKeyword(_ref) {
    var keyword = _ref.keyword, pagination = _ref.pagination;
    return (0, _http.get)("SEARCH_FROM_KEYWORD", {
        transform: true,
        params: {
            keyword: keyword,
            page: pagination.page,
            perPage: pagination.pageSize
        }
    }).then(parseSearchFromKeyword);
}

var mapPage = exports.mapPage = function mapPage() {
    var oldGoodsList = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var newGoodsList = arguments[1];
    var _ref2 = arguments[2];
    var page = _ref2.page, pageSize = _ref2.pageSize, homeFeeds = _ref2.homeFeeds;
    var _commonMapPage = (0, _page.mapPage)(oldGoodsList.goods, newGoodsList.goods, {
        page: page,
        pageSize: pageSize,
        homeFeeds: homeFeeds
    }), list = _commonMapPage.list, pagination = _commonMapPage.pagination;
    return Object.assign({}, newGoodsList, {
        goods: list,
        pagination: pagination
    });
};

var createData = exports.createData = function createData(goods) {
    var meta = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    if (!goods) {
        console.error("[goods-list] could not found goods array");
        // eslint-disable-line
        }
    var escapedNotes = goods.map(function(goodsItem) {
        return Object.assign(goodsItem, {
            title: (0, _string.escapeNoteString)(goodsItem.title),
            desc: (0, _string.escapeNoteString)(goodsItem.desc)
        });
    });
    var data = Object.assign({}, DEFAULT_DATA, meta, {
        goods: escapedNotes
    });
    return data;
};