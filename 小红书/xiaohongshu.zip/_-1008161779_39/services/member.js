Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.fetchMemberInfo = fetchMemberInfo;

exports.fetchMemberCheckout = fetchMemberCheckout;

exports.fetchMemberOrderId = fetchMemberOrderId;

exports.fetchMemberInvitation = fetchMemberInvitation;

exports.joinMemberInvitation = joinMemberInvitation;

exports.fetchPopups = fetchPopups;

exports.fetchMemberGoodsIds = fetchMemberGoodsIds;

var _http = require("../utils/http");

var _user = require("../utils/user");

var _user2 = _interopRequireDefault(_user);

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

function fetchMemberInfo() {
    return (0, _http.get)("MEMBER_INFO", {
        transform: {
            separateNumber: true
        }
    });
}

function fetchMemberCheckout() {
    return (0, _http.get)("MEMBER_ORDER_CHECKOUT", {
        transform: {
            separateNumber: true
        },
        params: {}
    });
}

function fetchMemberOrderId(type) {
    var renew = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
    var promotionId = arguments[2];
    var _userUtil$getUserInfo = _user2.default.getUserInfo(), openid = _userUtil$getUserInfo.openid;
    // eslint-disable-line
        var WEIXIN_PAYMENT_TYPE = 2;
    return (0, _http.post)("MEMBER_ORDER_CREATE", {
        openid: openid,
        type: type,
        renew: renew ? 1 : 0,
        promotionId: promotionId,
        paymentType: WEIXIN_PAYMENT_TYPE,
        // 自动续费类型是微信
        clientSource: "WXAPP_STORE"
    }, {
        transform: {
            separateNumber: true
        }
    });
}

function fetchMemberInvitation(_ref) {
    var invitationId = _ref.invitationId;
    // const { sid, openid } = wx.getStorageSync('user_info') // eslint-disable-line
        return (0, _http.get)("REVIEW_MEMBER_INVITATION", {
        transform: true,
        params: {
            invitationId: invitationId
        }
    });
}

function joinMemberInvitation(_ref2) {
    var invitationId = _ref2.invitationId;
    return (0, _http.post)("JOIN_MEMBER_INVITATION", {
        invitationId: invitationId
    }, {
        transform: true
    });
}

function fetchPopups() {
    return (0, _http.get)("MEMBER_EVENT_POPUPS");
}

function fetchMemberGoodsIds() {
    return (0, _http.get)("MEMBER_GOODS_IDS");
}