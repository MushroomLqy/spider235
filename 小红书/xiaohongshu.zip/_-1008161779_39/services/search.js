Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.search = exports.searchAuto = exports.TRENDING_TYPE = undefined;

var _regenerator = require("./../karin_npm/babel-runtime/regenerator/index.js");

var _regenerator2 = _interopRequireDefault(_regenerator);

var searchAuto = exports.searchAuto = function() {
    var _ref2 = _asyncToGenerator(/* */ _regenerator2.default.mark(function _callee() {
        var _ref3 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {}, _ref3$keyword = _ref3.keyword, keyword = _ref3$keyword === undefined ? "" : _ref3$keyword, _ref3$num = _ref3.num, num = _ref3$num === undefined ? 3 : _ref3$num;
        return _regenerator2.default.wrap(function _callee$(_context) {
            while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    if (keyword) {
                        _context.next = 2;
                        break;
                    }
                    return _context.abrupt("return", new Error("must provide keyword to searchAuto"));

                  case 2:
                    return _context.abrupt("return", (0, _http.get)("SEARCH", {
                        params: {
                            keyword: keyword,
                            page: 1,
                            page_size: num
                        }
                    }).then(parseSearchResult));

                  case 3:
                  case "end":
                    return _context.stop();
                }
            }
        }, _callee, this);
    }));
    return function searchAuto() {
        return _ref2.apply(this, arguments);
    };
}();

var search = exports.search = function() {
    var _ref4 = _asyncToGenerator(/* */ _regenerator2.default.mark(function _callee2(_ref5) {
        var keyword = _ref5.keyword, type = _ref5.type, _ref5$pagination = _ref5.pagination, pagination = _ref5$pagination === undefined ? _page.DEFAULT_PAGINATION_ARGS : _ref5$pagination;
        return _regenerator2.default.wrap(function _callee2$(_context2) {
            while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    if (keyword) {
                        _context2.next = 2;
                        break;
                    }
                    return _context2.abrupt("return", new Error("must provide keyword to searchFull"));

                  case 2:
                    return _context2.abrupt("return", (0, _http.get)("SEARCH", {
                        params: {
                            keyword: keyword,
                            type: type,
                            /* must be one of TRENDING_TYPE */ page: pagination.page,
                            page_size: pagination.pageSize
                        }
                    }).then(parseSearchResult));

                  case 3:
                  case "end":
                    return _context2.stop();
                }
            }
        }, _callee2, this);
    }));
    return function search(_x3) {
        return _ref4.apply(this, arguments);
    };
}();

exports.getHot = getHot;

var _http = require("../utils/http");

var _page = require("../utils/page");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

function _asyncToGenerator(fn) {
    return function() {
        var gen = fn.apply(this, arguments);
        return new Promise(function(resolve, reject) {
            function step(key, arg) {
                try {
                    var info = gen[key](arg);
                    var value = info.value;
                } catch (error) {
                    reject(error);
                    return;
                }
                if (info.done) {
                    resolve(value);
                } else {
                    return Promise.resolve(value).then(function(value) {
                        step("next", value);
                    }, function(err) {
                        step("throw", err);
                    });
                }
            }
            return step("next");
        });
    };
}

/* ------------------------------------ */ var TRENDING_TYPE = exports.TRENDING_TYPE = {
    SEARCH: "search_trending",
    GOODS: "goods_trending"
    /* ------------------------------------ */};

var searchResultKeyMap = {
    trending_data: "searchTrending",
    /* legacy prop*/ search_trending: "searchTrending",
    goods_trending: "goodsTrending"
};

var parseSearchResult = function parseSearchResult(data) {
    var parsedData = {};
    Object.keys(data).forEach(function(key) {
        var propKey = key;
        if (searchResultKeyMap[key]) {
            propKey = searchResultKeyMap[key];
        }
        parsedData[propKey] = data[key];
    });
    return parsedData;
};

/* ------------------------------------ */ function getHot() {
    var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {}, _ref$num = _ref.num, num = _ref$num === undefined ? 4 : _ref$num;
    return (0, _http.get)("HOT", {
        params: {
            num: num
        }
    }).then(parseSearchResult);
}