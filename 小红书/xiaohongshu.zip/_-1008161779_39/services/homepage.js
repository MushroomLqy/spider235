Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.getHomeFeeds = getHomeFeeds;

exports.getHomeFeedsCategories = getHomeFeedsCategories;

exports.getDefaultCategories = getDefaultCategories;

exports.getHomeFeedsCategoriesWithoutSid = getHomeFeedsCategoriesWithoutSid;

exports.getHomeFeedsWithoutSid = getHomeFeedsWithoutSid;

exports.checkIsDefaultCategories = checkIsDefaultCategories;

exports.getActivityBannerSwitch = getActivityBannerSwitch;

exports.getActivityBannerInfo = getActivityBannerInfo;

var _http = require("../utils/http");

function getHomeFeeds() {
    var postData = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0, _http.get)("COMMUNITY_HOMEFEEDS", {
        params: postData
    });
}

function getHomeFeedsCategories() {
    var postData = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0, _http.get)("COMMUNITY_CATEGORIES", {
        params: postData
    });
}

function getDefaultCategories() {
    return [ {
        name: "推荐",
        oid: "recommend"
    }, {
        name: "时尚",
        oid: "fasion"
    }, {
        name: "美妆",
        oid: "cosmetics"
    }, {
        name: "美食",
        oid: "food"
    }, {
        name: "运动",
        oid: "sport"
    }, // {
    //     name: '影音',
    //     oid: 'media'
    // },
    {
        name: "旅行",
        oid: "travel"
    }, {
        name: "居家",
        oid: "home"
    }, {
        name: "母婴",
        oid: "babycare"
    }, {
        name: "读书",
        oid: "books"
    }, {
        name: "数码",
        oid: "digital"
    }, {
        name: "时尚男士",
        oid: "mens_fasion"
    } ];
}

function getHomeFeedsCategoriesWithoutSid() {
    var data = getDefaultCategories();
    return new Promise(function(res) {
        res(data);
    });
}

function getHomeFeedsWithoutSid(_ref) {
    var oid = _ref.oid, page = _ref.page, pageSize = _ref.pageSize;
    return (0, _http.get)("COMMUNITY_HOMEFEEDS", {
        transform: true,
        params: {
            oid: oid,
            page: page,
            pageSize: pageSize
        }
    });
}

function checkIsDefaultCategories() {
    var categories = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
    var defaultCategories = getDefaultCategories();
    if (categories.length === 0 || categories.length !== defaultCategories.length) {
        return false;
    }
    categories.forEach(function(item, index) {
        if (defaultCategories[index] && item.oid !== defaultCategories[index].oid) {
            return false;
        }
    });
    return true;
}

function getActivityBannerSwitch() {
    return (0, _http.get)("INDEX_ACTIVITY_SWITCH", {
        transform: true
    });
}

function getActivityBannerInfo() {
    return (0, _http.get)("ACTIVITY_BANNER_INFO", {
        transform: true
    });
}