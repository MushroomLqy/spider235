Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.getFaved = getFaved;

exports.getAuthorFaved = getAuthorFaved;

var _http = require("../utils/http");

function getFaved(_ref) {
    var _ref$num = _ref.num, num = _ref$num === undefined ? 10 : _ref$num, bottomStart = _ref.bottomStart;
    if (bottomStart) {
        return (0, _http.get)("FAVED", {
            transform: true,
            params: {
                num: num,
                bottomStart: bottomStart
            }
        });
    } else {
        return (0, _http.get)("FAVED", {
            transform: true,
            params: {
                num: num
            }
        });
    }
}

function getAuthorFaved(_ref2) {
    var userId = _ref2.userId, _ref2$num = _ref2.num, num = _ref2$num === undefined ? 10 : _ref2$num, start = _ref2.start;
    return (0, _http.get)("AUTHORFAVED", {
        transform: true,
        params: {
            num: num,
            start: start
        },
        resourceParams: {
            userId: userId
        }
    });
}