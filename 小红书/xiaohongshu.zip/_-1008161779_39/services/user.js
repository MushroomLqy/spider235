Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.updateUserInfo = exports.updateSessionKey = exports.checkAuthorizationValidate = exports.getPhoneZones = exports.becomeRawFriend = exports.becomeFriend = exports.getVerifyCode = exports.WXMobileLogin = exports.telephoneLogin = exports.mobileLogin = exports.logout = exports.postUserInfoToServerAndGetSid = exports.loginWithCode = undefined;

var _http = require("../http.config");

var _http2 = require("../utils/http");

var _api = require("../utils/api");

var _api2 = _interopRequireDefault(_api);

var _feApiSign = require("../utils/fe-api-sign");

var _deepClone = require("../libs/deep-clone");

var _deepClone2 = _interopRequireDefault(_deepClone);

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

var MP_SOURCE = "SELECTED";

var platform = null;

function getPlatform() {
    var platform = _api2.default.getSystemInfoSync().platform;
    return platform === "devtools" ? "ios" : platform;
}

function loginWithCode(code) {
    if (!platform) {
        platform = getPlatform();
    }
    return (0, _http2.post)("LOGIN", {
        code: code,
        // empty code means user declined, but we still need to make session for this user
        platform: platform,
        mp_source: MP_SOURCE
    }, {
        transform: true
    });
}

// 发送授权得到的用户微信信息判断是否注册过APP,注册过直接登录APP返回用户态
function postUserInfoToServerAndGetSid(data) {
    if (!data.platform) {
        data.platform = getPlatform();
    }
    data.mp_source = MP_SOURCE;
    return (0, _http2.post)("USER_INFO", data, {
        transform: true
    });
}

function WXMobileLogin(data) {
    if (!data.platform) {
        data.platform = getPlatform();
    }
    data.mp_source = MP_SOURCE;
    return (0, _http2.post)("WX_MOBILE_LOGIN", data, {
        transform: true
    });
}

// ---------------------------------------------------------------------
function mobileLogin(data) {
    if (!platform) {
        platform = platform = getPlatform();
    }
    data.mp_source = MP_SOURCE;
    data.platform = platform;
    // await getUserInfoAndSetStorage()
        return (0, _http2.post)("MOBILE_LOGIN", data, {
        transform: true
    });
}

function telephoneLogin(data) {
    if (!platform) {
        platform = platform = getPlatform();
    }
    data.platform = platform;
    data.mp_source = MP_SOURCE;
    return (0, _http2.post)("MOBILE_LOGIN", data, {
        transform: true
    });
}

function getVerifyCode(data) {
    if (!platform) {
        platform = platform = getPlatform();
    }
    data.platform = platform;
    return (0, _http2.post)("VFC_CODE", data);
}

function becomeFriend(_ref) {
    var fromUid = _ref.fromUid, toUid = _ref.toUid, sid = _ref.sid;
    return (0, _http2.post)("WX_FRIEND", {
        fromUid: fromUid,
        toUid: toUid
    }, {
        resourceParams: {
            sid: sid
        },
        transform: true
    });
}

function becomeRawFriend(_ref2) {
    var _ref2$fromUnionId = _ref2.fromUnionId, fromUnionId = _ref2$fromUnionId === undefined ? "" : _ref2$fromUnionId, _ref2$fromUserId = _ref2.fromUserId, fromUserId = _ref2$fromUserId === undefined ? "" : _ref2$fromUserId, _ref2$toUnionId = _ref2.toUnionId, toUnionId = _ref2$toUnionId === undefined ? "" : _ref2$toUnionId, _ref2$toUserId = _ref2.toUserId, toUserId = _ref2$toUserId === undefined ? "" : _ref2$toUserId, _ref2$source = _ref2.source, source = _ref2$source === undefined ? "" : _ref2$source;
    return (0, _http2.post)("WX_RAW_FRIEND", {
        fromUnionid: fromUnionId,
        fromUserid: fromUserId,
        toUnionid: toUnionId,
        toUserid: toUserId,
        source: source
    }, {
        transform: true
    });
}

// ----------------------------- //
function logout() {
    return (0, _http2.get)("LOGOUT");
}

function getPhoneZones() {
    return (0, _http2.get)("GET_PHONE_ZONES");
}

function checkAuthorizationValidate(_ref3) {
    var authorization = _ref3.authorization, deviceId = _ref3.deviceId;
    return new Promise(function(resolve, reject) {
        var query = "";
        var header = {
            Authorization: authorization,
            "Device-Fingerprint": deviceId
        };
        var config = {
            url: "" + _http.config.BASE_URL.production + _http.config.API_LIST.CHECK_AUTH_VALIDATE + query,
            header: header,
            success: function success() {
                var res = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
                if (res.statusCode === 200 && res.data) {
                    if (res.data.success) {
                        resolve();
                        return;
                    } else if (res.data.errCode !== undefined && res.data.errCode !== -100) {
                        resolve();
                        return;
                    } else if (res.data.errCode !== undefined && res.data.errCode === -100 && res.data.msg === "该用户未注册") {
                        // auth 未过期 但没注册的用户 可以不执行 login
                        resolve();
                        return;
                    }
                }
                reject();
            },
            fail: function fail() {
                reject();
            }
        };
        var feApiConfig = (0, _deepClone2.default)(config);
        config.header[_feApiSign.DEFAULT_SIGN_HEADER] = (0, _feApiSign.encryptFeApiToken)(feApiConfig);
        wx.request(config);
    });
}

function updateSessionKey() {
    var data = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0, _http2.put)("ACTIVITY_UPDATE_SESSION_KEY", data, {
        resourceParams: {}
    });
}

function updateUserInfo() {
    var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var data = options.data;
    return (0, _http2.put)("ACTIVITY_UPDATE_WEIXIN_INFO", data, {
        resourceParams: {}
    });
}

exports.loginWithCode = loginWithCode;

exports.postUserInfoToServerAndGetSid = postUserInfoToServerAndGetSid;

exports.logout = logout;

exports.mobileLogin = mobileLogin;

exports.telephoneLogin = telephoneLogin;

exports.WXMobileLogin = WXMobileLogin;

exports.getVerifyCode = getVerifyCode;

exports.becomeFriend = becomeFriend;

exports.becomeRawFriend = becomeRawFriend;

exports.getPhoneZones = getPhoneZones;

exports.checkAuthorizationValidate = checkAuthorizationValidate;

exports.updateSessionKey = updateSessionKey;

exports.updateUserInfo = updateUserInfo;