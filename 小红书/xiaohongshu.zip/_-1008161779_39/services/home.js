Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.getHomeFeeds = getHomeFeeds;

exports.checkIfNewUser = checkIfNewUser;

exports.getFulisheCategoryBanner = getFulisheCategoryBanner;

exports.activityBannerEntry = activityBannerEntry;

var _http = require("../utils/http");

var _parseUrl = require("../utils/parse-url");

var parseHomeFeeds = function parseHomeFeeds(data) {
    var goods = [];
    var last = data.length > 0 && data.slice(-1)[0];
    var cursorScore = last && last.cursorScore;
    var hasMore = data.length > 0 || false;
    data.forEach(function(_ref) {
        var type = _ref.type, id = _ref.id, image = _ref.image, link = _ref.link, desc = _ref.desc, title = _ref.title, itemPrice = _ref.itemPrice, newArriving = _ref.newArriving, vendorIcon = _ref.vendorIcon, promotionText = _ref.promotionText;
        if (/立减|选/.test(promotionText)) {
            return;
        }
        var promotionTag = promotionText ? [ {
            name: promotionText
        } ] : [];
        var state = {
            type: type,
            id: id,
            image: (0, _parseUrl.transUriToSafe)(image),
            title: title,
            link: link,
            desc: desc,
            newArriving: newArriving || false,
            vendorIcon: (0, _parseUrl.transUriToSafe)(vendorIcon),
            promotionTag: promotionTag
        };
        itemPrice && Array.isArray(itemPrice) && itemPrice.forEach(function(_ref2) {
            var type = _ref2.type, price = _ref2.price;
            switch (type) {
              case "origin_price":
                state.price = price;
                break;

              case "sale_price":
                state.discountPrice = price;
                break;

              case "member_price":
                state.memberPrice = price;
                break;
            }
        });
        goods.push(state);
    });
    return {
        cursorScore: cursorScore,
        goods: goods,
        hasMore: hasMore
    };
};

function getHomeFeeds(_ref3) {
    var cursorScore = _ref3.cursorScore, categoryid = _ref3.categoryid;
    return (0, _http.get)("HOMEFEEDS", {
        transform: true,
        params: {
            source: "wx",
            cursorScore: cursorScore,
            categoryid: categoryid
        }
    }).then(parseHomeFeeds);
}

function checkIfNewUser(_ref4) {
    var sid = _ref4.sid;
    return (0, _http.get)("CHECK_IF_NEW_USER", {
        transform: true,
        params: {
            source: "wx",
            sid: sid
        }
    });
}

function getFulisheCategoryBanner(_ref5) {
    var tabId = _ref5.tabId;
    var params = {};
    if (tabId) {
        params.tabId = tabId;
    }
    return (0, _http.get)("FULISHE_CATEGORIES_BANNERS", {
        transform: true,
        params: params
    });
}

function activityBannerEntry() {
    return (0, _http.get)("ACTIVITY_BANNER_ENTRY", {
        transform: true
    });
}