Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.getUserInfo = getUserInfo;

exports.getNoteUser = getNoteUser;

exports.getUserOtherNotes = getUserOtherNotes;

exports.getAtTaNote = getAtTaNote;

exports.fetchMemberInfo = fetchMemberInfo;

var _http = require("../utils/http");

function getUserInfo(_ref) {
    var userId = _ref.userId;
    return (0, _http.get)("SNS_USER_INFO", {
        transform: true,
        resourceParams: {
            userId: userId
        }
    });
}

function getNoteUser(_ref2) {
    var userId = _ref2.userId, page = _ref2.page, pageSize = _ref2.pageSize;
    return (0, _http.get)("SNS_NOTE_USER", {
        transform: true,
        params: {
            page: page,
            pageSize: pageSize
        },
        resourceParams: {
            userId: userId
        }
    });
}

function getUserOtherNotes(_ref3) {
    var userId = _ref3.userId, filterNoteIds = _ref3.filterNoteIds;
    return (0, _http.get)("SNS_OTHER_NOTE_USER", {
        params: {
            filterNoteIds: filterNoteIds
        },
        resourceParams: {
            userId: userId
        }
    });
}

function getAtTaNote(_ref4) {
    var userId = _ref4.userId, page = _ref4.page, pageSize = _ref4.pageSize;
    return (0, _http.get)("SNS_ATTA_NOTE", {
        transform: true,
        params: {
            page: page,
            pageSize: pageSize
        },
        resourceParams: {
            userId: userId
        }
    });
}

function fetchMemberInfo() {
    return (0, _http.get)("MEMBER_INFO", {
        transform: {
            separateNumber: true
        }
    });
}