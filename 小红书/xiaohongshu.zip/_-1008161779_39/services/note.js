Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.getVideoNoteFeed = getVideoNoteFeed;

exports.getSingleNote = getSingleNote;

exports.getRelatedNotes = getRelatedNotes;

exports.getRelatedNoteFeed = getRelatedNoteFeed;

exports.likeNote = likeNote;

exports.dislikeNote = dislikeNote;

exports.collectNote = collectNote;

exports.deleteCollectNote = deleteCollectNote;

exports.getNoteImageStickers = getNoteImageStickers;

exports.getNoteDetailSwitch = getNoteDetailSwitch;

exports.getBrandLotteryInfo = getBrandLotteryInfo;

exports.getNoteCommentDetail = getNoteCommentDetail;

exports.getPinchNum = getPinchNum;

exports.getNoteTags = getNoteTags;

var _http = require("../utils/http");

function _objectWithoutProperties(obj, keys) {
    var target = {};
    for (var i in obj) {
        if (keys.indexOf(i) >= 0) continue;
        if (!Object.prototype.hasOwnProperty.call(obj, i)) continue;
        target[i] = obj[i];
    }
    return target;
}

/* eslint camelcase: false */ function getVideoNoteFeed(_ref) {
    var id = _ref.id, _ref$num = _ref.num, num = _ref$num === undefined ? 10 : _ref$num, _ref$page = _ref.page, page = _ref$page === undefined ? 1 : _ref$page;
    return (0, _http.get)("VIDEO_NOTE_FEED", {
        transform: true,
        params: {
            pageSize: num,
            page: page
        },
        resourceParams: {
            noteId: id
        }
    });
}

function getSingleNote(_ref2) {
    var id = _ref2.id;
    return (0, _http.get)("SINGLE_FEED", {
        transform: true,
        resourceParams: {
            noteId: id
        }
    });
}

function getRelatedNotes() {
    var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var id = options.id, otherParams = _objectWithoutProperties(options, [ "id" ]);
    return (0, _http.get)("RELATED_NOTES", {
        transform: false,
        params: otherParams,
        resourceParams: {
            noteId: id
        }
    });
}

function getRelatedNoteFeed() {
    var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var id = options.id, otherParams = _objectWithoutProperties(options, [ "id" ]);
    return (0, _http.get)("RELATED_NOTE_FEEDS", {
        transform: false,
        params: otherParams,
        resourceParams: {
            noteId: id
        }
    });
}

function likeNote(_ref3) {
    var noteId = _ref3.noteId;
    return (0, _http.post)("LIKE_NOTE", {
        noteId: noteId
    }, {
        transform: true,
        resourceParams: {
            noteId: noteId
        }
    });
}

function dislikeNote(_ref4) {
    var noteId = _ref4.noteId;
    return (0, _http.del)("LIKE_NOTE", {
        transform: true,
        resourceParams: {
            noteId: noteId
        }
    });
}

function collectNote(_ref5) {
    var noteId = _ref5.noteId, sid = _ref5.sid;
    return (0, _http.post)("COLLECT_NOTE", {
        noteId: noteId
    }, {
        transform: true,
        resourceParams: {
            noteId: noteId,
            sid: sid
        }
    });
}

function deleteCollectNote(_ref6) {
    var noteId = _ref6.noteId, sid = _ref6.sid;
    return (0, _http.del)("COLLECT_NOTE", {
        transform: true,
        params: {
            noteId: noteId
        },
        resourceParams: {
            noteId: noteId,
            sid: sid
        }
    });
}

function getNoteImageStickers(id) {
    return (0, _http.get)("IMAGE_STICKERS", {
        transform: true,
        resourceParams: {
            id: id
        }
    });
}

function getNoteDetailSwitch() {
    return (0, _http.get)("NOTE_DETAIL_ACTIVITY_SWITCH", {
        transform: true
    });
}

function getBrandLotteryInfo(data) {
    return (0, _http.get)("GET_BRAND_LOTTERY_INFO", {
        transform: true,
        params: data
    });
}

function getNoteCommentDetail(_ref7) {
    var noteId = _ref7.noteId, pageSize = _ref7.pageSize, endId = _ref7.endId;
    var params = {
        pageSize: pageSize || 10
    };
    if (endId) {
        params.endId = endId;
    }
    return (0, _http.get)("NOTE_COMMENT_DETAIL", {
        params: params,
        resourceParams: {
            noteId: noteId
        }
    });
}

function getPinchNum(payload) {
    return (0, _http.get)("PINCH_READ_NUM", {
        transform: true,
        resourceParams: {
            id: payload.id
        }
    });
}

function getNoteTags(_ref8) {
    var id = _ref8.id;
    return (0, _http.get)("NOTE_TAGS", {
        resourceParams: {
            noteId: id
        }
    });
}