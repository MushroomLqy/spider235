Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.fetchItems = fetchItems;

var _http = require("../utils/http");

// 即将废弃
function fetchItems(_ref) {
    var itemIds = _ref.itemIds, _ref$type = _ref.type, type = _ref$type === undefined ? 0 : _ref$type, _ref$datetime = _ref.datetime, datetime = _ref$datetime === undefined ? 0 : _ref$datetime;
    return get("ITEMS_INFO", {
        transform: true,
        params: {
            itemIds: itemIds.join(","),
            datetime: datetime,
            type: type
        }
    });
}