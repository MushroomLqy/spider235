Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.getActivityBanner = getActivityBanner;

var _http = require("../utils/http");

function getActivityBanner(params) {
    return (0, _http.get)("GET_ACTIVITY_BANNER", {
        params: params
    });
}