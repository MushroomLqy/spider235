Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.createData = exports.mapPage = exports.DEFAULT_DATA = undefined;

exports.getSearchFromKeyword = getSearchFromKeyword;

exports.getTopicFromKeyword = getTopicFromKeyword;

var _http = require("../utils/http");

var _page = require("../utils/page");

var _string = require("../utils/string");

var DEFAULT_META = {};

var DEFAULT_DATA = exports.DEFAULT_DATA = Object.assign({}, DEFAULT_META, {
    notes: []
});

var parseOneboxString = function parseOneboxString() {
    var item = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
    return item.replace(/·/g, " | ");
};

var parseTopicFromKeyword = function parseTopicFromKeyword(data) {
    var items = [];
    var topics = [];
    if (data && data.noteTopics && Array.isArray(data.noteTopics)) {
        items = data.noteTopics.slice();
    }
    items.forEach(function(item) {
        topics.push({
            name: item.name,
            link: item.link,
            id: item.id
        });
    });
    if (data && data.recommendOthers && data.recommendOthers.id) {
        data.recommendOthers.desc = parseOneboxString(data.recommendOthers.desc);
        var descType = data.recommendOthers.desc.split(" | ") || [];
        var isCity = descType[0] === "城市";
        return {
            topics: topics,
            isOthers: true,
            onebox: data.recommendOthers,
            isCity: isCity
        };
    } else if (data && data.recommendUser && data.recommendUser.id) {
        data.recommendUser.info = parseOneboxString(data.recommendUser.info);
        return {
            topics: topics,
            isUser: true,
            onebox: data.recommendUser
        };
    } else if (data && data.recommendGoods && data.recommendGoods.desc) {
        return {
            topics: topics,
            isGoods: true,
            onebox: data.recommendGoods
        };
    }
    return {
        topics: topics
    };
};

function getSearchFromKeyword(_ref) {
    var keyword = _ref.keyword, pagination = _ref.pagination, _ref$sort = _ref.sort, sort = _ref$sort === undefined ? "general" : _ref$sort, needGifCover = _ref.needGifCover, _ref$prependNoteIds = _ref.prependNoteIds, prependNoteIds = _ref$prependNoteIds === undefined ? "" : _ref$prependNoteIds;
    var params = {
        keyword: keyword,
        sortBy: sort,
        page: pagination.page,
        pageSize: pagination.pageSize,
        prependNoteIds: prependNoteIds
    };
    if (needGifCover) {
        params.needGifCover = needGifCover;
    }
    return (0, _http.get)("SEARCH_NOTES_FROM_KEYWORD", {
        params: params
    });
}

function getTopicFromKeyword(_ref2) {
    var keyword = _ref2.keyword;
    return (0, _http.get)("SEARCH_TOPIC", {
        transform: true,
        params: {
            keyword: keyword
        }
    });
}

var mapPage = exports.mapPage = function mapPage() {
    var oldNotesList = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var newNotesList = arguments[1];
    var _ref3 = arguments[2];
    var page = _ref3.page, pageSize = _ref3.pageSize, homeFeeds = _ref3.homeFeeds;
    var _commonMapPage = (0, _page.mapPage)(oldNotesList.notes, newNotesList.notes, {
        page: page,
        pageSize: pageSize,
        homeFeeds: homeFeeds
    }), list = _commonMapPage.list, pagination = _commonMapPage.pagination;
    return Object.assign({}, newNotesList, {
        notes: list,
        pagination: pagination
    });
};

var createData = exports.createData = function createData(notes) {
    var meta = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    if (!notes) {
        console.error("[notes-list] could not found notes array");
        // eslint-disable-line
        }
    var escapedNotes = notes.map(function(notesItem) {
        return Object.assign(notesItem, {
            title: (0, _string.escapeNoteString)(notesItem.title),
            desc: (0, _string.escapeNoteString)(notesItem.desc)
        });
    });
    var data = Object.assign({}, DEFAULT_DATA, meta, {
        notes: escapedNotes
    });
    return data;
};