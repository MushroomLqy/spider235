Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.sendTrackInfo = sendTrackInfo;

exports.wxTrack = wxTrack;

exports.goodsDetailTrack = goodsDetailTrack;

exports.checkoutTrack = checkoutTrack;

exports.bindMobileTrack = bindMobileTrack;

exports.launchAppTrack = launchAppTrack;

var _http = require("../utils/http");

var _httpConfig = require("../http.config.js");

var _routes = require("../routes");

var _path = require("../utils/path");

var _abTest = require("../utils/ab-test");

var _abTest2 = _interopRequireDefault(_abTest);

var _api = require("../utils/api");

var _api2 = _interopRequireDefault(_api);

var _md = require("../libs/md5");

var _md2 = _interopRequireDefault(_md);

var _uuid = require("../libs/uuid");

var _uuid2 = _interopRequireDefault(_uuid);

var _user = require("../utils/user");

var _user2 = _interopRequireDefault(_user);

var _string = require("../utils/string");

var _enum = require("../utils/enum");

var _projectVersion = require("../project-version");

var _projectVersion2 = _interopRequireDefault(_projectVersion);

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

var systemInfo = null;

var fromSource = "";

var shareAppUserId = "";

var externalSource = "";

var lastScene = "";

var canLaunchApp = null;

function transformDataToServiceStyle() {
    var data = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var result = {};
    var mapObj = function mapObj(scope, checkData) {
        Object.keys(checkData).forEach(function(checkKey) {
            var newKey = (0, _string.toLowerLine)(checkKey);
            if (Object.prototype.toString.call(checkData[checkKey]) === "[object Object]") {
                scope[newKey] = {};
                mapObj(scope[newKey], checkData[checkKey]);
            } else {
                scope[newKey] = checkData[checkKey];
            }
        });
    };
    mapObj(result, data);
    return result;
}

function sendTrackInfo() {
    var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var category = options.category, seAc = options.seAc, seLa = options.seLa, sePr = options.sePr, url = options.url, from = options.from, source = options.source, appuid = options.appuid, e = options.e, _options$co = options.co, co = _options$co === undefined ? {} : _options$co, aid = options.aid, isApm = options.isApm;
    // 更新首次应用启动时候的场景值
        if (!lastScene && co && co.scene) {
        lastScene = co.scene;
    }
    if ([ _enum.SHARE_MEESAGE_SCENE, _enum.APP_OPEN_SCENE ].indexOf(co.scene) > -1) {
        canLaunchApp = true;
        lastScene = co.scene;
    } else {
        if (lastScene === _enum.SHARE_MEESAGE_SCENE && co && [ _enum.OTHER_MP_BACK_SCENE, _enum.MAIN_CHAT_SCENE, _enum.HISTORY_SCENE ].indexOf(co.scene) > -1) {
            canLaunchApp = true;
        } else {
            canLaunchApp = false;
        }
    }
    // 渠道号
        if (from) {
        fromSource = from;
    }
    // app 端分享人的id
        if (appuid) {
        shareAppUserId = appuid;
    }
    // 来源
        if (source) {
        externalSource = source;
    }
    var pageCheckoutData = {};
    var trackRequestUrl = _httpConfig.config.API_LIST.TRACKING;
    if (fromSource) {
        pageCheckoutData.from = fromSource;
    }
    if (shareAppUserId) {
        pageCheckoutData.appuid = shareAppUserId;
    }
    if (externalSource) {
        pageCheckoutData.source = externalSource;
    }
    if (aid) {
        pageCheckoutData.aid = aid;
    }
    if (lastScene && co && co.scene) {
        pageCheckoutData.last_scene = lastScene;
        // eslint-disable-line
        }
    if (canLaunchApp !== null) {
        pageCheckoutData.can_launch_app = canLaunchApp;
        // eslint-disable-line
        }
    seAc = seAc || "";
    seAc = seAc.replace(/-/g, "_");
    co = co || {};
    for (var key in co) {
        if (Object.prototype.hasOwnProperty.call(co, key)) {
            pageCheckoutData[key] = co[key];
        }
    }
    // 获取基本信息
        if (!systemInfo) {
        try {
            systemInfo = _api2.default.getSystemInfoSync();
            // eslint-disable-line
                        if (systemInfo.brand && systemInfo.brand === "devtools") {
                trackRequestUrl = _httpConfig.config.API_LIST.TRACKING_TEST;
            }
        } catch (e) {
            // eslint-disable-line
            systemInfo = {};
        }
    }
    var userInfo = _user2.default.getUserInfo();
    // eslint-disable-line
        var openid = userInfo.openid, appUserId = userInfo.appUserId, isNewWxmpUser = userInfo.isNewWxmpUser, wxUserInfo = userInfo.wxUserInfo, authorization = userInfo.authorization, sid = userInfo.sid;
    var appUserInfo = userInfo.appUserInfo || {};
    var checkoutData = {
        schema: "xhs_mini_program/1-0-0",
        data: [ {
            schema: "mp-user/1-0-0",
            data: {
                openid: openid,
                isNewWxmpUser: isNewWxmpUser,
                isAppUser: appUserInfo.isAppUser,
                wxNickname: wxUserInfo && wxUserInfo.nickname,
                sid: sid,
                authorization: authorization
            }
        }, {
            schema: "page-info/1-0-0",
            data: pageCheckoutData
        }, {
            schema: "system-info/1-0-0",
            data: {
                model: systemInfo.model || "",
                platform: systemInfo.platform || "",
                sdk: systemInfo.SDKVersion || "",
                system: systemInfo.system || "",
                version: systemInfo.version || ""
            }
        } ]
    };
    var showProjectVersion = _projectVersion2.default ? _projectVersion2.default : "1.0";
    var eid = void 0;
    var uid = void 0;
    try {
        uid = appUserId ? (0, _md2.default)(appUserId) : null;
        eid = _uuid2.default.new().hex;
    } catch (error) {}
    // eslint-disable-line
        var item = {
        tna: "mpT",
        tv: "mp-0.1.0",
        aid: "xhs_marco_mewtwo#" + showProjectVersion,
        vp: systemInfo.windowWidth + "x" + systemInfo.windowHeight,
        p: "mp",
        e: e || "se",
        exp: "",
        eid: eid,
        seCa: category,
        seAc: seAc,
        uid: uid,
        // user token
        nuid: appUserId || null,
        url: url,
        co: checkoutData
    };
    if (sePr) {
        item.sePr = sePr;
    }
    if (seLa) {
        item.seLa = seLa;
    }
    item.co = JSON.stringify(item.co);
    // if (uid) {
    //   item.uid = md5(uid)
    // }
        console.log("trackRequestUrl: " + trackRequestUrl + ", trackItem:", item);
    // eslint-disable-line
        return new Promise(function(resolve) {
        var requestTrack = function requestTrack() {
            var expIds = _abTest2.default.getExpIds();
            item.exp = expIds.join("|");
            wx.request({
                url: trackRequestUrl,
                method: "POST",
                header: {
                    Authorization: authorization
                },
                data: {
                    schema: "payload",
                    data: [ transformDataToServiceStyle(item) ]
                },
                fail: function fail() {
                    console.error("track request fail");
                    // eslint-disable-line
                                }
            });
        };
        if (isApm || _abTest2.default.checkReady()) {
            requestTrack();
        } else {
            _abTest2.default.AddQueue(requestTrack);
        }
        resolve();
    });
}

function wxTrack(_ref) {
    var action = _ref.action, label = _ref.label, property = _ref.property, uid = _ref.uid;
    var _getPageUrl = (0, _path.getPageUrl)(), route = _getPageUrl.route, url = _getPageUrl.url, from = _getPageUrl.from, scene = _getPageUrl.scene;
    var category = (0, _routes.getCategory)(route);
    sendTrackInfo({
        category: category,
        seAc: action,
        sePr: property,
        url: url,
        from: from,
        co: {
            scene: scene
        }
    });
    return _api2.default.reportAnalytics("track", {
        // eslint-disable-line
        category: category || this.$wxpage.route,
        action: action,
        label: label,
        property: property,
        uid: uid || this.appUserId
    });
}

function goodsDetailTrack(_ref2) {
    var xhsGS = _ref2.xhsGS;
    var _Api$getStorageSync = _api2.default.getStorageSync("user_info"), openid = _Api$getStorageSync.openid, appUserId = _Api$getStorageSync.appUserId;
    // eslint-disable-line
        return sendTrackInfo({
        openid: openid,
        uid: appUserId,
        category: "goods_detail",
        seAc: "click_instance_buy",
        sePr: xhsGS,
        url: "pages/goods/index"
    });
}

function checkoutTrack(_ref3) {
    var xhsGS = _ref3.xhsGS, oid = _ref3.oid;
    var _Api$getStorageSync2 = _api2.default.getStorageSync("user_info"), openid = _Api$getStorageSync2.openid, token = _Api$getStorageSync2.token, appUserId = _Api$getStorageSync2.appUserId;
    // eslint-disable-line
        return sendTrackInfo({
        openid: openid,
        token: token,
        uid: appUserId,
        category: "order_checked",
        seAc: "pay_success",
        sePr: oid,
        url: "pages/checkout/index?xhs_g_s=" + xhsGS
    });
}

/**
 * 绑定手机号跟踪
 * @param action 'click_bind' 'skip_bind'
 * @param url 当前页面url
 * @param status 绑定状态
 */ function bindMobileTrack(_ref4) {
    var action = _ref4.action, url = _ref4.url, status = _ref4.status;
    var _Api$getStorageSync3 = _api2.default.getStorageSync("user_info"), openid = _Api$getStorageSync3.openid, token = _Api$getStorageSync3.token, appUserId = _Api$getStorageSync3.appUserId;
    // eslint-disable-line
        return sendTrackInfo({
        openid: openid,
        token: token,
        uid: appUserId,
        category: url === "pages/mine/index" ? "My_View" : "goods_detail",
        seAc: action,
        sePr: status,
        url: url
    });
}

function launchAppTrack(_ref5) {
    var category = _ref5.category, url = _ref5.url, fail = _ref5.fail, label = _ref5.label;
    var _Api$getStorageSync4 = _api2.default.getStorageSync("user_info"), openid = _Api$getStorageSync4.openid, token = _Api$getStorageSync4.token, appUserId = _Api$getStorageSync4.appUserId;
    // eslint-disable-line
        return sendTrackInfo({
        openid: openid,
        token: token,
        uid: appUserId,
        category: category,
        seAc: fail ? "launch_app_failed" : "launch_app_clicked",
        seLa: label || "launch_app_btn",
        url: url
    });
}