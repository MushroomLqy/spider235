Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.comment = comment;

var _http = require("../utils/http");

/* ------------------------------------ */ function comment(params) {
    return (0, _http.post)("SEND_COMMENT", params, {
        header: {
            "Content-Type": "application/x-www-form-urlencoded"
        }
    });
}