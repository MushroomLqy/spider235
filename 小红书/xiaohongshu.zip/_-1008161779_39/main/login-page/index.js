// main/login-page/index.js
Page({data: {}})