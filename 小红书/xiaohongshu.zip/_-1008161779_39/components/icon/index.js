Component({
    properties: {
        svg: String,
        width: String,
        height: String
    }
});