Component({
    properties: {
        type: {
            type: String,
            default: "search"
        },
        focus: {
            type: Boolean,
            default: false
        },
        searchValue: {
            type: String,
            default: ""
        },
        hasSearch: {
            type: Boolean,
            default: false
        },
        placeHolder: {
            type: String,
            default: ""
        }
    },
    methods: {
        handleInput: function handleInput(e) {
            var value = e.detail.value;
            this.data.searchValue = value;
            this.triggerEvent("handleInput", value);
        },
        handleCancel: function handleCancel() {
            // todo 删除数据的逻辑在外面加
            this.triggerEvent("handleCancel");
        },
        handleFocus: function handleFocus(e) {
            // 在外面处理跳转搜索页的逻辑
            var value = e.detail.value;
            this.triggerEvent("handleFocus", value);
        },
        handleConfirm: function handleConfirm(e) {
            var value = e.detail.value;
            this.triggerEvent("handleConfirm", value);
        },
        search: function search() {
            // 返回上一个页面   存储进来的值，返回的时候带回去
            this.triggerEvent("handleSearch", this.data.searchValue);
        },
        goSearchPage: function goSearchPage() {
            this.triggerEvent("goSearchPage");
        }
    }
});