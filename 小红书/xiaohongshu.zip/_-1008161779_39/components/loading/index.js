var _miniprogramComputed = require("./../../karin_npm/miniprogram-computed/miniprogram_dist/index.js");

var _miniprogramComputed2 = _interopRequireDefault(_miniprogramComputed);

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

Component({
    behaviors: [ _miniprogramComputed2.default ],
    properties: {
        type: String,
        text: String
    },
    computed: {
        loadingSrc: function loadingSrc(data) {
            var loadingSrc = "";
            switch (data.type) {
              case "defeat":
                loadingSrc = "/assets/images/loading.gif";
                break;

              case "red":
                loadingSrc = "/assets/images/loading-red.gif";
                break;

              case "gray":
                loadingSrc = "/assets/images/loading-gray.gif";
                break;

              default:
                loadingSrc = "/assets/images/loading.gif";
                break;
            }
            return loadingSrc;
        },
        loadingClass: function loadingClass(data) {
            var loadingClass = "";
            switch (data.type) {
              case "defeat":
                loadingClass = "loading-defeat";
                break;

              case "red":
                loadingClass = "loading-red";
                break;

              case "gray":
                loadingClass = "loading-gray";
                break;

              default:
                loadingClass = "loading-defeat";
                break;
            }
            return loadingClass;
        }
    }
});