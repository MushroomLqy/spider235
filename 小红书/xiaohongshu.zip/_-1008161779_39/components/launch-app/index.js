var _tracker = require("../../services/tracker");

var _track = require("../../utils/track");

var _path = require("../../utils/path");

var _api = require("../../utils/api");

var _api2 = _interopRequireDefault(_api);

var _routes = require("../../routes");

var _mp = require("../../libs/@xhs/protobuf-mp-chakra-tracker/mp.js");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

var launchOps = _api2.default.$instance.globalData.launchOps;

Component({
    properties: {
        launchAppParameter: String,
        show: Boolean,
        authorId: String,
        source: String
    },
    data: {
        showModal: false
    },
    methods: {
        handleTapLaunchApp: function handleTapLaunchApp() {
            var _getPageUrl = (0, _path.getPageUrl)(), route = _getPageUrl.route;
            var category = (0, _routes.getCategory)(route);
            var _data = this.data, source = _data.source, _data$launchAppParame = _data.launchAppParameter, launchAppParameter = _data$launchAppParame === undefined ? "" : _data$launchAppParame;
            if (source) {
                (0, _track.trackNormalData)({
                    action: "launch_app",
                    label: source
                });
            } else {
                (0, _tracker.launchAppTrack)({
                    category: category,
                    url: route + "?scene=" + launchOps.scene
                });
            }
            wx.$eaglet.push(_mp.tracker[5624]({
                channelTabName: source.replace(/-/g, "_"),
                channelTabId: (0, _path.getIdFromDeeplink)(launchAppParameter)
            }));
        },
        handleLaunchAppSuccess: function handleLaunchAppSuccess() {
            var source = this.data.source;
            (0, _track.trackNormalData)({
                action: "launch_app_success",
                label: source
            });
        },
        handleLaunchAppError: function handleLaunchAppError(e) {
            var _getPageUrl2 = (0, _path.getPageUrl)(), route = _getPageUrl2.route;
            var category = (0, _routes.getCategory)(route);
            console.log(e);
            // eslint-disable-line
                        (0, _tracker.launchAppTrack)({
                category: category,
                url: route + "?scene=" + launchOps.scene,
                fail: true
            });
            (0, _track.trackClick)({
                label: "open_contact_modal",
                timeStamp: new Date().getTime()
            });
            this.setData({
                showModal: true
            });
        },
        handleCloseModal: function handleCloseModal() {
            this.setData({
                showModal: false
            });
        }
    }
});