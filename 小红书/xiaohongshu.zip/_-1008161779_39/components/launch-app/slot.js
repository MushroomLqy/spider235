var _tracker = require("../../services/tracker");

var _track = require("../../utils/track");

var _path = require("../../utils/path");

var _api = require("../../utils/api");

var _api2 = _interopRequireDefault(_api);

var _routes = require("../../routes");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

var launchOps = _api2.default.$instance.globalData.launchOps;

Component({
    properties: {
        launchAppParameter: String,
        show: Boolean,
        authorId: String,
        customMessageReplyInfo: Object
    },
    data: {
        showModal: false,
        openType: "launchApp"
    },
    methods: {
        handleTapLaunchApp: function handleTapLaunchApp() {
            var _getPageUrl = (0, _path.getPageUrl)(), route = _getPageUrl.route;
            var category = (0, _routes.getCategory)(route);
            (0, _tracker.launchAppTrack)({
                category: category,
                url: route + "?scene=" + launchOps.scene
            });
        },
        handleLaunchAppError: function handleLaunchAppError(e) {
            var _getPageUrl2 = (0, _path.getPageUrl)(), route = _getPageUrl2.route;
            var category = (0, _routes.getCategory)(route);
            console.log(e);
            // eslint-disable-line
                        (0, _tracker.launchAppTrack)({
                category: category,
                url: route + "?scene=" + launchOps.scene,
                fail: true
            });
            (0, _track.trackClick)({
                label: "open_contact_modal",
                timeStamp: new Date().getTime()
            });
            this.setData({
                showModal: true
            });
        },
        handleCloseModal: function handleCloseModal() {
            this.setData({
                showModal: false
            });
        }
    },
    ready: function ready() {
        this.setData({
            openType: _api2.default.$instance.globalData.canLaunchApp ? "launchApp" : ""
        });
    }
});