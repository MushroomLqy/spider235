var _track = require("../../utils/track");

Component({
    properties: {
        showModal: Boolean,
        modalWidth: String,
        background: String
    },
    methods: {
        handleTabCloseModal: function handleTabCloseModal() {
            (0, _track.trackClick)({
                label: "cancel_to_contact",
                timeStamp: new Date().getTime()
            });
            this.triggerEvent("closeModal");
        },
        handleToContact: function handleToContact() {
            (0, _track.trackClick)({
                label: "to_contact",
                timeStamp: new Date().getTime()
            });
        }
    }
});