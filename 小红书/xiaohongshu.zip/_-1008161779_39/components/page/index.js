var _extends = Object.assign || function(target) {
    for (var i = 1; i < arguments.length; i++) {
        var source = arguments[i];
        for (var key in source) {
            if (Object.prototype.hasOwnProperty.call(source, key)) {
                target[key] = source[key];
            }
        }
    }
    return target;
};

var _miniprogramComputed = require("./../../karin_npm/miniprogram-computed/miniprogram_dist/index.js");

var _miniprogramComputed2 = _interopRequireDefault(_miniprogramComputed);

var _path = require("../../utils/path");

var _track = require("../../utils/track");

var _page = require("../../utils/page");

var _enum = require("../../utils/enum");

var _datetime = require("../../utils/datetime");

var _user = require("../../utils/user");

var _user2 = _interopRequireDefault(_user);

var _api = require("../../utils/api");

var _api2 = _interopRequireDefault(_api);

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

Component({
    behaviors: [ _miniprogramComputed2.default ],
    properties: {
        type: {
            type: String,
            default: ""
        },
        navigationBarConfig: {
            type: Object,
            default: {}
        },
        pageConfig: Object
    },
    computed: {
        leftSideInnerClass: function leftSideInnerClass(data) {
            var leftSideInnerClass = "";
            switch (data.type) {
              case "defeat":
                leftSideInnerClass = "back-defeat";
                break;

              case "white":
                leftSideInnerClass = "back-white";
                break;

              default:
                leftSideInnerClass = "back-defeat";
                break;
            }
            return leftSideInnerClass;
        },
        navIconContainerClass: function navIconContainerClass(data) {
            var navIconContainerClass = "";
            switch (data.type) {
              case "defeat":
                navIconContainerClass = "back-icon-container-defeat";
                break;

              case "white":
                navIconContainerClass = "back-icon-container--white";
                break;

              default:
                navIconContainerClass = "back-icon-container-defeat";
                break;
            }
            return navIconContainerClass;
        }
    },
    watch: {
        navigationBarConfig: function navigationBarConfig(newValue) {
            this.setNavigationBar(newValue);
        },
        pageConfig: function pageConfig(newValue) {
            this.setPageConfig(newValue);
        }
    },
    data: {
        title: "",
        isIphoneX: false,
        navigationBarTrueHeight: (0, _page.getTopSectionHeight)(),
        navigationBarStyles: "",
        navigationBarIconsNum: 0,
        canUseCustomNavigationBar: true,
        noShowNavigationBar: false,
        showBackIcon: false,
        showHomePageIcon: false,
        pageContentStyle: "",
        pageContainerClass: "",
        pageContentMinHeight: 0,
        leftSideInnerStyle: "",
        addMyMp: {
            hasClose: false,
            isShowAddMp: false
        },
        backPage: ""
    },
    ready: function ready() {
        // 基础信息
        var systemInfo = (0, _page.getSystemInfo)();
        var isAndroid = systemInfo.platform === "android";
        var rpx2px = function rpx2px(rpx) {
            return rpx * systemInfo.windowWidth / 750;
        };
        var renderData = {};
        this.initPageScrollEvent();
        this.data.isIphoneX = _api2.default.$instance.globalData.isIPhoneX;
        var navigationBarInfo = (0, _page.getNavigationBarInfo)();
        var pages = getCurrentPages();
        // eslint-disable-line
                this.setData({
            showBackIcon: pages.length > 1
        });
        // 是否可以使用自定义导航条
                renderData.canUseCustomNavigationBar = navigationBarInfo.canCustom;
        // 是否隐藏导航条
                renderData.noShowNavigationBar = navigationBarInfo.noShow;
        if (this.data.canUseCustomNavigationBar && this.data.noShowNavigationBar) {
            renderData.navigationBarTrueHeight = 0;
        }
        renderData.pageContainerClass = " ready";
        if (this.data.isIphoneX && this.data.canUseCustomNavigationBar && this.data.noShowNavigationBar) {
            renderData.navigationBarTrueHeight = (0, _page.getTopSectionHeight)();
        }
        this.setNavigationBar(this.data.navigationBarConfig);
        renderData.pageContentMinHeight = systemInfo.windowHeight - (systemInfo.windowHeight - systemInfo.windowHeight) - this.data.navigationBarTrueHeight + "px";
        this.triggerEvent("pageSizeInfo", {
            contentViewHeight: this.pageContentMinHeight
        });
        var leftSideInnerHeight = rpx2px(64) - 2;
        var leftSideInnerMaxWidth = rpx2px(174) - 2;
        if (isAndroid) {
            leftSideInnerHeight -= 1;
            leftSideInnerMaxWidth -= 1;
        }
        leftSideInnerHeight += "px";
        leftSideInnerMaxWidth += "px";
        renderData.leftSideInnerStyle = "height: " + leftSideInnerHeight + ";max-width: " + leftSideInnerMaxWidth + ";";
        this.setPageConfig(this.data.pageConfig || {});
        this.initAddMyMp();
        this.setData(renderData);
    },
    methods: {
        checkAddMyMp: function checkAddMyMp() {
            if (this.data.addMyMp.isShowAddMp && !this.data.addMyMp.hasClose) {
                this.setData({
                    addMyMp: _extends({}, this.data.addMyMp, {
                        isShowAddMp: false
                    })
                });
            }
        },
        initAddMyMp: function initAddMyMp() {
            var _this = this;
            var pinMiniProgramTime = wx.getStorageSync(_enum.STORAGE_KEY.PIN_MINI_PROGRAM_FLAG);
            // eslint-disable-line
                        var userInfo = wx.getStorageSync(_enum.STORAGE_KEY.USER_INFO) || {};
            // eslint-disable-line
                        var isNewWxmpUser = userInfo.isNewWxmpUser;
            var now = new Date().getTime();
            if (!pinMiniProgramTime) {
                pinMiniProgramTime = now;
                this.setData({
                    addMyMp: _extends({}, this.data.addMyMp, {
                        isShowAddMp: true
                    })
                });
                if (isNewWxmpUser) {
                    this.setData({
                        addMyMp: _extends({}, this.data.addMyMp, {
                            hasClose: true
                        })
                    });
                } else {
                    setTimeout(function() {
                        _this.setData({
                            addMyMp: _extends({}, _this.data.addMyMp, {
                                isShowAddMp: false
                            })
                        });
                    }, 3e3);
                }
                wx.setStorage({
                    key: _enum.STORAGE_KEY.PIN_MINI_PROGRAM_FLAG,
                    data: pinMiniProgramTime
                });
                return;
            }
            if (pinMiniProgramTime && now - pinMiniProgramTime > (0, _datetime.getTimeStampByDay)(7)) {
                this.setData({
                    addMyMp: _extends({}, this.data.addMyMp, {
                        isShowAddMp: true
                    })
                });
                if (isNewWxmpUser) {
                    this.setData({
                        addMyMp: _extends({}, this.data.addMyMp, {
                            hasClose: true
                        })
                    });
                    userInfo.isNewWxmpUser = false;
                    _user2.default.setUserInfo(userInfo);
                } else {
                    setTimeout(function() {
                        _this.setData({
                            addMyMp: _extends({}, _this.data.addMyMp, {
                                isShowAddMp: false
                            })
                        });
                    }, 3e3);
                }
                pinMiniProgramTime = now;
                wx.setStorage({
                    key: _enum.STORAGE_KEY.PIN_MINI_PROGRAM_FLAG,
                    data: pinMiniProgramTime
                });
            }
        },
        setNavigationBar: function setNavigationBar() {
            var config = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            var pageUrl = (0, _path.getPageUrl)();
            var renderData = {};
            var navigationBarIconsNum = 0;
            renderData.showHomePageIcon = (0, _page.isShowHomePage)(pageUrl.route);
            if (this.data.showBackIcon) {
                navigationBarIconsNum += 1;
            }
            if (config.hideHomePageIcon) {
                renderData.showHomePageIcon = false;
            }
            if (renderData.showHomePageIcon) {
                navigationBarIconsNum += 1;
            }
            renderData.navigationBarIconsNum = navigationBarIconsNum;
            if (config.titleText !== undefined) {
                renderData.title = config.titleText;
                wx.setNavigationBarTitle({
                    title: config.titleText
                });
            }
            if (config.backPagePath) {
                renderData.backPage = config.backPagePath;
            }
            var defaultBackgroundColor = "#000000";
            var backgroundColor = defaultBackgroundColor;
            var color = "#ffffff";
            if (config.backgroundColor) {
                backgroundColor = config.backgroundColor;
            }
            var colorStyleMap = {
                black: "#000000",
                white: "#ffffff"
            };
            if (colorStyleMap[config.textStyle]) {
                color = colorStyleMap[config.textStyle];
            }
            var paddingTop = (0, _page.getTrueStatusBarHeight)();
            renderData.navigationBarStyles = "color: " + color + ";background-color: " + backgroundColor + ";padding-top: " + paddingTop + "px;";
            if (wx.setNavigationBarColor) {
                if (backgroundColor === "none") {
                    backgroundColor = defaultBackgroundColor;
                }
                wx.setNavigationBarColor({
                    frontColor: color,
                    backgroundColor: backgroundColor
                });
            }
            this.setData(renderData);
        },
        setPageConfig: function setPageConfig() {
            var config = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            var fullScreen = config.fullScreen, pageContentPadding = config.pageContentPadding;
            var pageContentArr = [ "min-height: " + this.data.pageContentMinHeight ];
            if (fullScreen) {
                if (pageContentPadding) {
                    pageContentArr.push("padding-top: " + this.data.navigationBarTrueHeight + "px");
                }
                pageContentArr.push("height: 100%");
            } else {
                pageContentArr.push("margin-top: " + this.data.navigationBarTrueHeight + "px");
            }
            this.setData({
                pageContentStyle: pageContentArr.join(";")
            });
        },
        initPageScrollEvent: function initPageScrollEvent() {
            var _this2 = this;
            var pageInstance = (0, _path.getCurrentPage)();
            var priviteOPageScroll = pageInstance.onPageScroll || null;
            pageInstance.onPageScroll = function(res) {
                if (priviteOPageScroll) {
                    priviteOPageScroll.call(pageInstance, res);
                }
                _this2.checkAddMyMp();
            };
        },
        handleCloseAddMyMp: function handleCloseAddMyMp() {
            this.setData({
                addMyMp: _extends({}, this.data.addMyMp, {
                    isShowAddMp: false
                })
            });
        },
        handleGoLastPage: function handleGoLastPage() {
            if (this.data.backPage) {
                (0, _track.trackNormalData)({
                    action: "navigate_back_another_page"
                });
                if (this.data.backPage === "HOME" || this.data.backPage === "HomePage") {
                    (0, _path.switchTab)(this.data.backPage, {
                        isSpecifiedPath: true
                    });
                } else {
                    (0, _path.navigateTo)(this.data.backPage, {
                        isSpecifiedPath: true
                    });
                }
            } else {
                this.triggerEvent("navigateBack");
                (0, _track.trackNormalData)({
                    action: "navigate_back"
                });
                (0, _path.navigateBack)();
            }
        },
        handleHomePage: function handleHomePage() {
            this.triggerEvent("switchHomePage");
            (0, _track.trackNormalData)({
                action: "navigate_home_page"
            });
            (0, _path.switchTab)("HomePage");
        }
    }
});