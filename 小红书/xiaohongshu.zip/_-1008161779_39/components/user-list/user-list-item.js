var _path = require("../../utils/path");

var _user = require("../../utils/user");

var _user2 = _interopRequireDefault(_user);

var _icons = require("../../utils/icons");

var _icons2 = _interopRequireDefault(_icons);

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

Component({
    properties: {
        item: Object
    },
    data: {
        officalVerified: (0, _icons.getAbsoluteUrl)("ci.xiaohongshu.com", _icons2.default.officalVerified)
    },
    methods: {
        handleTapItem: function handleTapItem() {
            var item = this.data.item || {};
            if (item.id) {
                (0, _path.navigateTo)("AuthorPage", {
                    id: item.id
                });
            }
        },
        handleTriggleFollow: function handleTriggleFollow() {
            var _userUtil$getUserInfo = _user2.default.getUserInfo(), appUserId = _userUtil$getUserInfo.appUserId;
            if (!appUserId) {
                wx.showToast({
                    title: "请先登录",
                    icon: "none"
                });
            } else if (appUserId === this.data.item.id) {
                wx.showToast({
                    title: "不能关注自己",
                    icon: "none"
                });
            } else {
                this.triggerEvent("followUserListItem", this.data.item);
            }
        },
        handleAvatarError: function handleAvatarError() {
            if (this.data.item) {
                this.data.item.images = "https://ci.xiaohongshu.com/4dbf6dd3-7611-4625-90f3-91928fe0e4b0";
            }
        }
    }
});