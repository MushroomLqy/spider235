var _vuefy = require("../../libs/vuefy.js");

Component({
    properties: {
        hide: {
            type: Boolean,
            default: true
        }
    },
    options: {
        multipleSlots: true
    },
    methods: {
        handleStopBubble: function handleStopBubble() {
            return;
        }
    },
    ready: function ready() {
        (0, _vuefy.computed)(this, {
            showModal: function showModal() {
                return !this.data.hide;
            }
        });
    }
});