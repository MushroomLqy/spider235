var _icons = require("../../utils/icons");

var _icons2 = _interopRequireDefault(_icons);

var _track = require("../../utils/track");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

Component({
    properties: {
        addMyMp: Object
    },
    data: {
        closeIcon: "https://ci.xiaohongshu.com/" + _icons2.default.close,
        addToMyMpStyle: "content"
    },
    methods: {
        handleCloseAddMyMp: function handleCloseAddMyMp() {
            (0, _track.trackClick)({
                label: "close_pin_mini_program",
                context: {},
                timeStamp: new Date().getTime()
            });
            this.triggerEvent("closeAddMyMp");
        }
    }
});