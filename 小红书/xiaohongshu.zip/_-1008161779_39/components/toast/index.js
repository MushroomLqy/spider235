var _api = require("../../utils/api");

var _api2 = _interopRequireDefault(_api);

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

Component({
    data: {
        content: "",
        animationData: {},
        display: false
    },
    methods: {
        show: function show(opt) {
            var _this = this;
            this.setData({
                display: true,
                content: opt.content
            });
            this.createAnimation(1);
            setTimeout(function() {
                _this.setData({
                    display: false
                });
                _this.createAnimation(0);
            }, opt.duration || 850);
        },
        createAnimation: function createAnimation(opacity) {
            var animation = _api2.default.createAnimation();
            this.setData({
                animationData: animation.opacity(opacity).step().export()
            });
        }
    }
});