var _miniprogramComputed = require("./../../karin_npm/miniprogram-computed/miniprogram_dist/index.js");

var _miniprogramComputed2 = _interopRequireDefault(_miniprogramComputed);

var _date = require("../../utils/date");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

Component({
    behaviors: [ _miniprogramComputed2.default ],
    properties: {
        timeStamp: {
            type: Number,
            require: true
        },
        fmt: {
            type: String,
            default: "shortTime"
        },
        interval: {
            type: String,
            default: "1000"
        }
    },
    data: {
        timer: undefined,
        time: undefined,
        endTime: undefined
    },
    watch: {
        timeStamp: function timeStamp() {
            this.data.endTime = Number(this.data.timeStamp) + new Date().getTime();
            this.data.timer && clearInterval(this.data.timer);
            this.data.timer = setInterval(this.tick.bind(this), Number(this.interval));
            setTimeout(this.tick.bind(this), 0);
        }
    },
    ready: function ready() {
        this.data.timer = setInterval(this.tick.bind(this), Number(this.interval));
        setTimeout(this.tick.bind(this), 0);
    },
    methods: {
        invokeTick: function invokeTick() {
            this.data.endTime = Number(this.data.timeStamp) + new Date().getTime();
            this.data.timer && clearInterval(this.data.timer);
            this.data.timer = setInterval(this.tick.bind(this), Number(this.interval));
            setTimeout(this.tick.bind(this), 0);
        },
        getFormatTime: function getFormatTime() {
            var now = +new Date();
            var delta = this.endTime - now;
            if (delta < 0) {
                delta = 0;
            }
            return {
                formatTime: (0, _date.formatTime)(delta, this.fmt, true),
                delta: delta
            };
        },
        tick: function tick() {
            if (!this.endTime) {
                clearInterval(this.timer);
                return;
            }
            var current = this.getFormatTime();
            this.setData({
                time: current.formatTime
            });
            // 每次进入tick函数，发出事件tick，并返回参数 {{formatTime, delta: number}}
                        this.triggerEvent("tick", current);
            if (current.delta === 0) {
                clearInterval(this.timer);
                // 倒计时结束，发出事件end
                                this.triggerEvent("end");
            }
        },
        clearDownTime: function clearDownTime() {
            clearInterval(this.data.timer);
        }
    }
});