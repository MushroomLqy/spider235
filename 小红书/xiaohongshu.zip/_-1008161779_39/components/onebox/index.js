var _path = require("../../utils/path");

var _icons = require("../../utils/icons");

var _icons2 = _interopRequireDefault(_icons);

var _tracker = require("../../services/tracker");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

Component({
    properties: {
        noteOnebox: {
            type: Object,
            default: {}
        }
    },
    data: {
        officalVerified: (0, _icons.getAbsoluteUrl)("ci.xiaohongshu.com", _icons2.default.officalVerified)
    },
    methods: {
        handleTapTopic: function handleTapTopic(e) {
            var topic = e.currentTarget.dataset.topic;
            _tracker.wxTrack.call(this, {
                action: "onebox-tap",
                label: "onebox-block",
                property: topic.id
            });
            var link = topic && topic.link ? topic.link : "";
            // 临时处理 pages
                        if (link.includes("xhsdiscover://topic")) {
                link = link.replace("xhsdiscover://topic", "/page/topics");
            }
            if (link.indexOf("xhsdiscover") > -1 && link.indexOf("wechat_miniprogram") > -1) {
                link = decodeURIComponent(link);
                var route = (0, _path.getLinkVariable)(link, "path");
                if (route) {
                    wx.navigateTo({
                        url: "/" + route
                    });
                }
                return;
            }
            (0, _path.navigateTo)("Webview", {
                link: link
            });
        },
        handleTriggleFollow: function handleTriggleFollow() {
            this.triggerEvent("handleFollowOneBox", this.data.noteOnebox.box);
        },
        handleTapItem: function handleTapItem() {
            (0, _path.navigateTo)("AuthorPage", {
                id: this.data.noteOnebox.box.id
            });
        }
    }
});