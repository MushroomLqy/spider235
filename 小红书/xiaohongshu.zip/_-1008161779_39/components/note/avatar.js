var _icons = require("../../utils/icons");

var _icons2 = _interopRequireDefault(_icons);

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

Component({
    properties: {
        item: Object,
        width: {
            type: String,
            default: 80
        },
        hasBorder: {
            type: Boolean,
            default: true
        }
    },
    data: {
        officalVerified: (0, _icons.getAbsoluteUrl)("ci.xiaohongshu.com", _icons2.default.officalVerified)
    },
    methods: {
        handleAvatarError: function handleAvatarError() {
            this.data.item.avatarImage = "http://ci.xiaohongshu.com/4dbf6dd3-7611-4625-90f3-91928fe0e4b0";
        },
        handleTapAvatar: function handleTapAvatar() {
            this.triggerEvent("avatarTapped");
        }
    }
});