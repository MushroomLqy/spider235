var _extends = Object.assign || function(target) {
    for (var i = 1; i < arguments.length; i++) {
        var source = arguments[i];
        for (var key in source) {
            if (Object.prototype.hasOwnProperty.call(source, key)) {
                target[key] = source[key];
            }
        }
    }
    return target;
};

var _miniprogramComputed = require("./../../karin_npm/miniprogram-computed/miniprogram_dist/index.js");

var _miniprogramComputed2 = _interopRequireDefault(_miniprogramComputed);

var _discovery = require("../../utils/discovery");

var _string = require("../../utils/string");

var _vuefy = require("../../libs/vuefy.js");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

function getDoubleColumnNotes() {
    var notes = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
    if (!notes.length) {
        return {
            leftNotes: [],
            rightNotes: []
        };
    }
    var leftNotes = [];
    var rightNotes = [];
    var leftNotesHWRate = 0;
    var rightNotesHWRate = 0;
    notes.forEach(function(item) {
        var newItem = void 0;
        var coverHWRate = void 0;
        if (item.cover) {
            newItem = item;
        } else {
            newItem = _extends({
                cover: item.image,
                isLiked: item.isLiked
            }, item);
        }
        if (newItem.cover && newItem.cover.url) {
            newItem.cover.url = newItem.cover.url.replace("imageView2/2/w/540/", "imageView2/2/w/400/q/85/");
        }
        newItem.trackData = JSON.stringify({
            label: "note_card",
            property: newItem.id,
            context: {},
            timeStamp: new Date().getTime()
        });
        // 如果没有标题就用正文当标题
                var title = "";
        if (newItem.title) {
            title = newItem.title;
        } else if (newItem.desc) {
            title = newItem.desc;
        }
        title = title.trim();
        newItem.title = (0, _discovery.getNoTagNoFaceIconText)(title);
        if (newItem.videoInfo) {
            coverHWRate = newItem.videoInfo.height / newItem.videoInfo.width;
        } else {
            coverHWRate = newItem.cover.height / newItem.cover.width;
        }
        if (rightNotesHWRate < leftNotesHWRate) {
            rightNotesHWRate += coverHWRate;
            rightNotes.push(newItem);
        } else {
            leftNotesHWRate += coverHWRate;
            leftNotes.push(newItem);
        }
    });
    return {
        leftNotes: leftNotes,
        rightNotes: rightNotes
    };
}

Component({
    behaviors: [ _miniprogramComputed2.default ],
    properties: {
        notes: {
            type: Object,
            default: []
        },
        isFirstLogin: {
            type: Boolean,
            default: false
        },
        isNeverFillInRecommendTagForm: {
            type: Boolean,
            default: false
        },
        canLike: {
            type: Boolean,
            default: false
        },
        isCompression: {
            // 是否开启图片压缩 默认开启
            type: Boolean,
            default: true
        }
    },
    data: {
        isLoading: false,
        leftNotes: [],
        rightNotes: []
    },
    methods: {
        renderNoteList: function renderNoteList(newNotes) {
            var _getDoubleColumnNotes = getDoubleColumnNotes(newNotes), leftNotes = _getDoubleColumnNotes.leftNotes, rightNotes = _getDoubleColumnNotes.rightNotes;
            this.setData({
                leftNotes: leftNotes,
                rightNotes: rightNotes
            });
        }
    },
    attached: function attached() {
        var version = wx.getSystemInfoSync().SDKVersion;
        if ((0, _string.compareVersion)(version, "2.6.2") < 0) {
            (0, _vuefy.watch)(this, {
                notes: function notes(newNotes) {
                    this.renderNoteList(newNotes);
                }
            });
        }
    },
    watch: {
        notes: function notes(newNotes) {
            this.renderNoteList(newNotes);
        }
    }
});