Object.defineProperty(exports, "__esModule", {
    value: true
});

var PUSH_MORE_SCOLL_TOP = exports.PUSH_MORE_SCOLL_TOP = 2e3;

var REFRESH_FEEDS_NOTES_LENGTH = exports.REFRESH_FEEDS_NOTES_LENGTH = 100;

Component({
    properties: {
        notes: {
            type: Object,
            default: []
        },
        scrollTop: {
            type: Number,
            default: 0
        },
        isFirstLogin: {
            type: Boolean,
            default: false
        },
        isNeverFillInRecommendTagForm: {
            type: Boolean,
            default: false
        },
        canLike: {
            type: Boolean,
            default: false
        }
    },
    data: {
        isLoading: false
    },
    methods: {
        handleScroll: function handleScroll(e) {
            this.triggerEvent("scroll", e);
            if (this.data.notes.length > REFRESH_FEEDS_NOTES_LENGTH) {
                this.triggerEvent("cleanFeeds");
            }
            if (e.detail.scrollHeight - e.detail.scrollTop < PUSH_MORE_SCOLL_TOP) {
                if (!this.data.isLoading) {
                    this.data.isLoading = true;
                    this.triggerEvent("pushMoreFeeds");
                }
            } else {
                this.data.isLoading = false;
            }
        },
        handleScrollToLower: function handleScrollToLower() {
            this.triggerEvent("pushMoreFeeds");
        }
    }
});