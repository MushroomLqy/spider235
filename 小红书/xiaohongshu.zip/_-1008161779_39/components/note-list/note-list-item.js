var _path = require("../../utils/path");

var _enum = require("../../utils/enum");

var _track = require("../../utils/track");

var _eventBus = require("../../libs/event-bus");

var _eventBus2 = _interopRequireDefault(_eventBus);

var _debounce = require("../../libs/debounce");

var _debounce2 = _interopRequireDefault(_debounce);

var _user = require("../../utils/user");

var _user2 = _interopRequireDefault(_user);

var _system = require("../../services/system");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

Component({
    properties: {
        item: Object,
        index: {
            type: Boolean,
            default: 0
        },
        canLike: {
            type: Boolean,
            default: false
        }
    },
    data: {
        isTaped: false,
        isLazyLoad: true,
        loadedGifMap: {}
    },
    methods: {
        collectFormId: function collectFormId(e, label) {
            var formId = e.detail.formId;
            // 采集formid
                        if (formId !== "the formId is a mock one") {
                (0, _track.trackNormalData)({
                    action: "collect_form_id",
                    label: label
                });
                (0, _system.collectFormId)(e.detail.formId);
            }
        },
        tapNoteItem: function tapNoteItem() {
            var item = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            var type = item.type, id = item.id, image = item.image;
            var pageName = "NoteDetail";
            if (type === _enum.NOTE_TYPE.MULTI) {
                console.log("[discover-note] non-supported note type " + type);
                // eslint-disable-line
                                return;
            }
            // if (!type || type === NOTE_TYPE.NORMAL) {
            //   pageName = 'DISCOVER_NOTE'
            // } else if (type === NOTE_TYPE.VIDEO) {
            //   pageName = 'DISCOVER_VIDEO_NOTE'
            // }
                        var pages = getCurrentPages();
            // eslint-disable-line
                        image = image || {};
            var _image = image, width = _image.width, height = _image.height;
            var firstImageRatio = 1;
            var firstImageOriginalPath = type === "normal" && item.cover && item.cover.originalUrl ? encodeURIComponent(item.cover.originalUrl) : "";
            var nickname = item.user && item.user.nickname ? item.user.nickname : "";
            var userid = item.user && item.user.userid ? item.user.userid : "";
            var followed = item.user && item.user.followed;
            var redOfficialVerified = item.user && item.user.redOfficialVerified;
            if (width && height) {
                firstImageRatio = height / width;
            }
            var method = pages.length === 10 ? _path.redirectTo : _path.navigateTo;
            method(pageName, {
                id: id,
                type: type,
                firstImageRatio: firstImageRatio,
                firstImageOriginalPath: firstImageOriginalPath,
                nickname: nickname,
                followed: followed,
                redOfficialVerified: redOfficialVerified,
                userid: userid
            });
        },
        handlGifLoaded: function handlGifLoaded(e) {
            var id = e.target.dataset.id;
            this.data.loadedGifMap[id] = true;
        },
        handleUserTap: function handleUserTap(e) {
            var _this = this;
            (0, _debounce2.default)(function() {
                var item = _this.data.item || {};
                var user = item.user || {};
                var userId = user.userid || user.id;
                _user2.default.ensureLogin().then(function() {
                    _this.collectFormId(e, "note_card_userinfo");
                    (0, _track.trackClick)({
                        label: "author_info",
                        property: userId,
                        context: {},
                        timeStamp: new Date().getTime()
                    });
                    (0, _path.navigateTo)("AuthorPage", {
                        author_id: userId
                    });
                });
            }, 1e3, true)();
        },
        handleNoteItemTap: function handleNoteItemTap(e) {
            // defined on note-list component
            var item = this.data.item || {};
            var type = item.type, id = item.id, trackData = item.trackData;
            if (!this.data.isTaped) {
                this.collectFormId(e, "note_card");
            }
            this.data.isTaped = true;
            if (type && id && trackData) {
                try {
                    (0, _track.trackClick)(trackData);
                } catch (e) {}
                // eslint-disable-line
                                this.triggerEvent("noteItemTap", {
                    type: type,
                    id: id
                });
                this.tapNoteItem(item);
            }
        },
        handleGoInterestTap: function handleGoInterestTap(e) {
            this.collectFormId(e, "note_card_interest");
            (0, _path.navigateTo)("InterestCollectPage");
        },
        handleLikeTap: function handleLikeTap(e) {
            if (!_user2.default.checkLogin()) {
                (0, _path.navigateTo)("LoginIndex");
                return;
            }
            this.collectFormId(e, "note_card_like");
            var item = this.data.item || {};
            var id = item.id;
            (0, _track.trackClick)({
                label: "note_card_like",
                property: id,
                context: {},
                timeStamp: new Date().getTime()
            });
            if (this.data.canLike) {
                _eventBus2.default.emit("likeTaped", id);
            } else {
                this.tapNoteItem(item);
            }
        }
    }
});