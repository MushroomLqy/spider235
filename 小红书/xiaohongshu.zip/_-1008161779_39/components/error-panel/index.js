Component({
    properties: {
        info: Object
    }
});