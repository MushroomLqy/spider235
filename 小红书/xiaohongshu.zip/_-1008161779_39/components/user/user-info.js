var _miniprogramComputed = require("./../../karin_npm/miniprogram-computed/miniprogram_dist/index.js");

var _miniprogramComputed2 = _interopRequireDefault(_miniprogramComputed);

var _track = require("../../utils/track");

var _path = require("../../utils/path");

var _icons = require("../../utils/icons");

var _icons2 = _interopRequireDefault(_icons);

var _user = require("../../utils/user");

var _user2 = _interopRequireDefault(_user);

var _api = require("../../utils/api");

var _api2 = _interopRequireDefault(_api);

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

var CDN_ORIGIN = "https://ci.xiaohongshu.com";

var isIPhoneX = _api2.default.$instance.globalData.isIPhoneX;

var getDeeplink = function getDeeplink(_ref) {
    var id = _ref.id, isMinePage = _ref.isMinePage;
    if (isMinePage) {
        return "xhsdiscover://profile";
    }
    return "xhsdiscover://user/" + id + "?sourceId=miniprogram";
};

function formatNum() {
    var num = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
    if (num >= 1e4) {
        num = Math.round((num / 1e4).toFixed(1) * 10) / 10;
        return num + "万";
    }
    return num;
}

Component({
    behaviors: [ _miniprogramComputed2.default ],
    properties: {
        noteList: {
            type: Array,
            default: []
        },
        userInfo: {
            type: Object,
            default: {}
        },
        isMembership: {
            type: Boolean,
            default: false
        },
        switchTab: {
            type: String,
            default: "notes"
        },
        isFetching: {
            type: Boolean,
            default: false
        },
        isFetchEnd: {
            type: Boolean,
            default: false
        },
        isBrand: {
            type: Boolean,
            default: false
        },
        isMinePage: {
            type: Boolean,
            default: false
        }
    },
    options: {
        multipleSlots: true
    },
    data: {
        type: "red",
        text: "加载中",
        listType: "anthor",
        isIPhoneX: false,
        canLike: true,
        defaultImage: CDN_ORIGIN + "/8c47df99-484e-448d-9226-430e46641d53",
        isLogin: false,
        noFoundImg: CDN_ORIGIN + "/6f3fecd4-4282-4448-81a6-af6c26dbc10b",
        officalVerified: (0, _icons.getAbsoluteUrl)("ci.xiaohongshu.com", _icons2.default.officalVerified)
    },
    computed: {
        followingsCustomMessageReplyInfo: function followingsCustomMessageReplyInfo(data) {
            var _ref2 = data.userInfo || {}, id = _ref2.id;
            if (!id) {
                return {};
            }
            var newData = {
                sessionFrom: JSON.stringify({
                    title: "点我，查看关注详情",
                    thumbUrl: data.userInfo.image || data.defaultImag,
                    description: "",
                    deeplink: getDeeplink({
                        isMinePage: data.isMinePage,
                        id: id
                    })
                })
            };
            return newData;
        },
        showLabels: function showLabels(data) {
            var result = true;
            if (data.isBrand) {
                result = false;
            } else if (data.userInfo) {
                if (data.userInfo.redOfficialVerifyIconType === 2) {
                    result = false;
                } else if (data.userInfo.verifyContent && data.userInfo.verifyContent.includes("官方账号")) {
                    result = false;
                }
            }
            return result;
        },
        followersCustomMessageReplyInfo: function followersCustomMessageReplyInfo(data) {
            var _ref3 = data.userInfo || {}, id = _ref3.id;
            if (!id) {
                return {};
            }
            var newData = {
                sessionFrom: JSON.stringify({
                    title: "点我，查看粉丝详情",
                    thumbUrl: data.userInfo.image || data.defaultImag,
                    description: "",
                    deeplink: getDeeplink({
                        isMinePage: data.isMinePage,
                        id: id
                    })
                })
            };
            return newData;
        },
        launchAppParameter: function launchAppParameter(data) {
            var _ref4 = data.userInfo || {}, id = _ref4.id;
            if (!id) {
                return "";
            }
            return getDeeplink({
                isMinePage: data.isMinePage,
                id: id
            });
        },
        likedAndCollected: function likedAndCollected(data) {
            var _ref5 = data.userInfo || {}, liked = _ref5.liked, collected = _ref5.collected;
            var likedAndCollectedNum = liked + collected;
            return formatNum(likedAndCollectedNum) || 0;
        },
        fansNum: function fansNum(data) {
            var _ref6 = data.userInfo || {}, fans = _ref6.fans;
            return formatNum(fans);
        },
        genderIcon: function genderIcon(data) {
            var _ref7 = data.userInfo || {}, gender = _ref7.gender;
            if (gender === undefined) {
                return "";
            }
            return gender === 1 ? CDN_ORIGIN + "/" + _icons2.default.genderFemaleIcon : CDN_ORIGIN + "/" + _icons2.default.genderMaleIcon;
        }
    },
    methods: {
        handleTapSwitchTab: function handleTapSwitchTab(e) {
            if (!this.data.isLogin) {
                return;
            }
            var switchTab = e.currentTarget.dataset.type;
            (0, _track.trackNormalData)({
                action: "switchTab",
                property: switchTab
            });
            var listType = "";
            if (switchTab === "collect") {
                listType = "collect";
            } else if (switchTab === "atTa") {
                listType = "atTa";
            } else {
                listType = "anthor";
            }
            this.setData({
                listType: listType
            });
            this.triggerEvent("tapSwitchTab", switchTab);
        },
        handleTapSettings: function handleTapSettings() {
            if (!this.data.isLogin) {
                (0, _path.navigateTo)("LoginIndex");
                return;
            }
            (0, _track.trackClick)({
                label: "settings",
                context: {},
                timeStamp: new Date().getTime()
            });
            (0, _path.navigateTo)("SETTINGS");
        },
        handleTapFollowings: function handleTapFollowings() {
            if (!this.data.isLogin) {
                return;
            }
            (0, _track.trackClick)({
                label: "followings",
                context: {},
                timeStamp: new Date().getTime()
            });
            // navigateTo('FOLLOWINGS', { authorId: this.userInfo.id })
                },
        handleTapFollowers: function handleTapFollowers() {
            if (!this.data.isLogin) {
                return;
            }
            (0, _track.trackClick)({
                label: "followers",
                context: {},
                timeStamp: new Date().getTime()
            });
            // navigateTo('FOLLOWERS', { authorId: this.userInfo.id })
                },
        handleToLogin: function handleToLogin() {
            (0, _path.navigateTo)("LoginIndex");
        },
        handleTapUserImage: function handleTapUserImage() {
            if (!this.data.isLogin) {
                (0, _path.navigateTo)("LoginIndex");
                return;
            }
        },
        jumpToMemberWebview: function jumpToMemberWebview() {
            _user2.default.ensureLogin().then(function() {
                (0, _path.navigateTo)("Webview", {
                    link: "/store/mc/landing"
                });
            });
        }
    },
    ready: function ready() {
        this.setData({
            isIPhoneX: isIPhoneX,
            isLogin: _user2.default.getUserId()
        });
    }
});