var _miniprogramComputed = require("./../../karin_npm/miniprogram-computed/miniprogram_dist/index.js");

var _miniprogramComputed2 = _interopRequireDefault(_miniprogramComputed);

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

var CDN_ORIGIN = "https://ci.xiaohongshu.com";

var CONTAINER_IMAGE_DEFAULT = {
    goods: {
        imageUrl: CDN_ORIGIN + "/e3d4990f-d80f-4adb-a2f6-e056c356c916",
        title: "没有找到相关商品 换个词试试吧"
    },
    notes: {
        imageUrl: CDN_ORIGIN + "/e3d4990f-d80f-4adb-a2f6-e056c356c916",
        title: "没有找到相关笔记 换个词试试吧"
    },
    collect: {
        imageUrl: CDN_ORIGIN + "/6f3fecd4-4282-4448-81a6-af6c26dbc10b",
        title: "还没有收藏任何笔记哦"
    },
    user: {
        imageUrl: CDN_ORIGIN + "/5e9cea27-311c-4be3-ae98-05783e142842",
        title: "没有找到相关用户 换个词试试吧"
    },
    anthor: {
        imageUrl: CDN_ORIGIN + "/6f3fecd4-4282-4448-81a6-af6c26dbc10b",
        title: "还没有笔记哦"
    },
    atTa: {
        imageUrl: CDN_ORIGIN + "/ca061265-40ca-4bb5-a76e-85954168165c",
        title: "还没有@TA的笔记哦"
    }
};

Component({
    behaviors: [ _miniprogramComputed2.default ],
    properties: {
        type: {
            type: String,
            default: ""
        }
    },
    data: {
        obj: {
            imageUrl: CDN_ORIGIN + "/6f3fecd4-4282-4448-81a6-af6c26dbc10b",
            title: "还没有笔记哦"
        }
    },
    computed: {
        objC: function objC(data) {
            var type = data.type || "anthor";
            var obj = CONTAINER_IMAGE_DEFAULT[type];
            return obj;
        }
    }
});