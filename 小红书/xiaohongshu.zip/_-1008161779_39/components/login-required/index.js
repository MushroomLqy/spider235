var _regenerator = require("./../../karin_npm/babel-runtime/regenerator/index.js");

var _regenerator2 = _interopRequireDefault(_regenerator);

var _miniprogramComputed = require("./../../karin_npm/miniprogram-computed/miniprogram_dist/index.js");

var _miniprogramComputed2 = _interopRequireDefault(_miniprogramComputed);

var _user = require("../../utils/user");

var _user2 = _interopRequireDefault(_user);

var _track = require("../../utils/track");

var _path = require("../../utils/path");

var _login = require("../../utils/login");

var _login2 = _interopRequireDefault(_login);

var _api = require("../../utils/api");

var _api2 = _interopRequireDefault(_api);

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

function _asyncToGenerator(fn) {
    return function() {
        var gen = fn.apply(this, arguments);
        return new Promise(function(resolve, reject) {
            function step(key, arg) {
                try {
                    var info = gen[key](arg);
                    var value = info.value;
                } catch (error) {
                    reject(error);
                    return;
                }
                if (info.done) {
                    resolve(value);
                } else {
                    return Promise.resolve(value).then(function(value) {
                        step("next", value);
                    }, function(err) {
                        step("throw", err);
                    });
                }
            }
            return step("next");
        });
    };
}

var defaultSource = "default";

Component({
    behaviors: [ _miniprogramComputed2.default ],
    properties: {
        showLoginModal: Boolean,
        showLoginModalSource: String,
        noNeedRelaunch: Boolean
    },
    data: {
        autoShow: false,
        isReady: false,
        canShowLoginModal: false
    },
    methods: {
        handleGetPhoneNumber: function handleGetPhoneNumber(data) {
            var _this = this;
            var _ref = data.detail || {}, errMsg = _ref.errMsg, encryptedData = _ref.encryptedData, iv = _ref.iv;
            (0, _track.trackNormalData)({
                action: "get_user_phone_number"
            });
            // 判断是否授权手机号
                        if (errMsg.indexOf("getPhoneNumber:fail") > -1 || errMsg.indexOf("deny") > -1) {
                (0, _track.trackNormalData)({
                    action: "get_user_phone_number_failed"
                });
                return;
            }
            _user2.default.loginWidthEncryptedData({
                encryptedData: encryptedData,
                iv: iv
            }).then(function(userInfo) {
                if (userInfo) {
                    _login2.default.saveUserInfo(userInfo);
                }
                _this.setData({
                    autoShow: false
                });
                _this.triggerEvent("closeLoginModal");
                if (!_this.data.noNeedRelaunch && _user2.default.getUserId()) {
                    try {
                        var pages = getCurrentPages();
                        // eslint-disable-line
                                                var page = pages[pages.length - 1];
                        var route = page && page.route;
                        var args = page && page.options;
                        var url = "/" + (0, _path.makePath)(route, args);
                        _api2.default.reLaunch({
                            url: url
                        });
                    } catch (error) {}
                    // eslint-disable-line
                                }
            }).catch(function(err) {
                (0, _track.trackNormalData)({
                    action: "update_user_info_fail",
                    property: JSON.stringify(data),
                    label: err.detail.result
                });
                wx.showToast({
                    title: "登录失败，请稍候重试",
                    icon: "none",
                    duration: 2e3,
                    success: function success() {
                        (0, _path.redirectTo)("LoginIndex");
                    }
                });
            }).catch(function() {
                (0, _track.trackNormalData)({
                    action: "login_with_weixin_fail",
                    property: JSON.stringify(data.detail)
                });
            });
        },
        handleCloseModal: function handleCloseModal() {
            this.setData({
                autoShow: false
            });
            this.triggerEvent("closeLoginModal");
        },
        handleClickModal: function handleClickModal() {
            return;
        },
        handleGoToMobileLogin: function handleGoToMobileLogin() {
            var source = this.data.showLoginModalSource ? this.data.showLoginModalSource : defaultSource;
            (0, _track.trackNormalData)({
                property: "login_request",
                action: "click_to_login",
                label: source
            });
            (0, _path.navigateTo)("MobileLogin", {
                source: source,
                from: "login_modal"
            });
        }
    },
    computed: {
        show: function show(data) {
            var showLoginModal = data.showLoginModal, autoShow = data.autoShow;
            if (showLoginModal || autoShow) {
                var source = data.showLoginModalSource ? data.showLoginModalSource : defaultSource;
                (0, _track.trackNormalData)({
                    property: "login_request",
                    action: "impression",
                    label: source
                });
                return true;
            }
            return false;
        }
    },
    created: function created() {
        var _this2 = this;
        return _asyncToGenerator(/* */ _regenerator2.default.mark(function _callee() {
            return _regenerator2.default.wrap(function _callee$(_context) {
                while (1) {
                    switch (_context.prev = _context.next) {
                      case 0:
                        _context.next = 2;
                        return _api2.default.$instance.globalData.promise;

                      case 2:
                        if (_login2.default.canShowLoginModal() && !_this2.data.autoShow) {
                            _this2.setData({
                                autoShow: true
                            });
                        }

                      case 3:
                      case "end":
                        return _context.stop();
                    }
                }
            }, _callee, _this2);
        }))();
    }
});