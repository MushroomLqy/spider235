var _miniprogramComputed = require("./../../karin_npm/miniprogram-computed/miniprogram_dist/index.js");

var _miniprogramComputed2 = _interopRequireDefault(_miniprogramComputed);

var _page = require("../../utils/page");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

Component({
    behaviors: [ _miniprogramComputed2.default ],
    properties: {
        isRefreshing: {
            type: Boolean,
            default: false
        },
        isFetchingNoteList: {
            type: Boolean,
            default: false
        },
        isLoadMoreNoteList: {
            type: Boolean,
            default: false
        },
        scrollIntoView: {
            type: String,
            default: ""
        }
    },
    data: {
        firstTouchY: 0,
        touchYDelta: 0,
        triggerDistance: 100,
        scrollTopStatus: true,
        showPullDownLoading: false,
        scrollBottomStatus: false,
        bottomDistance: 1e3,
        isInitReachBottomObserver: false
    },
    computed: {
        scrollHeight: function scrollHeight() {
            var topSectionHeight = (0, _page.getTopSectionHeight)();
            return "calc(100vh - " + topSectionHeight + "px)";
        }
    },
    watch: {
        isRefreshing: function isRefreshing(newValue) {
            if (!newValue) {
                this.setData({
                    showPullDownLoading: false
                });
            }
        },
        isLoadMoreNoteList: function isLoadMoreNoteList(newValue, oldValue) {
            console.log(oldValue);
            if (oldValue) {
                this.setData({
                    scrollBottomStatus: false
                });
            }
        }
    },
    methods: {
        initReachBottomObserver: function initReachBottomObserver() {
            var _this = this;
            if (!this.createIntersectionObserver || this.data.isInitReachBottomObserver) {
                return;
            }
            this.data.isInitReachBottomObserver = true;
            try {
                this.createIntersectionObserver().relativeToViewport({
                    bottom: 10
                }).observe(".page-scroll-end", function() {
                    _this.triggerEvent("scrollBottom");
                });
            } catch (err) {
                console.warn("initReachBottomObserver error");
                // eslint-disable-line
                        }
        },
        handleScrollTop: function handleScrollTop() {
            this.setData({
                scrollTopStatus: true
            });
        },
        handleScrollBottom: function handleScrollBottom() {
            this.initReachBottomObserver();
            if (!this.data.scrollBottomStatus) {
                this.setData({
                    scrollBottomStatus: true
                });
            }
        },
        touchstart: function touchstart() {
            var ev = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            if (ev.touches && ev.touches.length > 0) {
                var touchobj = ev.touches[0];
                this.setData({
                    firstTouchY: parseInt(touchobj.clientY, 10)
                });
            }
        },
        touchmove: function touchmove() {
            var ev = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            if (ev.touches && ev.touches.length > 0) {
                var touchobj = ev.touches[0];
                var touchY = parseInt(touchobj.clientY, 10);
                this.setData({
                    touchYDelta: touchY - this.data.firstTouchY
                });
            }
        },
        touchend: function touchend() {
            // 根据下拉高度判断是否加载新数据
            if (this.data.touchYDelta >= this.data.triggerDistance && this.data.scrollTopStatus) {
                this.setData({
                    showPullDownLoading: true
                });
                this.triggerEvent("scrollPullDown");
            }
            // 检测是否离开了scrollTop
                        if (this.data.touchYDelta < 0 && this.data.scrollTopStatus) {
                this.setData({
                    scrollTopStatus: false
                });
            }
            // 根据是否上拉下判断是否加载新数据
                        if (this.data.touchYDelta < 0 && this.data.scrollBottomStatus) {
                this.triggerEvent("scrollBottom");
                this.setData({
                    scrollBottomStatus: false
                });
            }
            this.setData({
                firstTouchY: 0,
                touchYDelta: 0
            });
        }
    }
});