var _track = require("../../utils/track");

Component({
    properties: {
        launchAppParameter: String,
        authorId: String,
        otherInfo: String
    },
    data: {
        show: new Date().getTime() < 156528e7,
        showModal: false,
        source: "tfboys"
    },
    methods: {
        handleTapLaunchApp: function handleTapLaunchApp() {
            var _ref = this.data || {}, source = _ref.source, otherInfo = _ref.otherInfo;
            (0, _track.trackNormalData)({
                action: "launch_app",
                label: source,
                property: otherInfo
            });
        },
        handleLaunchAppSuccess: function handleLaunchAppSuccess() {
            var _ref2 = this.data || {}, source = _ref2.source, otherInfo = _ref2.otherInfo;
            (0, _track.trackNormalData)({
                action: "launch_app_success",
                label: source,
                property: otherInfo
            });
        },
        handleLaunchAppError: function handleLaunchAppError() {
            var _ref3 = this.data || {}, source = _ref3.source, otherInfo = _ref3.otherInfo;
            (0, _track.trackNormalData)({
                action: "launch_app_fail",
                label: source,
                property: otherInfo
            });
            this.setData({
                showModal: true
            });
        },
        handleCloseModal: function handleCloseModal() {
            this.setData({
                showModal: false
            });
        }
    }
});