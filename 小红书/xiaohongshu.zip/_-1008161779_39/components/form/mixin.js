Object.defineProperty(exports, "__esModule", {
    value: true
});

var _page = require("../../utils/page");

exports.default = Behavior({
    data: {
        marginTop: 0
    },
    ready: function ready() {
        var navigationBarInfo = (0, _page.getNavigationBarInfo)();
        if (!navigationBarInfo.canCustom) {
            return;
        }
        if (!navigationBarInfo.noShow) {
            this.setData({
                marginTop: (0, _page.getTopSectionHeight)() + "px"
            });
        }
    }
});