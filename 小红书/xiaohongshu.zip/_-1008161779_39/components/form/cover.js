var _mixin = require("./mixin");

var _mixin2 = _interopRequireDefault(_mixin);

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

Component({
    behaviors: [ _mixin2.default ]
});