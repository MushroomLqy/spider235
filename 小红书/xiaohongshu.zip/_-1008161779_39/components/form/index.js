var _mixin = require("./mixin");

var _mixin2 = _interopRequireDefault(_mixin);

var _enum = require("../../utils/enum");

var _track = require("../../utils/track");

var _api = require("../../utils/api");

var _api2 = _interopRequireDefault(_api);

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

Component({
    behaviors: [ _mixin2.default ],
    properties: {
        buttonClass: {
            type: String,
            default: ""
        },
        fromSource: {
            type: String,
            default: "default"
        },
        formData: {
            type: Object
        }
    },
    data: {
        isTaped: false
    },
    methods: {
        reset: function reset() {
            this.setData({
                isTaped: false
            });
        },
        handleForm: function handleForm() {
            return;
        },
        submit: function submit(e) {
            var userInfo = _api2.default.getStorageSync(_enum.STORAGE_KEY.USER_INFO);
            var eventName = "submit";
            var formId = e.detail.formId;
            userInfo = userInfo || {};
            if (this.data.isTaped || !userInfo.sid || formId === "the formId is a mock one") {
                this.triggerEvent(eventName, this.formData);
                return;
            }
            this.setData({
                isTaped: true
            });
            // collectFormId(formId)
                        (0, _track.trackNormalData)({
                action: "collect_form_id",
                label: this.data.fromSource
            });
            this.triggerEvent(eventName, this.data.formData);
        }
    }
});