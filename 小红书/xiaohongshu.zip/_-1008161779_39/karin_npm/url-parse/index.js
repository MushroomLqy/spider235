module.exports = function(o) {
    var n = {};
    function r(e) {
        if (n[e]) return n[e].exports;
        var t = n[e] = {
            i: e,
            l: !1,
            exports: {}
        };
        return o[e].call(t.exports, t, t.exports, r), t.l = !0, t.exports;
    }
    return r.m = o, r.c = n, r.d = function(e, t, o) {
        r.o(e, t) || Object.defineProperty(e, t, {
            enumerable: !0,
            get: o
        });
    }, r.r = function(e) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        });
    }, r.t = function(t, e) {
        if (1 & e && (t = r(t)), 8 & e) return t;
        if (4 & e && "object" == typeof t && t && t.__esModule) return t;
        var o = Object.create(null);
        if (r.r(o), Object.defineProperty(o, "default", {
            enumerable: !0,
            value: t
        }), 2 & e && "string" != typeof t) for (var n in t) r.d(o, n, function(e) {
            return t[e];
        }.bind(null, n));
        return o;
    }, r.n = function(e) {
        var t = e && e.__esModule ? function() {
            return e.default;
        } : function() {
            return e;
        };
        return r.d(t, "a", t), t;
    }, r.o = function(e, t) {
        return Object.prototype.hasOwnProperty.call(e, t);
    }, r.p = "", r(r.s = "./node_modules/url-parse/index.js");
}({
    "../../../../usr/local/lib/node_modules/@xhs/karin-cli/node_modules/webpack/buildin/global.js": 
    /*!***********************************!*\
  !*** (webpack)/buildin/global.js ***!
  \***********************************/
    /*! no static exports found */ function(e, t) {
        function o(e) {
            return (o = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                return typeof e;
            } : function(e) {
                return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
            })(e);
        }
        var n = function() {
            return this;
        }();
        try {
            n = n || new Function("return this")();
        } catch (e) {
            "object" === ("undefined" == typeof window ? "undefined" : o(window)) && (n = window);
        }
        e.exports = n;
    },
    "./node_modules/querystringify/index.js": 
    /*!**********************************************!*\
  !*** ./node_modules/querystringify/index.js ***!
  \**********************************************/
    /*! no static exports found */ function(e, t, o) {
        "use strict";
        var s = Object.prototype.hasOwnProperty;
        function i(e) {
            return decodeURIComponent(e.replace(/\+/g, " "));
        }
        t.stringify = function(e, t) {
            var o, n, r = [];
            for (n in "string" != typeof (t = t || "") && (t = "?"), e) s.call(e, n) && ((o = e[n]) || null != o && !isNaN(o) || (o = ""), 
            r.push(encodeURIComponent(n) + "=" + encodeURIComponent(o)));
            return r.length ? t + r.join("&") : "";
        }, t.parse = function(e) {
            for (var t = /([^=?&]+)=?([^&]*)/g, o = {}; r = t.exec(e); ) {
                var n = i(r[1]), r = i(r[2]);
                n in o || (o[n] = r);
            }
            return o;
        };
    },
    "./node_modules/requires-port/index.js": 
    /*!*********************************************!*\
  !*** ./node_modules/requires-port/index.js ***!
  \*********************************************/
    /*! no static exports found */ function(e, t, o) {
        "use strict";
        e.exports = function(e, t) {
            if (t = t.split(":")[0], !(e = +e)) return !1;
            switch (t) {
              case "http":
              case "ws":
                return 80 !== e;

              case "https":
              case "wss":
                return 443 !== e;

              case "ftp":
                return 21 !== e;

              case "gopher":
                return 70 !== e;

              case "file":
                return !1;
            }
            return 0 !== e;
        };
    },
    "./node_modules/url-parse/index.js": 
    /*!*****************************************!*\
  !*** ./node_modules/url-parse/index.js ***!
  \*****************************************/
    /*! no static exports found */ function(e, t, o) {
        "use strict";
        !function(r) {
            function f(e) {
                return (f = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                    return typeof e;
                } : function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
                })(e);
            }
            var h = o(/*! requires-port */ "./node_modules/requires-port/index.js"), d = o(/*! querystringify */ "./node_modules/querystringify/index.js"), t = /^([a-z][a-z0-9.+-]*:)?(\/\/)?([\S\s]*)/i, s = /^[A-Za-z][A-Za-z0-9+-.]*:\/\//, y = [ [ "#", "hash" ], [ "?", "query" ], function(e) {
                return e.replace("\\", "/");
            }, [ "/", "pathname" ], [ "@", "auth", 1 ], [ NaN, "host", void 0, 1, 1 ], [ /:(\d+)$/, "port", void 0, 1 ], [ NaN, "hostname", void 0, 1, 1 ] ], i = {
                hash: 1,
                query: 1
            };
            function m(e) {
                var t, o = "undefined" != typeof window ? window : void 0 !== r ? r : "undefined" != typeof self ? self : {}, o = o.location || {}, n = {}, o = f(e = e || o);
                if ("blob:" === e.protocol) n = new g(unescape(e.pathname), {}); else if ("string" === o) for (t in n = new g(e, {}), 
                i) delete n[t]; else if ("object" === o) {
                    for (t in e) t in i || (n[t] = e[t]);
                    void 0 === n.slashes && (n.slashes = s.test(e.href));
                }
                return n;
            }
            function b(e) {
                e = t.exec(e);
                return {
                    protocol: e[1] ? e[1].toLowerCase() : "",
                    slashes: !!e[2],
                    rest: e[3]
                };
            }
            function g(e, t, o) {
                if (!(this instanceof g)) return new g(e, t, o);
                var n, r, s, i, a, u = y.slice(), l = f(t), c = this, p = 0;
                for ("object" !== l && "string" !== l && (o = t, t = null), o && "function" != typeof o && (o = d.parse), 
                t = m(t), n = !(l = b(e || "")).protocol && !l.slashes, c.slashes = l.slashes || n && t.slashes, 
                c.protocol = l.protocol || t.protocol || "", e = l.rest, l.slashes || (u[3] = [ /(.*)/, "pathname" ]); p < u.length; p++) "function" != typeof (s = u[p]) ? (r = s[0], 
                a = s[1], r != r ? c[a] = e : "string" == typeof r ? ~(i = e.indexOf(r)) && (e = "number" == typeof s[2] ? (c[a] = e.slice(0, i), 
                e.slice(i + s[2])) : (c[a] = e.slice(i), e.slice(0, i))) : (i = r.exec(e)) && (c[a] = i[1], 
                e = e.slice(0, i.index)), c[a] = c[a] || n && s[3] && t[a] || "", s[4] && (c[a] = c[a].toLowerCase())) : e = s(e);
                o && (c.query = o(c.query)), n && t.slashes && "/" !== c.pathname.charAt(0) && ("" !== c.pathname || "" !== t.pathname) && (c.pathname = function(e, t) {
                    for (var o = (t || "/").split("/").slice(0, -1).concat(e.split("/")), n = o.length, e = o[n - 1], r = !1, s = 0; n--; ) "." === o[n] ? o.splice(n, 1) : ".." === o[n] ? (o.splice(n, 1), 
                    s++) : s && (0 === n && (r = !0), o.splice(n, 1), s--);
                    return r && o.unshift(""), "." !== e && ".." !== e || o.push(""), o.join("/");
                }(c.pathname, t.pathname)), h(c.port, c.protocol) || (c.host = c.hostname, c.port = ""), 
                c.username = c.password = "", c.auth && (s = c.auth.split(":"), c.username = s[0] || "", 
                c.password = s[1] || ""), c.origin = c.protocol && c.host && "file:" !== c.protocol ? c.protocol + "//" + c.host : "null", 
                c.href = c.toString();
            }
            g.prototype = {
                set: function(e, t, o) {
                    var n, r = this;
                    switch (e) {
                      case "query":
                        "string" == typeof t && t.length && (t = (o || d.parse)(t)), r[e] = t;
                        break;

                      case "port":
                        r[e] = t, h(t, r.protocol) ? t && (r.host = r.hostname + ":" + t) : (r.host = r.hostname, 
                        r[e] = "");
                        break;

                      case "hostname":
                        r[e] = t, r.port && (t += ":" + r.port), r.host = t;
                        break;

                      case "host":
                        r[e] = t, /:\d+$/.test(t) ? (t = t.split(":"), r.port = t.pop(), r.hostname = t.join(":")) : (r.hostname = t, 
                        r.port = "");
                        break;

                      case "protocol":
                        r.protocol = t.toLowerCase(), r.slashes = !o;
                        break;

                      case "pathname":
                      case "hash":
                        t ? (n = "pathname" === e ? "/" : "#", r[e] = t.charAt(0) !== n ? n + t : t) : r[e] = t;
                        break;

                      default:
                        r[e] = t;
                    }
                    for (var s = 0; s < y.length; s++) {
                        var i = y[s];
                        i[4] && (r[i[1]] = r[i[1]].toLowerCase());
                    }
                    return r.origin = r.protocol && r.host && "file:" !== r.protocol ? r.protocol + "//" + r.host : "null", 
                    r.href = r.toString(), r;
                },
                toString: function(e) {
                    e && "function" == typeof e || (e = d.stringify);
                    var t = this, o = t.protocol;
                    return o && ":" !== o.charAt(o.length - 1) && (o += ":"), o += t.slashes ? "//" : "", 
                    t.username && (o += t.username, t.password && (o += ":" + t.password), o += "@"), 
                    o += t.host + t.pathname, (e = "object" === f(t.query) ? e(t.query) : t.query) && (o += "?" !== e.charAt(0) ? "?" + e : e), 
                    t.hash && (o += t.hash), o;
                }
            }, g.extractProtocol = b, g.location = m, g.qs = d, e.exports = g;
        }.call(this, o(/*! ./../../../../../../usr/local/lib/node_modules/@xhs/karin-cli/node_modules/webpack/buildin/global.js */ "../../../../usr/local/lib/node_modules/@xhs/karin-cli/node_modules/webpack/buildin/global.js"));
    }
});