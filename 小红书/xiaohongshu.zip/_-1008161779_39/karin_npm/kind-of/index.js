module.exports = function(e) {
    var n = {};
    function o(r) {
        if (n[r]) return n[r].exports;
        var t = n[r] = {
            i: r,
            l: !1,
            exports: {}
        };
        return e[r].call(t.exports, t, t.exports, o), t.l = !0, t.exports;
    }
    return o.m = e, o.c = n, o.d = function(r, t, e) {
        o.o(r, t) || Object.defineProperty(r, t, {
            enumerable: !0,
            get: e
        });
    }, o.r = function(r) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(r, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(r, "__esModule", {
            value: !0
        });
    }, o.t = function(t, r) {
        if (1 & r && (t = o(t)), 8 & r) return t;
        if (4 & r && "object" == typeof t && t && t.__esModule) return t;
        var e = Object.create(null);
        if (o.r(e), Object.defineProperty(e, "default", {
            enumerable: !0,
            value: t
        }), 2 & r && "string" != typeof t) for (var n in t) o.d(e, n, function(r) {
            return t[r];
        }.bind(null, n));
        return e;
    }, o.n = function(r) {
        var t = r && r.__esModule ? function() {
            return r.default;
        } : function() {
            return r;
        };
        return o.d(t, "a", t), t;
    }, o.o = function(r, t) {
        return Object.prototype.hasOwnProperty.call(r, t);
    }, o.p = "", o(o.s = "./node_modules/kind-of/index.js");
}({
    "./node_modules/kind-of/index.js": 
    /*!***************************************!*\
  !*** ./node_modules/kind-of/index.js ***!
  \***************************************/
    /*! no static exports found */ function(r, t) {
        function n(r) {
            return (n = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(r) {
                return typeof r;
            } : function(r) {
                return r && "function" == typeof Symbol && r.constructor === Symbol && r !== Symbol.prototype ? "symbol" : typeof r;
            })(r);
        }
        var o = Object.prototype.toString;
        function a(r) {
            return r.constructor ? r.constructor.name : null;
        }
        r.exports = function(r) {
            if (void 0 === r) return "undefined";
            if (null === r) return "null";
            var t, e = n(r);
            if ("boolean" === e) return "boolean";
            if ("string" === e) return "string";
            if ("number" === e) return "number";
            if ("symbol" === e) return "symbol";
            if ("function" === e) return "GeneratorFunction" === a(r) ? "generatorfunction" : "function";
            if (t = r, Array.isArray ? Array.isArray(t) : t instanceof Array) return "array";
            if (function(r) {
                if (r.constructor && "function" == typeof r.constructor.isBuffer) return r.constructor.isBuffer(r);
                return !1;
            }(r)) return "buffer";
            if (function(r) {
                try {
                    if ("number" == typeof r.length && "function" == typeof r.callee) return !0;
                } catch (r) {
                    if (-1 !== r.message.indexOf("callee")) return !0;
                }
                return !1;
            }(r)) return "arguments";
            if ((t = r) instanceof Date || "function" == typeof t.toDateString && "function" == typeof t.getDate && "function" == typeof t.setDate) return "date";
            if ((t = r) instanceof Error || "string" == typeof t.message && t.constructor && "number" == typeof t.constructor.stackTraceLimit) return "error";
            if ((t = r) instanceof RegExp || "string" == typeof t.flags && "boolean" == typeof t.ignoreCase && "boolean" == typeof t.multiline && "boolean" == typeof t.global) return "regexp";
            switch (a(r)) {
              case "Symbol":
                return "symbol";

              case "Promise":
                return "promise";

              case "WeakMap":
                return "weakmap";

              case "WeakSet":
                return "weakset";

              case "Map":
                return "map";

              case "Set":
                return "set";

              case "Int8Array":
                return "int8array";

              case "Uint8Array":
                return "uint8array";

              case "Uint8ClampedArray":
                return "uint8clampedarray";

              case "Int16Array":
                return "int16array";

              case "Uint16Array":
                return "uint16array";

              case "Int32Array":
                return "int32array";

              case "Uint32Array":
                return "uint32array";

              case "Float32Array":
                return "float32array";

              case "Float64Array":
                return "float64array";
            }
            if ("function" == typeof (t = r).throw && "function" == typeof t.return && "function" == typeof t.next) return "generator";
            switch (e = o.call(r)) {
              case "[object Object]":
                return "object";

              case "[object Map Iterator]":
                return "mapiterator";

              case "[object Set Iterator]":
                return "setiterator";

              case "[object String Iterator]":
                return "stringiterator";

              case "[object Array Iterator]":
                return "arrayiterator";
            }
            return e.slice(8, -1).toLowerCase().replace(/\s/g, "");
        };
    }
});