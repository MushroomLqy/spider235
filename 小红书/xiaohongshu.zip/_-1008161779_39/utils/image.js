Object.defineProperty(exports, "__esModule", {
    value: true
});

var Domain = "xiaohongshu.com";

var Protocol = "http://";

var nomalImageHostRegex = /(https?):\/\/(img|ci)\.xiaohongshu\.com\//;

var newImageHostRegex = /(https?):\/\/sns-img-(qc|ws|qn|bd|up)\.xhscdn\.com\//;

var IMAGE_SOURCE_TYPE = exports.IMAGE_SOURCE_TYPE = {
    IMG_SOURCE: "img",
    CI_SOURCE: "ci"
};

var replaceProtocol = exports.replaceProtocol = function replaceProtocol(url) {
    url = url || "";
    return url.replace(/https?:\/\//, "");
};

var isCiUrl = exports.isCiUrl = function isCiUrl(url) {
    url = url || "";
    return /ci\.xiaohongshu\.com/.test(url);
};

var isImageUrl = exports.isImageUrl = function isImageUrl(url) {
    url = url || "";
    return /img\.xiaohongshu\.com/.test(url);
};

var replaceImageOrigin = exports.replaceImageOrigin = function replaceImageOrigin() {
    var url = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
    var result = url;
    if (nomalImageHostRegex.test(url)) {
        result = result.replace(nomalImageHostRegex, "");
    } else if (newImageHostRegex.test(url)) {
        result = result.replace(newImageHostRegex, "");
    }
    return result;
};

var getImageId = exports.getImageId = function getImageId() {
    var url = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
    var isRelativePath = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
    var newUrl = url;
    if (!isRelativePath) {
        newUrl = replaceImageOrigin(newUrl);
    }
    var id = newUrl.substr(0, 36);
    return id;
};

var getCiUrlById = exports.getCiUrlById = function getCiUrlById(id) {
    return IMAGE_SOURCE_TYPE.CI_SOURCE + "." + Domain + "/" + id;
};

var getCiUrl = exports.getCiUrl = function getCiUrl(options) {
    options = options || {};
    var _options = options, width = _options.width, height = _options.height, url = _options.url, quality = _options.quality, abbrevType = _options.abbrevType, isMogr2 = _options.isMogr2, scale = _options.scale, blur = _options.blur;
    var host = IMAGE_SOURCE_TYPE.CI_SOURCE + "." + Domain + "/";
    quality = quality || 92;
    url = replaceProtocol(url);
    url = url.replace(host, "");
    var id = getImageId(url, true);
    var arr = [];
    if (isMogr2) {
        if (scale) {
            arr.push("/thumbnail/!" + scale + "p");
        }
        if (blur) {
            arr.push("/blur/" + blur.radius + "x" + blur.sigma);
        }
        arr.push("/quality/" + quality);
        return "" + Protocol + host + id + "?imageMogr2" + arr.join("");
    }
    if (width) {
        arr.push("/w/" + width);
    }
    if (height) {
        arr.push("/h/" + height);
    }
    arr.push("/q/" + quality);
    abbrevType = abbrevType || 0;
    return "" + Protocol + host + id + "?imageView2/" + abbrevType + "/" + arr.join("");
};

var getFormatedUrl = exports.getFormatedUrl = function getFormatedUrl(options) {
    options = options || {};
    var _options2 = options, url = _options2.url;
    url = replaceProtocol(url);
    url = "https://" + url;
    // if (isCiUrl(url)) {
    //   url = getCiUrl(options)
    // }
        return url;
};