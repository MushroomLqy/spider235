Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function() {
    function defineProperties(target, props) {
        for (var i = 0; i < props.length; i++) {
            var descriptor = props[i];
            descriptor.enumerable = descriptor.enumerable || false;
            descriptor.configurable = true;
            if ("value" in descriptor) descriptor.writable = true;
            Object.defineProperty(target, descriptor.key, descriptor);
        }
    }
    return function(Constructor, protoProps, staticProps) {
        if (protoProps) defineProperties(Constructor.prototype, protoProps);
        if (staticProps) defineProperties(Constructor, staticProps);
        return Constructor;
    };
}();

var _track = require("./track");

function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}

var Image = function() {
    function Image() {
        _classCallCheck(this, Image);
        this.imageInfoCache = {};
        this.cdnOrigin = "https://ci.xiaohongshu.com/";
    }
    _createClass(Image, [ {
        key: "privateGetImageInfo",
        value: function privateGetImageInfo() {
            var url = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
            var timeout = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
            return new Promise(function(resolve, reject) {
                var clock = void 0;
                if (timeout) {
                    clock = setTimeout(function() {
                        reject();
                    }, 3e3);
                }
                wx.getImageInfo({
                    src: url,
                    success: function success(res) {
                        if (clock) {
                            clearTimeout(clock);
                        }
                        resolve(res);
                    },
                    fail: function fail() {
                        if (clock) {
                            clearTimeout(clock);
                        }
                        reject({});
                        (0, _track.trackNormalData)({
                            action: "get_image_info_error",
                            property: url
                        });
                    }
                });
            });
        }
    }, {
        key: "getImageInfo",
        value: function getImageInfo() {
            var image = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            var imageInfoCache = this.imageInfoCache, cdnOrigin = this.cdnOrigin, privateGetImageInfo = this.privateGetImageInfo;
            return new Promise(function(resolve) {
                var pathId = image.pathId, width = image.width, path = image.path;
                if (path) {
                    privateGetImageInfo(path).then(function() {
                        var res = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
                        resolve(res);
                    });
                    return;
                }
                var key = width ? pathId + "_" + width : "" + pathId;
                // 检测有没有信息
                                if (imageInfoCache[key] && !imageInfoCache[key].isGetting) {
                    resolve(imageInfoCache[key].info);
                    return;
                }
                // 检测是否进入队列
                                if (imageInfoCache[key] && imageInfoCache[key].isGetting) {
                    imageInfoCache[key].queue.push(function(info) {
                        resolve(info);
                    });
                    return;
                }
                // 初始化
                                if (!imageInfoCache[key]) {
                    imageInfoCache[key] = {
                        queue: [],
                        info: {},
                        isGetting: true
                    };
                }
                var url = path ? path : "" + cdnOrigin + pathId;
                if (width && !path) {
                    url = url + "?imageView2/0//w/" + width;
                    console.log(url);
                }
                privateGetImageInfo(url).then(function() {
                    var res = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
                    var hasData = res.path;
                    imageInfoCache[key].isGetting = false;
                    res.url = url;
                    imageInfoCache[key].info = res;
                    imageInfoCache[key].queue.forEach(function(callback) {
                        callback(res);
                    });
                    imageInfoCache[key].queue = [];
                    if (!hasData) {
                        delete imageInfoCache[key];
                    }
                    resolve(res);
                });
            });
        }
    } ]);
    return Image;
}();

exports.default = new Image();