Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.getStorage = getStorage;

exports.getStorageSync = getStorageSync;

exports.setStorageSync = setStorageSync;

exports.setStorage = setStorage;

var _api = require("./api");

var _api2 = _interopRequireDefault(_api);

var _enum = require("../utils/enum");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

var isObject = function isObject(value) {
    // eslint-disable-line
    return Object.prototype.toString.call(value) === "[object Object]";
};

function getStorage() {
    var key = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
    return _getStorage(key, false);
    // eslint-disable-line
}

function getStorageSync() {
    var key = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
    return _getStorage(key, true);
    // eslint-disable-line
}

var _getStorage = function _getStorage() {
    var key = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
    var isSync = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
    // eslint-disable-line
        var _key = _enum.STORAGE_KEY[key];
    // eslint-disable-line
        if (!_key) {
        throw new Error("not find this key " + key + " in STORAGE_KEY");
        return;
        // eslint-disable-line
        }
    var now = Date.parse(new Date());
    if (isSync) {
        var cacheData = _api2.default.getStorageSync(_key);
        if (isObject(cacheData)) {
            var expire = cacheData.expire, data = cacheData.data;
            // 处理是否过期
                        if (expire !== 0 && expire < now) {
                return;
            } else {
                return data;
            }
        } else {
            return cacheData;
        }
    } else {
        return _api2.default.getStorage({
            key: _key
        }).then(function(res) {
            var cacheData = res.data;
            if (res.data) {
                if (isObject(cacheData)) {
                    var _expire2 = cacheData.expire, _data = cacheData.data;
                    // 处理是否过期
                                        if (_expire2 !== 0 && _expire2 < now) {
                        return;
                    } else {
                        return _data;
                    }
                } else {
                    return cacheData;
                }
            } else {
                return;
            }
        });
    }
};

var _setStorage = function _setStorage() {
    var key = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
    var data = arguments[1];
    var expire = arguments[2];
    var isSync = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : true;
    // eslint-disable-line
        var targetKey = _enum.STORAGE_KEY[key];
    var saveData = {
        expire: expire,
        data: data
    };
    if (!targetKey) {
        throw new Error("not find this key " + key + " in STORAGE_KEY");
    }
    if (isSync) {
        return _api2.default.setStorageSync(targetKey, saveData);
    }
    return _api2.default.setStorage({
        key: targetKey,
        data: saveData
    });
};

var parseExpire = function parseExpire(expireHours) {
    if (isNaN(expireHours)) {
        return 0;
    }
    return expireHours * 60 * 60 * 1e3 + Date.parse(new Date());
};

function setStorageSync(_ref) {
    var key = _ref.key, data = _ref.data, expireHours = _ref.expireHours;
    var _expire = parseExpire(expireHours);
    return _setStorage(key, data, _expire, true);
}

function setStorage(_ref2) {
    var key = _ref2.key, data = _ref2.data, expireHours = _ref2.expireHours;
    var _expire = parseExpire(expireHours);
    return _setStorage(key, data, _expire, false);
}