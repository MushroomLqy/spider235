Object.defineProperty(exports, "__esModule", {
    value: true
});

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function(obj) {
    return typeof obj;
} : function(obj) {
    return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
};

var _createClass = function() {
    function defineProperties(target, props) {
        for (var i = 0; i < props.length; i++) {
            var descriptor = props[i];
            descriptor.enumerable = descriptor.enumerable || false;
            descriptor.configurable = true;
            if ("value" in descriptor) descriptor.writable = true;
            Object.defineProperty(target, descriptor.key, descriptor);
        }
    }
    return function(Constructor, protoProps, staticProps) {
        if (protoProps) defineProperties(Constructor.prototype, protoProps);
        if (staticProps) defineProperties(Constructor, staticProps);
        return Constructor;
    };
}();

exports.dateStringToTimestamp = dateStringToTimestamp;

function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}

var TIMEZONE = "+08:00";

var DAY = 864e5;

var HOUR = 36e5;

var MINUTE = 6e4;

var SECOND = 1e3;

var DATE_TIME_MASKS = {
    default: "YYYY-MM-DD HH:mm:ss",
    shortTime: "mm:ss",
    mediumTime: "HH:mm:ss",
    longTime: "DD HH:mm:ss"
};

var TIME_MASKS = {
    shortTime: "mm: ss",
    mediumTimeDistance: "距离结束还有 HH: mm: ss",
    mediumTimeRemain: "还剩HH小时mm分ss秒",
    longTime: "还剩D天HH小时mm分ss秒"
};

var REGTOVALUE = {
    "D+": "days",
    "H+": "hours",
    "m+": "minutes",
    "s+": "seconds"
};

var DateTimeFormatter = function() {
    function DateTimeFormatter(fmt, timezone) {
        _classCallCheck(this, DateTimeFormatter);
        this.fmt = DATE_TIME_MASKS[fmt] || fmt;
        this.timezone = timezone;
        /**
     * 参数说明
     * '/u65e5'  日
     * '/u4e00'  一
     * '/u4e8c'  二
     * '/u4e09'  三
     * '/u56db'  四
     * '/u4e94'  五
     * '/u516d'  六
     * '/u661f'  星
     * '/u671f'  期
     * '/u5468'  周
     */        this.week = {
            0: "/u65e5",
            1: "/u4e00",
            2: "/u4e8c",
            3: "/u4e09",
            4: "/u56db",
            5: "/u4e94",
            6: "/u516d"
        };
    }
    _createClass(DateTimeFormatter, [ {
        key: "getODate",
        value: function getODate(date) {
            return {
                "M+": {
                    regexp: /(M+)/,
                    value: date.getMonth() + 1
                },
                "D+": {
                    regexp: /(D+)/,
                    value: date.getDate()
                },
                "h+": {
                    regexp: /(h+)/,
                    value: date.getHours() % 12 === 0 ? 12 : date.getHours() % 12
                },
                "H+": {
                    regexp: /(H+)/,
                    value: date.getHours()
                },
                "m+": {
                    regexp: /(m+)/,
                    value: date.getMinutes()
                },
                "s+": {
                    regexp: /(s+)/,
                    value: date.getSeconds()
                },
                "q+": {
                    regexp: /(q+)/,
                    value: Math.floor((date.getMonth() + 3) / 3)
                },
                S: {
                    regexp: /(S)/,
                    value: date.getMilliseconds()
                }
            };
        }
    }, {
        key: "normalize",
        value: function normalize(val) {
            // 判断isNaN(Number(tm)) 判断undefined 判断null
            if (isNaN(Number(val)) || Object.prototype.toString.call(val) === "[object Null]") {
                throw new Error("Wrong parameter: dateSource " + val);
            }
            if (val instanceof Date) {
                return val;
            } else {
                var timestamp = this.adjustTimezone(val * SECOND, this.timezone);
                return new Date(timestamp);
            }
        }
    }, {
        key: "adjustTimezone",
        value: function adjustTimezone(timestamp) {
            var zoneOffset = Number(this.timezone.replace(":00", "")) * (MINUTE / SECOND);
            return timestamp + (new Date().getTimezoneOffset() + zoneOffset) * MINUTE;
        }
    }, {
        key: "format",
        value: function format(source) {
            var date = this.normalize(source);
            var oDate = this.getODate(date);
            if (/(Y+)/.test(this.fmt)) {
                this.fmt = this.fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
            }
            if (/(E+)/.test(this.fmt)) {
                this.fmt = this.fmt.replace(RegExp.$1, (RegExp.$1.length > 1 ? RegExp.$1.length > 2 ? "/u661f/u671f" : "/u5468" : "") + this.week[date.getDay() + ""]);
            }
            for (var k in oDate) {
                if (oDate[k].regexp.test(this.fmt)) {
                    this.fmt = this.fmt.replace(RegExp.$1, RegExp.$1.length === 1 ? oDate[k].value : ("00" + oDate[k].value).substr(("" + oDate[k].value).length));
                }
            }
            return this.fmt;
        }
    } ]);
    return DateTimeFormatter;
}();

var TimeFormatter = function() {
    function TimeFormatter(fmt) {
        _classCallCheck(this, TimeFormatter);
        this.fmt = TIME_MASKS[fmt] || fmt;
    }
    _createClass(TimeFormatter, [ {
        key: "getOTime",
        value: function getOTime(timestamp) {
            var timestampObject = this.getTimestampObject(timestamp);
            return {
                "D+": {
                    regexp: /(D+)/,
                    value: timestampObject.days
                },
                "H+": {
                    regexp: /(H+)/,
                    value: timestampObject.hours
                },
                "m+": {
                    regexp: /(m+)/,
                    value: timestampObject.minutes
                },
                "s+": {
                    regexp: /(s+)/,
                    value: timestampObject.seconds
                }
            };
        }
    }, {
        key: "getTimestampObject",
        value: function getTimestampObject(timestamp) {
            return {
                days: Math.floor(timestamp / DAY),
                hours: Math.floor(timestamp % DAY / HOUR),
                minutes: Math.floor(timestamp % HOUR / MINUTE),
                seconds: Math.floor(timestamp % MINUTE / SECOND)
            };
        }
    }, {
        key: "getAutoFmt",
        value: function getAutoFmt() {
            var fmtArrs = TimeFormatter.splitFmt(this.fmt);
            var outputArr = [];
            var isFirst = true;
            var length = fmtArrs.length;
            var timestampObject = this.getTimestampObject(this.timestamp);
            for (var i = 0; i < length; ) {
                var item = fmtArrs[i];
                var isMatch = TimeFormatter.isMatch(item);
                var time = timestampObject[TimeFormatter.searchKey(item)];
                if (!isMatch && i === 0) {
                    outputArr.push(item);
                    i++;
                    continue;
                }
                if (isFirst && isMatch) {
                    if (time === 0 && length - i > 2) {
                        if (TimeFormatter.isMatch(fmtArrs[i + 1])) {
                            i++;
                        } else {
                            i += 2;
                        }
                        continue;
                    } else {
                        i++;
                        isFirst = false;
                        outputArr.push(time);
                        continue;
                    }
                }
                if (isMatch) {
                    outputArr.push(("00" + timestampObject[TimeFormatter.searchKey(item)]).slice(-item.length));
                    i++;
                    continue;
                }
                outputArr.push(item);
                i++;
            }
            return outputArr.join("");
        }
    }, {
        key: "format",
        value: function format(source, auto, fmtArray) {
            this.timestamp = TimeFormatter.normalize(source);
            if (fmtArray) {
                var fmtArrs = TimeFormatter.splitFmt(this.fmt);
                var timestampObject = this.getTimestampObject(this.timestamp);
                var arr = [];
                fmtArrs.forEach(function(item) {
                    if (TimeFormatter.isMatch(item)) {
                        arr.push({
                            key: item,
                            value: ("00" + timestampObject[TimeFormatter.searchKey(item)]).slice(-item.length)
                        });
                    } else {
                        arr.push({
                            key: "separator",
                            value: item
                        });
                    }
                });
                return arr;
            }
            if (!auto) {
                var oTime = this.getOTime(this.timestamp);
                for (var k in oTime) {
                    if (oTime[k].regexp.test(this.fmt)) {
                        this.fmt = this.fmt.replace(RegExp.$1, RegExp.$1.length === 1 ? oTime[k].value : ("00" + oTime[k].value).substr(("" + oTime[k].value).length));
                    }
                }
                return this.fmt;
            } else {
                return this.getAutoFmt();
            }
        }
    } ], [ {
        key: "normalize",
        value: function normalize(val) {
            // 判断isNaN(Number(val)) 判断undefined 判断object(null)
            if (isNaN(Number(val)) || (typeof val === "undefined" ? "undefined" : _typeof(val)) === "object") {
                throw new Error("Wrong parameter: dateSource " + val);
            }
            return Number(val);
        }
    }, {
        key: "isMatch",
        value: function isMatch(value) {
            return /D+|H+|m+|s+/g.test(value);
        }
    }, {
        key: "splitFmt",
        value: function splitFmt(fmt) {
            return fmt.match(/D+|H+|m+|s+|[^D+|H+|m+|s+]+/g);
        }
    }, {
        key: "searchKey",
        value: function searchKey(value) {
            var output = "";
            for (var key in REGTOVALUE) {
                if (Object.prototype.hasOwnProperty.call(REGTOVALUE, key)) {
                    var reg = RegExp("" + key, "g");
                    if (reg.test(value)) {
                        output = REGTOVALUE[key];
                    }
                }
            }
            return output;
        }
    } ]);
    return TimeFormatter;
}();

var formatDateTime = function formatDateTime(dateSource) {
    var fmt = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "default";
    var timezone = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : TIMEZONE;
    var dateUtil = new DateTimeFormatter(fmt, timezone);
    return dateUtil.format(dateSource);
};

var formatTime = function formatTime(dateSource) {
    var fmt = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "shortTime";
    var _ref = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {}, _ref$auto = _ref.auto, auto = _ref$auto === undefined ? false : _ref$auto, fmtArray = _ref.fmtArray;
    var dateUtil = new TimeFormatter(fmt);
    return dateUtil.format(dateSource, auto, fmtArray);
};

// format dateString as '2017-02-13 12:22' to timestamp
function dateStringToTimestamp() {
    var str = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
    var zone = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : TIMEZONE;
    return new Date(str.trim().replace(" ", "T") + ("" + zone)).getTime();
}

exports.default = {
    formatDateTime: formatDateTime,
    formatTime: formatTime
};