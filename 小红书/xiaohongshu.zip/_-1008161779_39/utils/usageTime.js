Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function() {
    function defineProperties(target, props) {
        for (var i = 0; i < props.length; i++) {
            var descriptor = props[i];
            descriptor.enumerable = descriptor.enumerable || false;
            descriptor.configurable = true;
            if ("value" in descriptor) descriptor.writable = true;
            Object.defineProperty(target, descriptor.key, descriptor);
        }
    }
    return function(Constructor, protoProps, staticProps) {
        if (protoProps) defineProperties(Constructor.prototype, protoProps);
        if (staticProps) defineProperties(Constructor, staticProps);
        return Constructor;
    };
}();

function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}

var UsageTime = function() {
    function UsageTime() {
        _classCallCheck(this, UsageTime);
        this.startTime = 0;
        this.usageInterval = null;
        this.usageTime = 0;
    }
    _createClass(UsageTime, [ {
        key: "start",
        value: function start() {
            var _this = this;
            this.startTime = new Date().getTime() / 1e3;
            this.usageTime = 0;
            if (this.usageInterval) {
                clearInterval(this.usageInterval);
            }
            this.usageInterval = setInterval(function() {
                _this.usageTime += 1;
            }, 1e3);
        }
    }, {
        key: "getUsageTime",
        value: function getUsageTime() {
            return this.usageTime;
        }
    }, {
        key: "isHealthy",
        value: function isHealthy() {
            // 当前时间和心跳检测时间误差超过5s, 则判定为死亡
            if (Math.abs(new Date().getTime() / 1e3 - this.startTime - this.usageTime) < 5) {
                return true;
            }
            return false;
        }
    }, {
        key: "close",
        value: function close() {
            clearInterval(this.usageInterval);
        }
    } ]);
    return UsageTime;
}();

exports.default = new UsageTime();