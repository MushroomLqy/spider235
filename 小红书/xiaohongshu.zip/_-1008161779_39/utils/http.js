Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.configure = exports.interceptors = exports.makeUri = exports.patch = exports.put = exports.post = exports.head = exports.del = exports.get = undefined;

var _api = require("./api");

var _api2 = _interopRequireDefault(_api);

var _http = require("../libs/@xhs/http");

var _http2 = _interopRequireDefault(_http);

var _deepClone = require("../libs/deep-clone");

var _deepClone2 = _interopRequireDefault(_deepClone);

var _enum = require("./enum");

var _path = require("../utils/path");

var _user = require("../utils/user");

var _user2 = _interopRequireDefault(_user);

var _verify = require("../utils/verify");

var _verify2 = _interopRequireDefault(_verify);

var _http3 = require("../http.config");

var _feApiSign = require("./fe-api-sign");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

/* adapts methods to handle req / res data in same format */ /* --------------------------------- */ var isRelaunching = false;

function processResponseData() {
    var res = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var data = res.data, statusCode = res.statusCode;
    return {
        data: data,
        statusCode: statusCode
    };
}

function processResponseError(err) {
    var response = err.response;
    var data = response && response.data || err.data;
    var statusCode = response && response.status || err.statusCode;
    var errorMsg = err.message || err.errMsg;
    var errorCode = err.code;
    return {
        data: data,
        statusCode: statusCode,
        errorMsg: errorMsg,
        errorCode: errorCode
    };
}

/* export methods */ /* --------------------------------- */ if (!_api2.default.hasMpApi()) {
    throw new Error("[Http Exception] could not found wepy instance");
}

var _sendRequest = function _sendRequest(config) {
    // eslint-disable-line
    var _ref = _api2.default.getStorageSync(_enum.STORAGE_KEY.USER_INFO) || {}, authorization = _ref.authorization;
    // 部分接口如登录不需要传 authorization
        var noAuthorization = [ _http3.config.API_LIST.LOGIN, _http3.config.API_LIST.MOBILE_LOGIN, _http3.config.API_LIST.CI_TOKEN ];
    var needAuthorization = true;
    noAuthorization.some(function(noAuthorizationItem) {
        if (config.url.indexOf(noAuthorizationItem) > -1) {
            needAuthorization = false;
            return true;
        }
    });
    if (authorization && needAuthorization) {
        if (config.header) {
            config.header["Authorization"] = authorization;
            // eslint-disable-line
                } else {
            config.header = {
                Authorization: authorization
            };
        }
    }
    if (config.url.indexOf(_feApiSign.DEFAULT_SIGN_API_PATH) > -1) {
        var feApiConfig = (0, _deepClone2.default)(config);
        config.header[_feApiSign.DEFAULT_SIGN_HEADER] = (0, _feApiSign.encryptFeApiToken)(feApiConfig);
        // eslint-disable-line
        }
    var wxRequestConfig = (0, _deepClone2.default)(config);
    return new Promise(function(resolve, reject) {
        wxRequestConfig.success = function() {
            var res = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            // 检测登录态是否失效
                        var data = res.data;
            if ((data.result === -100 || data.errCode === -100) && !isRelaunching) {
                isRelaunching = true;
                _user2.default.loginWithCode().then(function() {
                    isRelaunching = false;
                    _user2.default.ensureLogin().then(function() {
                        var result = _user2.default.getEagletUserInfo();
                        wx.$eaglet.resetABInfo(result);
                        _api2.default.reLaunch({
                            url: "/" + (0, _path.getPageUrl)().url
                        });
                    });
                }).catch(function() {
                    isRelaunching = false;
                });
                reject(res);
                return;
            }
            if (res.statusCode !== 200) {
                if (res.statusCode === 461) {
                    var verifyTypeStr = "sm";
                    console.log("###############", _verify2.default.canJumpToVerifyPage());
                    // eslint-disable-line
                                        if (_verify2.default.canJumpToVerifyPage()) {
                        _verify2.default.setDisableVerifyPage();
                        _verify2.default.setRelaunchBeforeVerifyPage();
                    }
                    _verify2.default.goToVerifyPage(verifyTypeStr);
                }
                reject(res);
            } else {
                var resData = res.data;
                // 返回data为string时，可能是解析空格时出错 需要替换
                                if (Object.prototype.toString.call(resData) === "[object String]" && resData[0] === "{" && resData[resData.length - 1] === "}") {
                    resData = resData.replace(/\s/g, "");
                    try {
                        res.data = JSON.parse(resData);
                    } catch (e) {}
                    // eslint-disable-line
                                }
                try {
                    res.data.requestUrl = config.url;
                } catch (err) {
                    console.error(err);
                    // eslint-disable-line
                                }
                resolve(res);
            }
        };
        wxRequestConfig.fail = function() {
            resolve({});
        };
        _api2.default.request(wxRequestConfig);
    });
};

var request = function request() {
    var config = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    if (config.params && Object.keys(config.params).length > 0) {
        var paramsArr = Object.keys(config.params).map(function(key) {
            var formatKey = encodeURI(decodeURI(key));
            var formatValue = encodeURI(decodeURI(config.params[key]));
            return formatKey + "=" + formatValue;
        });
        config.url = config.url + "?" + paramsArr.join("&");
        delete config.params;
    }
    return _sendRequest(config);
};

var adapts = {
    processResponseData: processResponseData,
    processResponseError: processResponseError
};

var _factory = (0, _http2.default)(request, adapts), get = _factory.get, del = _factory.del, head = _factory.head, post = _factory.post, put = _factory.put, patch = _factory.patch, makeUri = _factory.makeUri, interceptors = _factory.interceptors, configure = _factory.configure;

var wxHttpConfigure = function wxHttpConfigure(config) {
    return configure(config);
};

exports.get = get;

exports.del = del;

exports.head = head;

exports.post = post;

exports.put = put;

exports.patch = patch;

exports.makeUri = makeUri;

exports.interceptors = interceptors;

exports.configure = wxHttpConfigure;