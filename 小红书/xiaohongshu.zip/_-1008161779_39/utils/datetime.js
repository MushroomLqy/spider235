Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function() {
    function defineProperties(target, props) {
        for (var i = 0; i < props.length; i++) {
            var descriptor = props[i];
            descriptor.enumerable = descriptor.enumerable || false;
            descriptor.configurable = true;
            if ("value" in descriptor) descriptor.writable = true;
            Object.defineProperty(target, descriptor.key, descriptor);
        }
    }
    return function(Constructor, protoProps, staticProps) {
        if (protoProps) defineProperties(Constructor.prototype, protoProps);
        if (staticProps) defineProperties(Constructor, staticProps);
        return Constructor;
    };
}();

function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}

var Datetime = function() {
    function Datetime() {
        _classCallCheck(this, Datetime);
    }
    _createClass(Datetime, [ {
        key: "getFormatObj",
        value: function getFormatObj(timestamp) {
            var date = new Date(timestamp);
            var obj = {
                year: date.getFullYear(),
                month: date.getMonth() + 1,
                day: date.getDate(),
                hour: date.getHours(),
                minute: date.getMinutes(),
                seconds: date.getSeconds()
            };
            var newObj = {};
            for (var key in obj) {
                if (Object.prototype.hasOwnProperty.call(obj, key)) {
                    newObj[key] = this.formatNumber(obj[key]);
                }
            }
            return newObj;
        }
    }, {
        key: "formatNumber",
        value: function formatNumber(number) {
            return number < 10 ? "0" + number : number.toString();
        }
    }, {
        key: "getTimeStampByDay",
        value: function getTimeStampByDay() {
            var number = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
            return number * 1e3 * 60 * 60 * 24;
        }
    } ]);
    return Datetime;
}();

exports.default = new Datetime();

function getTimeStampByDay() {
    var number = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
    return number * 1e3 * 60 * 60 * 24;
}

exports.getTimeStampByDay = getTimeStampByDay;