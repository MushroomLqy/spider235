Object.defineProperty(exports, "__esModule", {
    value: true
});

var _regenerator = require("./../karin_npm/babel-runtime/regenerator/index.js");

var _regenerator2 = _interopRequireDefault(_regenerator);

var _createClass = function() {
    function defineProperties(target, props) {
        for (var i = 0; i < props.length; i++) {
            var descriptor = props[i];
            descriptor.enumerable = descriptor.enumerable || false;
            descriptor.configurable = true;
            if ("value" in descriptor) descriptor.writable = true;
            Object.defineProperty(target, descriptor.key, descriptor);
        }
    }
    return function(Constructor, protoProps, staticProps) {
        if (protoProps) defineProperties(Constructor.prototype, protoProps);
        if (staticProps) defineProperties(Constructor, staticProps);
        return Constructor;
    };
}();

var _api = require("./api");

var _api2 = _interopRequireDefault(_api);

var _canvasImage = require("./canvasImage");

var _canvasImage2 = _interopRequireDefault(_canvasImage);

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

function _asyncToGenerator(fn) {
    return function() {
        var gen = fn.apply(this, arguments);
        return new Promise(function(resolve, reject) {
            function step(key, arg) {
                try {
                    var info = gen[key](arg);
                    var value = info.value;
                } catch (error) {
                    reject(error);
                    return;
                }
                if (info.done) {
                    resolve(value);
                } else {
                    return Promise.resolve(value).then(function(value) {
                        step("next", value);
                    }, function(err) {
                        step("throw", err);
                    });
                }
            }
            return step("next");
        });
    };
}

function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}

var Canvas = function() {
    function Canvas() {
        _classCallCheck(this, Canvas);
        this.context = {};
    }
    _createClass(Canvas, [ {
        key: "initCanvas",
        value: function initCanvas() {
            var canvasId = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
            this.context = _api2.default.createCanvasContext(canvasId);
        }
    }, {
        key: "drawImage",
        value: function() {
            var _ref = _asyncToGenerator(/* */ _regenerator2.default.mark(function _callee() {
                var image = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
                var x, y, width, height, imageInfo, res;
                return _regenerator2.default.wrap(function _callee$(_context) {
                    while (1) {
                        switch (_context.prev = _context.next) {
                          case 0:
                            x = image.x, y = image.y, width = image.width, height = image.height;
                            imageInfo = {};
                            if (image.pathId) {
                                imageInfo.pathId = image.pathId;
                            }
                            if (image.path) {
                                imageInfo.path = image.path;
                            }
                            _context.next = 6;
                            return _canvasImage2.default.getImageInfo(imageInfo);

                          case 6:
                            res = _context.sent;
                            if (res.path) {
                                this.context.drawImage(res.path, x, y, width, height);
                            }

                          case 8:
                          case "end":
                            return _context.stop();
                        }
                    }
                }, _callee, this);
            }));
            function drawImage() {
                return _ref.apply(this, arguments);
            }
            return drawImage;
        }()
    }, {
        key: "drawImageWithRadius",
        value: function() {
            var _ref2 = _asyncToGenerator(/* */ _regenerator2.default.mark(function _callee2() {
                var image = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
                var x, y, width, height, radius;
                return _regenerator2.default.wrap(function _callee2$(_context2) {
                    while (1) {
                        switch (_context2.prev = _context2.next) {
                          case 0:
                            x = image.x, y = image.y, width = image.width, height = image.height, radius = image.radius;
                            this.context.save();
                            // 先保存状态 已便于画完圆再用
                                                        this.context.beginPath();
                            // 开始绘制
                                                        this.context.arc(x + radius, y + radius, radius, Math.PI, Math.PI * 3 / 2);
                            this.context.lineTo(width - radius + x, y);
                            this.context.arc(width - radius + x, radius + y, radius, Math.PI * 3 / 2, Math.PI * 2);
                            this.context.lineTo(width + x, height + y - radius);
                            this.context.arc(width - radius + x, height - radius + y, radius, 0, Math.PI * 1 / 2);
                            this.context.lineTo(radius + x, height + y);
                            this.context.arc(radius + x, height - radius + y, radius, Math.PI * 1 / 2, Math.PI);
                            this.context.closePath();
                            this.context.fill();
                            this.context.clip();
                            _context2.next = 15;
                            return this.drawImage(image);

                          case 15:
                            console.log("............");
                            this.context.restore();

                          case 17:
                          case "end":
                            return _context2.stop();
                        }
                    }
                }, _callee2, this);
            }));
            function drawImageWithRadius() {
                return _ref2.apply(this, arguments);
            }
            return drawImageWithRadius;
        }()
        /** *
    圆形头像
    pathId: cdn id,
    path,
    x,
    y,
    width,
    borderWidth: 边框宽度
    borderColor: 边框颜色
  ****/    }, {
        key: "drawAvatar",
        value: function() {
            var _ref3 = _asyncToGenerator(/* */ _regenerator2.default.mark(function _callee3() {
                var avatar = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
                var x, y, width, borderWidth, borderColor, defaultUrl, path, url, res, resDefault, avatarPath;
                return _regenerator2.default.wrap(function _callee3$(_context3) {
                    while (1) {
                        switch (_context3.prev = _context3.next) {
                          case 0:
                            x = avatar.x, y = avatar.y, width = avatar.width, borderWidth = avatar.borderWidth, 
                            borderColor = avatar.borderColor, defaultUrl = avatar.defaultUrl, path = avatar.path;
                            url = path;
                            _context3.next = 4;
                            return _canvasImage2.default.privateGetImageInfo(url, 5e3);

                          case 4:
                            res = _context3.sent;
                            console.log(res);
                            resDefault = "";
                            avatarPath = "";
                            defaultUrl = defaultUrl ? defaultUrl : "https://ci.xiaohongshu.com/23eafaab-11fa-4d51-bc08-5636a3c988d0";
                            if (!res.path) {
                                _context3.next = 13;
                                break;
                            }
                            avatarPath = res.path;
                            _context3.next = 18;
                            break;

                          case 13:
                            if (!defaultUrl) {
                                _context3.next = 17;
                                break;
                            }
                            _context3.next = 16;
                            return _canvasImage2.default.privateGetImageInfo(defaultUrl);

                          case 16:
                            resDefault = _context3.sent;

                          case 17:
                            avatarPath = resDefault.path;

                          case 18:
                            this.context.save();
                            // 先保存状态 已便于画完圆再用
                                                        this.context.beginPath();
                            // 开始绘制
                                                        this.context.arc(x, y, width / 2, 0, Math.PI * 2);
                            this.context.clip();
                            this.context.drawImage(avatarPath, x - width / 2, y - width / 2, width, width);
                            this.context.restore();
                            // 画边框
                                                        this.context.beginPath();
                            // 开始绘制
                                                        this.context.arc(x, y, width / 2 + borderWidth / 2, 0, Math.PI * 2);
                            this.context.setStrokeStyle(borderColor);
                            this.context.setLineWidth(borderWidth);
                            this.context.stroke();

                          case 29:
                          case "end":
                            return _context3.stop();
                        }
                    }
                }, _callee3, this);
            }));
            function drawAvatar() {
                return _ref3.apply(this, arguments);
            }
            return drawAvatar;
        }()
    }, {
        key: "drawText",
        value: function drawText() {
            var textInfo = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            var _textInfo$size = textInfo.size, size = _textInfo$size === undefined ? 15 : _textInfo$size, _textInfo$color = textInfo.color, color = _textInfo$color === undefined ? "black" : _textInfo$color, _textInfo$text = textInfo.text, text = _textInfo$text === undefined ? "" : _textInfo$text, _textInfo$x = textInfo.x, x = _textInfo$x === undefined ? 0 : _textInfo$x, _textInfo$y = textInfo.y, y = _textInfo$y === undefined ? 0 : _textInfo$y, _textInfo$align = textInfo.align, align = _textInfo$align === undefined ? "left" : _textInfo$align, isBlod = textInfo.isBlod;
            if (isBlod) {
                this.context.font = "normal bold " + size + "px sans-serif";
            } else {
                this.context.font = size + "px sans-serif";
            }
            this.context.setTextAlign(align);
            this.context.setFontSize(size);
            this.context.setFillStyle(color);
            this.context.fillText(text, x, y);
        }
    }, {
        key: "drawRect",
        value: function drawRect() {
            var rectInfo = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            var _rectInfo$color = rectInfo.color, color = _rectInfo$color === undefined ? "black" : _rectInfo$color, _rectInfo$x = rectInfo.x, x = _rectInfo$x === undefined ? 0 : _rectInfo$x, _rectInfo$y = rectInfo.y, y = _rectInfo$y === undefined ? 0 : _rectInfo$y, _rectInfo$width = rectInfo.width, width = _rectInfo$width === undefined ? 0 : _rectInfo$width, _rectInfo$height = rectInfo.height, height = _rectInfo$height === undefined ? 0 : _rectInfo$height;
            this.context.setFillStyle(color);
            this.context.fillRect(x, y, width, height);
        }
    }, {
        key: "drawTrue",
        value: function drawTrue() {
            var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            var onDrawedCallBack = options.onDrawedCallBack;
            this.context.draw(true, function() {
                onDrawedCallBack && onDrawedCallBack();
            });
        }
    }, {
        key: "getTextWidth",
        value: function getTextWidth() {
            var textInfo = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            var textWidth = 0;
            var _textInfo$size2 = textInfo.size, size = _textInfo$size2 === undefined ? 15 : _textInfo$size2, _textInfo$text2 = textInfo.text, text = _textInfo$text2 === undefined ? "" : _textInfo$text2, isBlod = textInfo.isBlod;
            if (isBlod) {
                this.context.font = "normal bold " + size + "px sans-serif";
            } else {
                this.context.font = size + "px sans-serif";
            }
            textWidth = this.context.measureText(text).width;
            return textWidth;
        }
    } ]);
    return Canvas;
}();

exports.default = Canvas;