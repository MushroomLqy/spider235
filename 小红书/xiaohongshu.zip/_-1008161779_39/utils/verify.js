Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function() {
    function defineProperties(target, props) {
        for (var i = 0; i < props.length; i++) {
            var descriptor = props[i];
            descriptor.enumerable = descriptor.enumerable || false;
            descriptor.configurable = true;
            if ("value" in descriptor) descriptor.writable = true;
            Object.defineProperty(target, descriptor.key, descriptor);
        }
    }
    return function(Constructor, protoProps, staticProps) {
        if (protoProps) defineProperties(Constructor.prototype, protoProps);
        if (staticProps) defineProperties(Constructor, staticProps);
        return Constructor;
    };
}();

var _path = require("./path");

function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}

var goToVerPageTimeout = void 0;

var Verify = function() {
    function Verify() {
        _classCallCheck(this, Verify);
        this.canJumpToVerifyPageValue = true;
        this.lastJumpPageUrl = "";
    }
    _createClass(Verify, [ {
        key: "canJumpToVerifyPage",
        value: function canJumpToVerifyPage() {
            return this.canJumpToVerifyPageValue;
        }
    }, {
        key: "setRelaunchBeforeVerifyPage",
        value: function setRelaunchBeforeVerifyPage() {
            var pages = getCurrentPages() || [];
            // eslint-disable-line
                        var lastJumpPageUrl = "";
            if (pages && pages.length > 0) {
                var page = pages[pages.length - 1];
                var route = page && page.route;
                var args = page && page.options;
                if (route && args) {
                    lastJumpPageUrl = "/" + (0, _path.makePath)(route, args);
                }
            }
            console.log("###############", lastJumpPageUrl);
            // eslint-disable-line
                        this.lastJumpPageUrl = lastJumpPageUrl;
        }
    }, {
        key: "relaunchBeforeVerifyPage",
        value: function relaunchBeforeVerifyPage() {
            if (!this.lastJumpPageUrl) {
                (0, _path.switchTab)("HomePage");
            } else {
                wx.reLaunch({
                    url: this.lastJumpPageUrl
                });
            }
        }
    }, {
        key: "setDisableVerifyPage",
        value: function setDisableVerifyPage() {
            this.canJumpToVerifyPageValue = false;
        }
    }, {
        key: "setAvailableVerifyPage",
        value: function setAvailableVerifyPage() {
            this.canJumpToVerifyPageValue = true;
        }
    }, {
        key: "goToVerifyPage",
        value: function goToVerifyPage(verifyTypeStr) {
            if (goToVerPageTimeout) {
                clearTimeout(goToVerPageTimeout);
            }
            goToVerPageTimeout = setTimeout(function() {
                // 检测当前页面是不是验证码页面，如果是就不跳转
                var pages = getCurrentPages() || [];
                // eslint-disable-line
                                if (pages.length > 0) {
                    var page = pages[pages.length - 1];
                    var route = page && page.route;
                    if (route === "pages/secondary/verify/index") {
                        return;
                    }
                }
                (0, _path.redirectTo)("VerPage", {
                    verifyType: verifyTypeStr
                });
            }, 800);
        }
    } ]);
    return Verify;
}();

exports.default = new Verify();