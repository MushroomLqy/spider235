Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function() {
    function defineProperties(target, props) {
        for (var i = 0; i < props.length; i++) {
            var descriptor = props[i];
            descriptor.enumerable = descriptor.enumerable || false;
            descriptor.configurable = true;
            if ("value" in descriptor) descriptor.writable = true;
            Object.defineProperty(target, descriptor.key, descriptor);
        }
    }
    return function(Constructor, protoProps, staticProps) {
        if (protoProps) defineProperties(Constructor.prototype, protoProps);
        if (staticProps) defineProperties(Constructor, staticProps);
        return Constructor;
    };
}();

var _path = require("./path");

function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}

var IntervalUtil = function() {
    function IntervalUtil() {
        _classCallCheck(this, IntervalUtil);
        this.intervalMaps = {};
        this.nowPageKey = null;
    }
    _createClass(IntervalUtil, [ {
        key: "addIntervalTask",
        value: function addIntervalTask(fn, time) {
            var _getPageUrl = (0, _path.getPageUrl)(), url = _getPageUrl.url;
            this.nowPageKey = url;
            var nowPageKey = this.nowPageKey;
            if (!this.intervalMaps[nowPageKey]) {
                this.intervalMaps[nowPageKey] = [];
            }
            var task = setInterval(fn, time);
            this.intervalMaps[nowPageKey].push({
                fn: fn,
                time: time,
                task: task
            });
        }
        // 睡眠任务队列
        }, {
        key: "sleep",
        value: function sleep() {
            var pagekey = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
            var intervals = this.intervalMaps[pagekey];
            if (!intervals) {
                return;
            }
            intervals.forEach(function(interval) {
                clearTimeout(interval.task);
                interval.task = null;
            });
            this.intervalMaps[pagekey] = intervals;
        }
        // 唤醒任务队列
        }, {
        key: "wakeUp",
        value: function wakeUp() {
            var pagekey = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
            var intervals = this.intervalMaps[pagekey];
            if (!intervals) {
                return;
            }
            intervals.forEach(function(interval) {
                var fn = interval.fn, time = interval.time;
                interval.task = setInterval(fn, time);
            });
        }
        // 清楚所有队列
        }, {
        key: "clean",
        value: function clean() {
            if (this.intervalMaps && Object.keys(this.intervalMaps).length > 0) {
                for (var pageKey in this.intervalMaps) {
                    if (Object.prototype.hasOwnProperty.call(this.intervalMaps, pageKey)) {
                        this.intervalMaps[pageKey].forEach(function(interval) {
                            clearTimeout(interval.task);
                            interval.task = null;
                        });
                    }
                }
            }
            this.intervalMaps = {};
        }
    } ]);
    return IntervalUtil;
}();

exports.default = new IntervalUtil();