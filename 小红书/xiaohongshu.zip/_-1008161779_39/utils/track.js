Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.trackImpression = exports.trackPageview = exports.trackClick = exports.trackError = exports.trackApm = exports.trackNormalData = undefined;

var _createClass = function() {
    function defineProperties(target, props) {
        for (var i = 0; i < props.length; i++) {
            var descriptor = props[i];
            descriptor.enumerable = descriptor.enumerable || false;
            descriptor.configurable = true;
            if ("value" in descriptor) descriptor.writable = true;
            Object.defineProperty(target, descriptor.key, descriptor);
        }
    }
    return function(Constructor, protoProps, staticProps) {
        if (protoProps) defineProperties(Constructor.prototype, protoProps);
        if (staticProps) defineProperties(Constructor, staticProps);
        return Constructor;
    };
}();

var _routes = require("../routes");

var _path = require("./path");

var _enum = require("./enum");

var _api = require("./api");

var _api2 = _interopRequireDefault(_api);

var _user = require("./user");

var _user2 = _interopRequireDefault(_user);

var _tracker = require("../services/tracker");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}

var SHOW_PART_RATE = .3;

var getPageUrlInfo = function getPageUrlInfo() {
    var pageInfo = (0, _path.getPageUrl)();
    try {
        var query = pageInfo.query || {};
        var gdt_vid = query.gdt_vid, weixinadinfo = query.weixinadinfo;
        // eslint-disable-line
                var result = {};
        if (gdt_vid && weixinadinfo) {
            // eslint-disable-line
            var weixinadinfoArr = weixinadinfo.split(".");
            result.aid = weixinadinfoArr[0];
        }
        result = Object.assign(result, pageInfo);
        return result;
    } catch (error) {
        console.warn(error);
        // eslint-disable-line
                return pageInfo;
    }
};

// 手动打点
var trackNormalData = exports.trackNormalData = function trackNormalData(_ref) {
    var action = _ref.action, label = _ref.label, property = _ref.property, context = _ref.context, sourceRoute = _ref.sourceRoute, isApm = _ref.isApm;
    var pageInfo = getPageUrlInfo();
    if ((!pageInfo || !pageInfo.route) && !sourceRoute) {
        return;
    }
    var route = pageInfo.route, url = pageInfo.url, from = pageInfo.from, aid = pageInfo.aid, source = pageInfo.source, appuid = pageInfo.appuid;
    var category = (0, _routes.getCategory)(route || sourceRoute);
    context = context || {};
    context.scene = pageInfo.scene;
    if (!action) {
        console.error("action is required");
        // eslint-disable-line
        }
    (0, _tracker.sendTrackInfo)({
        category: category,
        seAc: action,
        sePr: property,
        seLa: label,
        url: url,
        from: from,
        co: context,
        aid: aid,
        isApm: isApm,
        source: source,
        appuid: appuid
    });
};

var trackApm = exports.trackApm = function trackApm() {
    var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var newOptions = options;
    newOptions.isApm = true;
    return trackNormalData(newOptions);
};

var trackError = exports.trackError = function trackError() {
    var errMsg = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
    try {
        var pageInfo = getPageUrlInfo();
        if (!pageInfo || !pageInfo.route) {
            return;
        }
        var _userUtil$getUserInfo = _user2.default.getUserInfo(), openid = _userUtil$getUserInfo.openid, appUserId = _userUtil$getUserInfo.appUserId;
        var route = pageInfo.route, url = pageInfo.url, from = pageInfo.from, aid = pageInfo.aid;
        var category = (0, _routes.getCategory)(route) || "mpPage";
        wx.reportAnalytics("app_onerror", {
            openid: openid,
            category: category,
            message: errMsg,
            user_id: appUserId
        });
        var postData = {
            category: category,
            seAc: "error",
            sePr: "",
            seLa: errMsg.substr(0, 60),
            url: url,
            from: from,
            aid: aid,
            co: {
                errMsg: errMsg.substr(0, 220)
            },
            isApm: true
        };
        (0, _tracker.sendTrackInfo)(postData);
    } catch (error) {
        wx.reportAnalytics("app_onerror", {
            openid: "",
            category: "",
            message: error
        });
        console.error(error);
        // eslint-disable-line
        }
};

var trackClick = exports.trackClick = function trackClick() {
    var info = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var datas = {};
    var _getPageUrlInfo = getPageUrlInfo(), route = _getPageUrlInfo.route, url = _getPageUrlInfo.url, from = _getPageUrlInfo.from, scene = _getPageUrlInfo.scene, aid = _getPageUrlInfo.aid, source = _getPageUrlInfo.source, appuid = _getPageUrlInfo.appuid;
    try {
        if (Object.prototype.toString.call(info) === "[object String]") {
            datas = JSON.parse(info);
        }
        if (Object.prototype.toString.call(info) === "[object Object]") {
            datas = info;
        }
    } catch (e) {
        console.warn("The id attribute of track element must be json stringify");
        // eslint-disable-line
                return;
    }
    var _datas = datas, label = _datas.label, property = _datas.property, context = _datas.context;
    context = context || {};
    context.scene = scene;
    var postData = {
        category: (0, _routes.getCategory)(route) || "mpPage",
        seAc: label + "_click",
        sePr: property,
        url: url,
        from: from,
        source: source,
        appuid: appuid,
        co: context,
        aid: aid
    };
    (0, _tracker.sendTrackInfo)(postData);
};

var trackPageview = exports.trackPageview = function trackPageview() {
    var _getPageUrlInfo2 = getPageUrlInfo(), route = _getPageUrlInfo2.route, query = _getPageUrlInfo2.query, url = _getPageUrlInfo2.url, scene = _getPageUrlInfo2.scene, from = _getPageUrlInfo2.from, aid = _getPageUrlInfo2.aid, source = _getPageUrlInfo2.source, appuid = _getPageUrlInfo2.appuid;
    (0, _tracker.sendTrackInfo)({
        category: (0, _routes.getCategory)(route) || "mpPage",
        seAc: "pv",
        sePr: query.id || "",
        seLa: scene,
        co: {
            scene: scene
        },
        url: url,
        from: from,
        source: source,
        appuid: appuid,
        aid: aid
    });
};

var impressionScrollMap = {};

var trackImpression = exports.trackImpression = function() {
    function trackImpression(pageInstance) {
        var _this = this;
        _classCallCheck(this, trackImpression);
        this.findTrackFailNum = 0;
        this.impressedTracker = {};
        this.pageInstance = pageInstance;
        this.initWindowSize();
        this.countDown = null;
        var key = pageInstance.$wxpage.route;
        if (!impressionScrollMap[key]) {
            impressionScrollMap[key] = 1;
            this.countDown = setTimeout(function() {
                _this.postData();
            }, 300);
            this.trackEvent();
        }
    }
    _createClass(trackImpression, [ {
        key: "trackEvent",
        value: function trackEvent() {
            var _this2 = this;
            var that = this;
            var pageInstance = that.pageInstance;
            var priviteOPageScroll = pageInstance.onPageScroll || null;
            pageInstance.onPageScroll = function(res) {
                if (priviteOPageScroll) {
                    priviteOPageScroll.call(pageInstance, res);
                }
                if (_this2.countDown) {
                    clearTimeout(_this2.countDown);
                }
                _this2.countDown = setTimeout(function() {
                    // 防止监测对象过大
                    if (Object.keys(that.impressedTracker).length > 100) {
                        that.impressedTracker = {};
                    }
                    that.postData();
                }, 500);
            };
            // clear impressedTracker when onPullDownRefresh
                        if (pageInstance.onPullDownRefresh) {
                var priviteOPullDownRefresh = pageInstance.onPullDownRefresh;
                pageInstance.onPullDownRefresh = function() {
                    that.clearImpressedTracker();
                    priviteOPullDownRefresh.call(pageInstance);
                };
            } else {
                pageInstance.onPullDownRefresh = function() {
                    that.clearImpressedTracker();
                };
            }
        }
    }, {
        key: "initWindowSize",
        value: function initWindowSize() {
            // let that = this
            var systemInfo = this.pageInstance.$root.$parent.globalData.systemInfo;
            // eslint-disable-line
                        this.windowHeight = systemInfo.windowHeight;
            this.windowWidth = systemInfo.windowWidth;
            // minus tabBar height if has it
            // Api.createSelectorQuery().select('#tabBar').boundingClientRect(res => { // eslint-disable-line
            //   if (res.height) {
            //     that.windowHeight -= res.height
            //   }
            // })
            //   .exec()
                }
    }, {
        key: "postData",
        value: function postData() {
            var that = this;
            var _getPageUrl = (0, _path.getPageUrl)(), route = _getPageUrl.route, url = _getPageUrl.url, from = _getPageUrl.from, source = _getPageUrl.source, scene = _getPageUrl.scene, appuid = _getPageUrl.appuid;
            if (!_api2.default.canIUse("createSelectorQuery") || !_api2.default.createSelectorQuery) {
                // eslint-disable-line
                return;
            }
            var query = _api2.default.createSelectorQuery();
            // eslint-disable-line
                        query.selectAll("." + _enum.TRACK.className).boundingClientRect(function(rects) {
                rects.forEach(function(rect) {
                    // rect.id format: id_index
                    var datas = {};
                    try {
                        datas = JSON.parse(rect.id);
                    } catch (e) {
                        console.warn("The id attribute of track element must be json stringify");
                        // eslint-disable-line
                                                return;
                    }
                    var _datas2 = datas, label = _datas2.label, property = _datas2.property, context = _datas2.context, timeStamp = _datas2.timeStamp;
                    label = label || "";
                    property = property || "";
                    context = context || {};
                    context.scene = scene;
                    timeStamp = timeStamp || 0;
                    that.label = label;
                    var checkIsImpressionKey = "" + label + property + timeStamp;
                    // haven't collected impression dot
                                        if (!that.impressedTracker[checkIsImpressionKey]) {
                        var isInnerWindow = that.isInnerWindow(rect);
                        if (isInnerWindow) {
                            var postData = {
                                category: (0, _routes.getCategory)(route) || "mpPage",
                                seAc: label + "_impression",
                                sePr: property,
                                url: url,
                                co: context,
                                from: from,
                                source: source,
                                appuid: appuid
                            };
                            that.impressedTracker[checkIsImpressionKey] = 1;
                            (0, _tracker.sendTrackInfo)(postData);
                        }
                    }
                });
            }).exec();
        }
    }, {
        key: "clearImpressedTracker",
        value: function clearImpressedTracker() {
            this.impressedTracker = {};
            this.findTrackFailNum = 0;
        }
        // 是否在屏幕内
        }, {
        key: "isInnerWindow",
        value: function isInnerWindow(bounds) {
            if (bounds) {
                var isDomVerticalVisibleEnough = bounds.bottom >= 0 && bounds.top + bounds.height * SHOW_PART_RATE < this.windowHeight;
                var isDomHorizonalVisibleEnough = bounds.right >= 0 && bounds.left + bounds.width * SHOW_PART_RATE < this.windowWidth;
                return isDomVerticalVisibleEnough && isDomHorizonalVisibleEnough;
            }
        }
    } ]);
    return trackImpression;
}();