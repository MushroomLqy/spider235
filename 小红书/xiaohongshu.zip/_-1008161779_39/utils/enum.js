Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.contains = contains;

function contains(ENUM, value) {
    for (var key in ENUM) {
        if (ENUM.hasOwnProperty(key) && ENUM[key] === value) {
            return true;
        }
    }
    return false;
}

var TRACK = exports.TRACK = {
    className: "xhs-track"
};

var TRENDING_TYPE = exports.TRENDING_TYPE = {
    SEARCH_TRENDING: "search_trending",
    GOODS_TRENDING: "goods_trending"
};

var NOTE_TYPE = exports.NOTE_TYPE = {
    NORMAL: "normal",
    MULTI: "multi",
    VIDEO: "video"
};

var STORAGE_KEY = exports.STORAGE_KEY = {
    API_TOKEN: "api_token",
    LAST_SEARCH: "last_search",
    USER_INFO: "user_info_v1",
    PRODUCT_SEARCH_RECORDS: "product_search_records_v1",
    NEWBIE_FLAG: "newbie_flag",
    PIN_MINI_PROGRAM_FLAG: "pin_mini_program",
    CATEGORY: "category",
    HOME_PAGE_FEEDS: "homePageFeeds",
    WX_USER_INFO_DETAIL: "wx_user_info_detail",
    // 微信userinfo接口获得的原始数据 为了跳过注册获取好友关系使用
    IS_GET_NEW_FEEDS: "is_get_new_feeds",
    AB_TEST: "xhs_ab_test",
    IS_NEW_WXMP_UESR: "is_new_wxmp_user",
    SELECTED_STAR: "selected_star",
    CAN_SHOW_FULL_ADD_MP: "canShowFullAddMp"
};

var SHARE_GROUP_CARD = exports.SHARE_GROUP_CARD = 1008;

var SHARE_SINGLE_CARD = exports.SHARE_SINGLE_CARD = 1007;

var SHARE_MEESAGE_SCENE = exports.SHARE_MEESAGE_SCENE = 1036;

var OTHER_MP_BACK_SCENE = exports.OTHER_MP_BACK_SCENE = 1038;

var APP_OPEN_SCENE = exports.APP_OPEN_SCENE = 1069;

var MAIN_CHAT_SCENE = exports.MAIN_CHAT_SCENE = 1089;

var HISTORY_SCENE = exports.HISTORY_SCENE = 1090;

var RENEW_DATA = exports.RENEW_DATA = {
    scene: 1038,
    appId: "wxbd687630cd02ce1d"
};