Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.isSupportDiscovery = exports.getGoodsId = undefined;

var _ICON_MAPPING;

exports.getFormatTag = getFormatTag;

exports.getExpressionIcon = getExpressionIcon;

exports.getFormatedExpressionArr = getFormatedExpressionArr;

exports.filterUnSupportDiscovery = filterUnSupportDiscovery;

exports.getNoTagNoFaceIconText = getNoTagNoFaceIconText;

var _enum = require("./enum");

var _icons = require("./icons");

function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}

// eslint-disable-line
var ICON_MAPPING = (_ICON_MAPPING = {
    oldDeyi: "得意",
    xihuan: "喜欢",
    huoli: "活力",
    shaonv: "少女心",
    buman: "不满",
    taoyan: "讨厌",
    wuyu: "无语L",
    oldShengqi: "生气",
    koubi: "抠鼻",
    zhuangku: "装酷",
    zhenjing: "震惊L",
    shihua: "石化",
    haipa: "害怕",
    kuku: "哭哭",
    fanu: "发怒",
    fuhei: "腹黑",
    weiqu: "委屈",
    keshui: "瞌睡",
    baji: "吧唧R",
    // eslint-disable-line
    bishi: "鄙视R",
    // eslint-disable-line
    deyi: "得意R",
    // eslint-disable-line
    feiwen: "飞吻R",
    // eslint-disable-line
    fuqiang: "扶墙R",
    // eslint-disable-line
    haixiu: "害羞R",
    // eslint-disable-line
    hanyan: "汗颜R",
    // eslint-disable-line
    jingkong: "惊恐R",
    // eslint-disable-line
    kure: "哭惹R",
    // eslint-disable-line
    mengmengda: "萌萌哒R",
    // eslint-disable-line
    sese: "色色R",
    // eslint-disable-line
    shengqi: "生气R",
    // eslint-disable-line
    tanqi: "叹气R",
    // eslint-disable-line
    touxiao: "偷笑R",
    // eslint-disable-line
    xiaoku: "笑哭R",
    // eslint-disable-line
    zaijian: "再见R",
    // eslint-disable-line
    zan: "赞R",
    // eslint-disable-line
    zhuakuang: "抓狂R",
    // eslint-disable-line
    r_xieyan: "斜眼R",
    r_kelian: "可怜R",
    r_zhoumei: "皱眉R",
    angry: "无语",
    han: "汗",
    blind: "瞎",
    cool: "酷",
    cry: "哭",
    cute: "萌",
    kiss: "么么哒",
    dignose: "挖鼻孔",
    koushui: "口水",
    baiyan: "白眼",
    frozen: "好冷",
    shy: "害羞",
    titter: "嘿嘿",
    xixi: "嘻嘻",
    haha: "哈哈",
    oops: "好雷",
    question: "啊？",
    rish: "土豪",
    shock: "震惊",
    shoo: "嘘",
    dizzy: "晕",
    h_tushetou: "吐舌头H",
    h_jingxia: "惊吓H",
    h_chelian: "扯脸H",
    r_anzhongguancha: "暗中观察R",
    r_chigua: "吃瓜R",
    r_daxiao: "大笑R",
    r_heishuwenhao: "黑薯问号R",
    r_henaicha: "喝奶茶R",
    r_huangjinshu: "黄金薯R"
}, _defineProperty(_ICON_MAPPING, "r_kelian", "可怜R"), _defineProperty(_ICON_MAPPING, "r_koubi", "抠鼻R"), 
_defineProperty(_ICON_MAPPING, "r_maibao", "买爆R"), _defineProperty(_ICON_MAPPING, "r_paidui", "派对R"), 
_defineProperty(_ICON_MAPPING, "r_shihua", "石化R"), _defineProperty(_ICON_MAPPING, "r_shiwang", "失望R"), 
_defineProperty(_ICON_MAPPING, "r_shuijiao", "睡觉R"), _defineProperty(_ICON_MAPPING, "r_wa", "哇R"), 
_defineProperty(_ICON_MAPPING, "r_weixiao", "微笑R"), _defineProperty(_ICON_MAPPING, "r_wulian", "捂脸R"), 
_defineProperty(_ICON_MAPPING, "r_zipai", "自拍R"), _defineProperty(_ICON_MAPPING, "r_nidongde", "你懂的R"), 
_defineProperty(_ICON_MAPPING, "r_sang", "丧R"), _ICON_MAPPING);

var ICON_MAPPING_REVERSE = Object.keys(ICON_MAPPING).reduce(function(ret, key) {
    var value = ICON_MAPPING[key];
    if (key.indexOf("old") === 0 && key.split("old").length > 1) {
        key = key.split("old")[1].toLowerCase();
    }
    ret[value] = key;
    return ret;
}, {});

var isDeepLink = function isDeepLink(tag) {
    return tag.link && tag.link.indexOf("xhsdiscover") > -1;
};

var getGoodsId = exports.getGoodsId = function getGoodsId(str) {
    var goodsStr = "/goods/";
    var startGoodsStrIndex = str.indexOf(goodsStr);
    var id = str || "";
    if (str.indexOf("http") > -1) {
        id = str.substr(startGoodsStrIndex + goodsStr.length, 24);
    }
    return id;
};

function getFormatedUserTag() {
    var checkStr = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
    var ats = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];
    var checkUserArr = checkStr.trim().split("@");
    var result = [];
    var hasUserTag = false;
    checkUserArr.forEach(function(str, index) {
        var letter = index > 0 && str ? "@" : "";
        var itemHasUserTag = false;
        ats.some(function(user) {
            var userIndex = str.indexOf(user.nickname);
            if (userIndex > -1) {
                itemHasUserTag = true;
                hasUserTag = true;
                result.push({
                    type: "userTag",
                    text: "@ " + user.nickname,
                    id: user.userid || user.id
                });
                var lastStr = str.replace(user.nickname, "");
                if (lastStr.trim()) {
                    result.push({
                        type: "text",
                        text: lastStr
                    });
                }
                return true;
            }
        });
        if (!itemHasUserTag && str) {
            result.push({
                type: "text",
                text: "" + letter + str
            });
        }
    });
    return {
        result: result,
        hasUserTag: hasUserTag
    };
}

function getFormatTag() {
    var checkStr = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
    var hashTags = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];
    var ats = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : [];
    var copyHashTags = JSON.parse(JSON.stringify(hashTags));
    var arr = checkStr.split(/[#]/);
    var result = [];
    arr.forEach(function(str) {
        if (str) {
            var hasPageTag = false;
            var hasUserTag = false;
            var isDeepLinkTag = false;
            copyHashTags.some(function(tag) {
                tag.link = tag.link || "";
                if (str === tag.name && isDeepLink(tag)) {
                    isDeepLinkTag = true;
                }
                if (str === tag.name && !isDeepLink(tag)) {
                    hasPageTag = true;
                    result.push({
                        type: "pageTag",
                        sourceType: tag.type,
                        text: str,
                        link: tag.link,
                        iconUrl: (0, _icons.getPageTagIconUrl)(tag.type)
                    });
                    return true;
                }
            });
            if (isDeepLinkTag && str && str.trim()) {
                str = "#" + str + "#";
            }
            // 检查有没有被@的用户
                        if (str.indexOf("@") > -1 && ats.length > 0) {
                var getFormatedUserTags = getFormatedUserTag(str, ats);
                hasUserTag = getFormatedUserTags.hasUserTag;
                if (hasUserTag) {
                    result = result.concat(getFormatedUserTags.result);
                }
            }
            if (!hasPageTag && !hasUserTag) {
                result.push({
                    type: "text",
                    text: str
                });
            }
        }
    });
    return result;
}

function getExpressionIcon(str) {
    if (!str) {
        return null;
    }
    var innerMap = JSON.parse(JSON.stringify(ICON_MAPPING_REVERSE));
    for (var key in innerMap) {
        if (key === str) {
            return "https://ci.xiaohongshu.com/xy_emo_" + ICON_MAPPING_REVERSE[key] + ".png?v=2";
        }
    }
    return null;
}

function getFormatedExpressionArr() {
    var str = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
    var hashTags = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];
    var ats = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : [];
    var arr = [];
    var copyStr = str;
    var copyHashTags = JSON.parse(JSON.stringify(hashTags));
    var hasSpecialCharacter = copyStr.indexOf("[") > -1 && copyStr.indexOf("]") > -1;
    if (!hasSpecialCharacter && copyStr.indexOf("@") > -1) {
        hasSpecialCharacter = true;
    }
    if (!hasSpecialCharacter) {
        return [ {
            type: "text",
            text: copyStr
        } ];
    }
    copyStr = copyStr.replace(/\[商品]|\[话题]|\[地区]|\[自定义]|\[品牌]|\[地点]|\[店铺]|\[影视]/g, "");
    while (copyStr.length > 0) {
        var startIndex = copyStr.indexOf("[");
        var endIndex = copyStr.indexOf("]");
        if (startIndex === -1 || endIndex === -1 || endIndex < startIndex) {
            arr = arr.concat(getFormatTag(copyStr, copyHashTags, ats));
            copyStr = "";
            break;
        }
        arr = arr.concat(getFormatTag(copyStr.substr(0, startIndex), copyHashTags, ats));
        var checkStr = copyStr.substr(startIndex + 1, endIndex - startIndex - 1);
        if (getExpressionIcon(checkStr)) {
            arr.push({
                type: "image",
                url: getExpressionIcon(checkStr),
                text: copyStr.substr(startIndex, endIndex - startIndex + 1)
            });
        } else {
            var _str = copyStr.substr(startIndex, endIndex - startIndex + 1);
            arr = arr.concat(getFormatTag(_str, copyHashTags, ats));
        }
        copyStr = copyStr.substr(endIndex + 1, copyStr.length);
    }
    return arr;
}

var isSupportDiscovery = exports.isSupportDiscovery = function isSupportDiscovery(discovery) {
    return discovery.type !== _enum.NOTE_TYPE.MULTI;
};

function filterUnSupportDiscovery() {
    var datas = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
    var arr = [];
    datas.forEach(function(data) {
        if (isSupportDiscovery(data)) {
            arr.push(data);
        }
    });
    return arr;
}

/**
 * 获取无表情无tag的文本
 * @param 源文本 text
 */ function getNoTagNoFaceIconText() {
    var text = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
    return text.replace(/\[(.+?)\]/g, "");
}