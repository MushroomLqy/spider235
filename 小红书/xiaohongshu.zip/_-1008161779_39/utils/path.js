Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.getCurrentPage = exports.relaunchLastPage = exports.getLinkVariable = exports.makePathByRouteKey = exports.getPageUrl = exports.makeSharePath = exports.makePath = exports.navigateBack = exports.isPage = exports.MINIPROGRAM_STORE = exports.reLaunch = exports.switchTab = exports.redirectTo = exports.navigateTo = exports.getIdFromDeeplink = undefined;

var _routes = require("../routes");

var _api = require("./api");

var _api2 = _interopRequireDefault(_api);

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

var fromKey = "from";

var sourcekey = "source";

var appuidkey = "appuid";

var MINIPROGRAM_STORE = {
    TARGET: "miniProgram",
    APP_ID: "wx4554c1e6dfadc8ed",
    VERSION: "release"
};

function getCurrentPage() {
    var pages = getCurrentPages();
    // eslint-disable-line
        if (pages.length > 0) {
        return pages[pages.length - 1];
    }
    return {};
}

function getPageUrl() {
    var queryArray = [];
    var getGlobalData = _api2.default.getGlobalData();
    var launchOps = getGlobalData.launchOps || {};
    // eslint-disable-line
        var pages = getCurrentPages();
    // eslint-disable-line
        var currentPage = pages[pages.length - 1];
    currentPage = currentPage || {};
    var _currentPage = currentPage, route = _currentPage.route, options = _currentPage.options;
    var scene = launchOps.scene;
    var from = "";
    var source = "";
    var appuid = "";
    route = route || "";
    options = options || {};
    if (scene) {
        options.scene = scene;
    }
    for (var key in options) {
        if (Object.prototype.hasOwnProperty.call(options, key)) {
            if (key === fromKey) {
                from = options[key];
            }
            if (key === sourcekey) {
                source = options[key];
            }
            if (key === appuidkey) {
                appuid = options[key];
            }
            queryArray.push(key + "=" + options[key]);
        }
    }
    var queryString = queryArray.length > 0 ? "?" + queryArray.join("&") : "";
    return {
        from: from,
        source: source,
        appuid: appuid,
        scene: scene,
        query: options,
        route: route,
        url: "" + route + queryString
    };
}

function isPage(key) {
    return (0, _routes.getRoute)(key);
}

function makePathByRouteKey(key, args) {
    var route = (0, _routes.getRoute)(key);
    if (!route) {
        throw new Error("[path] could not found path via name " + key);
    }
    if (args) {
        route += "?";
        Object.keys(args).forEach(function(key, i) {
            if (args[key]) {
                if (i > 0) {
                    route += "&";
                }
                var prop = String(args[key]);
                route += key + "=" + prop;
            }
        });
    }
    return route;
}

function getLinkVariable() {
    var url = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
    var key = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "";
    var vars = url.split("&");
    url = url || "";
    key = key || "";
    for (var i = 0; i < vars.length; i++) {
        var pair = vars[i].split("=");
        if (pair[0] === key && pair[1]) {
            return pair[1];
        }
    }
    return false;
}

function makePath(name, args) {
    var route = (0, _routes.getRoute)(name);
    var path = "";
    if (args && args.plain) {
        return name;
    }
    if (!name && !route) {
        throw new Error("[path] could not found path via name " + name);
    }
    if (route) {
        path = route;
    } else {
        path = name;
    }
    if (args) {
        path += "?";
        Object.keys(args).forEach(function(key, i) {
            if (args[key]) {
                if (i > 0) {
                    path += "&";
                }
                var prop = String(args[key]);
                path += key + "=" + prop;
            }
        });
    }
    return path;
}

function makeSharePath(name, inArgs) {
    var args = inArgs || {};
    args.share = true;
    return makePath(name, args);
}

var wrap = function wrap(method) {
    return function(category, query) {
        var args = {};
        var route = (0, _routes.getRoute)(category);
        if (route) {
            args.url = "/" + route;
        }
        if (!args.url) {
            console.error("[path] must provide url parameter");
            // eslint-disable-line
                        return;
        }
        if (args.url.indexOf("/webview") > -1 && query.link && typeof query.link === "string" && query.link.indexOf("http") > -1) {
            query.link = encodeURIComponent(decodeURIComponent(query.link));
        }
        args.url = makePath(args.url, query);
        return _api2.default[method](args);
    };
};

var getIdFromDeeplink = exports.getIdFromDeeplink = function getIdFromDeeplink() {
    var deeplink = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
    var ids = deeplink.match(/([a-f\d]{24}|[A-F\d]{24})/g);
    if (ids && ids.length > 0) {
        return ids[0];
    }
    ids = deeplink.match(/picasso_pages\/(\S*)(\?)/);
    if (ids && ids.length > 2) {
        return ids[1];
    }
    return "null";
};

var navigateTo = exports.navigateTo = wrap("navigateTo");

var redirectTo = exports.redirectTo = wrap("redirectTo");

var switchTab = exports.switchTab = wrap("switchTab");

var reLaunch = exports.reLaunch = wrap("reLaunch");

var navigateBack = function navigateBack() {
    return _api2.default.navigateBack();
};

function relaunchLastPage() {
    var backNum = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;
    var pages = getCurrentPages() || [];
    // eslint-disable-line
        if (pages.length === 1) {
        switchTab("HomePage");
    } else {
        var page = pages[pages.length - (1 + backNum)];
        var route = page && page.route;
        var args = page && page.options;
        var url = "/" + makePath(route, args);
        wx.reLaunch({
            url: url
        });
    }
}

exports.MINIPROGRAM_STORE = MINIPROGRAM_STORE;

exports.isPage = isPage;

exports.navigateBack = navigateBack;

exports.makePath = makePath;

exports.makeSharePath = makeSharePath;

exports.getPageUrl = getPageUrl;

exports.makePathByRouteKey = makePathByRouteKey;

exports.getLinkVariable = getLinkVariable;

exports.relaunchLastPage = relaunchLastPage;

exports.getCurrentPage = getCurrentPage;