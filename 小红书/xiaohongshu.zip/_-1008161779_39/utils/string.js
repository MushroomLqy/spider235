Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.isWebViewLink = isWebViewLink;

exports.escapeNoteString = escapeNoteString;

exports.compareVersion = compareVersion;

exports.toLowerLine = toLowerLine;

exports.subMaxLengthString = subMaxLengthString;

// http://stackoverflow.com/questions/2965293/javascript-parse-error-on-u2028-unicode-character
// 判断是不是webview 链接
function isWebViewLink() {
    var str = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
    return /^(https?):\/\/.+$/.test(str);
}

function escapeNoteString() {
    var str = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
    return str.replace(/(\u2028|\u2029)/g, "\n");
}

function compareVersion() {
    var v1 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
    var v2 = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "";
    v1 = v1.split(".");
    v2 = v2.split(".");
    var len = Math.max(v1.length, v2.length);
    while (v1.length < len) {
        v1.push("0");
    }
    while (v2.length < len) {
        v2.push("0");
    }
    for (var i = 0; i < len; i++) {
        var num1 = parseInt(v1[i], 10);
        var num2 = parseInt(v2[i], 10);
        if (num1 > num2) {
            return 1;
        } else if (num1 < num2) {
            return -1;
        }
    }
    return 0;
}

function toLowerLine() {
    var str = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
    return str.replace(/([A-Z])/g, "_$1").toLowerCase();
}

function subMaxLengthString() {
    var str = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
    var maxLength = arguments[1];
    // let ranges = [
    //   '\ud83c[\udf00-\udfff]',
    //   '\ud83d[\udc00-\ude4f]',
    //   '\ud83d[\ude80-\udeff]',
    //   '\S', // eslint-disable
    // ]
        var arr = str.match(/\ud83c[\udf00-\udfff]|\ud83d[\udc00-\ude4f]|\ud83d[\ude80-\udeff]|\S/g);
    var length = arr.length;
    var newArr = [];
    var newArrLength = 0;
    if (length > maxLength) {
        arr.some(function(item) {
            if (newArrLength > maxLength - 3) {
                return true;
            }
            newArr.push(item);
            newArrLength++;
        });
        return newArr.join("") + "...";
    }
    return str;
}