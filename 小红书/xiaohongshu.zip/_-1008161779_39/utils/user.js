Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function() {
    function defineProperties(target, props) {
        for (var i = 0; i < props.length; i++) {
            var descriptor = props[i];
            descriptor.enumerable = descriptor.enumerable || false;
            descriptor.configurable = true;
            if ("value" in descriptor) descriptor.writable = true;
            Object.defineProperty(target, descriptor.key, descriptor);
        }
    }
    return function(Constructor, protoProps, staticProps) {
        if (protoProps) defineProperties(Constructor.prototype, protoProps);
        if (staticProps) defineProperties(Constructor, staticProps);
        return Constructor;
    };
}();

var _api = require("./api");

var _api2 = _interopRequireDefault(_api);

var _enum = require("./enum");

var _user = require("../services/user");

var _path = require("./path");

var _abTest = require("./ab-test");

var _abTest2 = _interopRequireDefault(_abTest);

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}

var User = function() {
    function User() {
        _classCallCheck(this, User);
        this.platform = this.getPlatform();
        this.cacheUserInfo = null;
    }
    _createClass(User, [ {
        key: "getPlatform",
        value: function getPlatform() {
            var platform = _api2.default.getSystemInfoSync().platform;
            return platform === "devtools" ? "ios" : platform;
        }
        // 从缓存获取用户信息
        }, {
        key: "getUserInfo",
        value: function getUserInfo() {
            var result = {};
            if (this.cacheUserInfo) {
                result = this.cacheUserInfo;
            } else {
                result = _api2.default.getStorageSync(_enum.STORAGE_KEY.USER_INFO) || {};
                this.cacheUserInfo = result;
            }
            return result;
        }
        // 获取新打点需要的用户信息
        }, {
        key: "getEagletUserInfo",
        value: function getEagletUserInfo() {
            var userInfo = this.getUserInfo();
            var exp = _abTest2.default.getExpIds();
            var expIdsTrace = _abTest2.default.getExpIdsTrace();
            var _userInfo$appUserInfo = userInfo.appUserInfo, appUserInfo = _userInfo$appUserInfo === undefined ? {} : _userInfo$appUserInfo;
            return {
                exp: exp,
                userId: userInfo.appUserId,
                wxOpenid: userInfo.openid || "",
                wxUnionid: userInfo.unionid || "",
                mpIsAppUser: appUserInfo.isAppUser,
                mpIsNewMpUser: userInfo.isNewWxmpUser,
                expIdsTrace: expIdsTrace
            };
        }
        // 获取用户sid
        }, {
        key: "getSid",
        value: function getSid() {
            var userInfo = this.getUserInfo();
            var sid = userInfo.sid && userInfo.sid !== "undefined" ? userInfo.sid : "";
            return sid;
        }
        // 获取用户id
        }, {
        key: "getUserId",
        value: function getUserId() {
            var userInfo = this.getUserInfo();
            return userInfo.appUserId || "";
        }
    }, {
        key: "getNickname",
        value: function getNickname() {
            var userInfo = this.getUserInfo();
            var appUserInfo = userInfo.appUserInfo;
            appUserInfo = appUserInfo || {};
            return appUserInfo.nickname || "";
        }
    }, {
        key: "getWeixinNickname",
        value: function getWeixinNickname() {
            var userInfo = this.getUserInfo();
            var wxUserInfo = userInfo.wxUserInfo;
            wxUserInfo = wxUserInfo || {};
            return wxUserInfo.nickname || "";
        }
    }, {
        key: "getWxUserInfo",
        value: function getWxUserInfo() {
            var userInfo = this.getUserInfo();
            var wxUserInfo = userInfo.wxUserInfo;
            wxUserInfo = wxUserInfo || {};
            return wxUserInfo;
        }
    }, {
        key: "setWxUserInfo",
        value: function setWxUserInfo() {
            var wxUserInfo = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            if (!wxUserInfo.avatar || !wxUserInfo.nickname) {
                return;
            }
            var userInfo = this.getUserInfo();
            userInfo.wxUserInfo = wxUserInfo;
            this.setUserInfo(userInfo);
        }
    }, {
        key: "isMale",
        value: function isMale() {
            var userInfo = this.getUserInfo();
            var appUserInfo = userInfo.appUserInfo;
            appUserInfo = appUserInfo || {};
            return appUserInfo.gender === 0;
        }
    }, {
        key: "setWxUserInfoGender",
        value: function setWxUserInfoGender(gender) {
            var userInfo = this.getUserInfo();
            var wxUserInfo = userInfo.wxUserInfo;
            wxUserInfo = wxUserInfo || {};
            wxUserInfo.gender = gender;
            this.setUserInfo(userInfo);
        }
    }, {
        key: "isMaleByWeixin",
        value: function isMaleByWeixin() {
            var userInfo = this.getUserInfo();
            var wxUserInfo = userInfo.wxUserInfo;
            wxUserInfo = wxUserInfo || {};
            return wxUserInfo.gender === 1;
        }
        // ---------------------------通过读取缓存中的sid，判断是否登陆----------------------------
        // 检查登陆态，是否有sid
        }, {
        key: "checkLogin",
        value: function checkLogin() {
            var userInfo = this.getUserInfo();
            return Boolean(userInfo.appUserId);
        }
        // 检查登陆过期
        }, {
        key: "checkSession",
        value: function checkSession() {
            return new Promise(function(resolve, reject) {
                var clock = setTimeout(function() {
                    // 打点
                    console.error("check_session_error");
                    // eslint-disable-line
                                        reject();
                }, 3e3);
                wx.checkSession({
                    success: function success() {
                        if (clock) {
                            clearTimeout(clock);
                        }
                        resolve();
                    },
                    fail: function fail() {
                        if (clock) {
                            clearTimeout(clock);
                        }
                        reject();
                    }
                });
            });
        }
        // 提供给业务代码使用，确认是否登陆
        }, {
        key: "ensureLogin",
        value: function ensureLogin() {
            var _this = this;
            return new Promise(function(resolve) {
                var isLogin = _this.checkLogin();
                if (isLogin) {
                    resolve();
                } else {
                    _this.goToLogin();
                }
            });
        }
    }, {
        key: "goToLogin",
        value: function goToLogin() {
            var userInfo = this.getUserInfo();
            // 有sid但是sid失效的情况置空当新用户处理
                        if (userInfo.sid) {
                userInfo.sid = "";
                this.setUserInfo(userInfo).then(function() {
                    _api2.default.showToast({
                        title: "登录过期",
                        icon: "loading",
                        success: function success() {
                            (0, _path.navigateTo)("LoginIndex");
                        }
                    });
                });
                return;
            }
            (0, _path.navigateTo)("LoginIndex");
        }
        // ----------------------------通过code获取用户信息，并存入缓存----------------------------
        // 获取临时登录凭证code
        }, {
        key: "privateGetWeixinCode",
        value: function privateGetWeixinCode() {
            return new Promise(function(resolve) {
                _api2.default.login({
                    timeout: 5e3,
                    success: function success() {
                        var data = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
                        resolve(data.code);
                    },
                    fail: function fail() {
                        resolve();
                    }
                });
            });
        }
        // 将用户信息存入缓存
        }, {
        key: "setUserInfo",
        value: function setUserInfo() {
            var data = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            var oldData = this.getUserInfo();
            var newData = Object.assign({}, oldData, data, {
                updateTime: new Date().getTime()
            });
            var self = this;
            // 检测authorization
                        if (!newData.authorization) {
                console.error("no authorization !!!");
                // eslint-disable-line
                        }
            return new Promise(function(resolve) {
                _api2.default.setStorage({
                    key: _enum.STORAGE_KEY.USER_INFO,
                    data: newData,
                    success: function success() {
                        // 更新缓存
                        self.cacheUserInfo = newData;
                        // 更新新打点信息
                                                try {
                            var newTrackUserInfo = self.getEagletUserInfo();
                            wx.$eaglet.resetABInfo(newTrackUserInfo);
                        } catch (error) {
                            // 新打点
                            console.log(error);
                            // eslint-disable-line
                                                }
                        resolve(newData);
                    },
                    fail: function fail() {
                        resolve(false);
                    }
                });
            });
        }
        // 通过code获取用户信息
        }, {
        key: "loginWithCode",
        value: function loginWithCode() {
            var _this2 = this;
            var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            var noAutoGoToLogin = options.noAutoGoToLogin, forceWeixinLogin = options.forceWeixinLogin;
            return new Promise(function(resolve, reject) {
                _this2.privateGetWeixinCode().then(function(code) {
                    if (!code) {
                        reject();
                        return;
                    }
                    var userInfo = _this2.getUserInfo();
                    var isPhoneLogin = userInfo.isPhoneLogin, phone = userInfo.phone, zone = userInfo.zone;
                    // 判断是否上次是手机号登录的
                                        if (isPhoneLogin && !forceWeixinLogin) {
                        (0, _user.telephoneLogin)({
                            phone: phone,
                            zone: zone,
                            weixin_code: code
                        }).then(function() {
                            var data = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
                            _this2.setUserInfo({
                                userId: data.userId,
                                authorization: data.authorization,
                                openid: data.openid,
                                sid: data.sessionId,
                                unionid: data.unionid,
                                appUserId: data.appUserId,
                                appUserInfo: data.appUserInfo,
                                wxUserInfo: data.wxUserInfo,
                                isNewWxmpUser: data.isNewWxmpUser
                            }).then(function(data) {
                                resolve(data);
                            });
                        }).catch(function() {
                            if (!noAutoGoToLogin) {
                                _this2.goToLogin();
                                reject();
                            } else {
                                resolve();
                            }
                        });
                    } else {
                        // 直接用微信信息登录
                        (0, _user.loginWithCode)(code, userInfo.token).then(function() {
                            var data = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
                            _this2.setUserInfo({
                                userId: data.userId,
                                authorization: data.authorization,
                                openid: data.openid,
                                sid: data.sessionId,
                                unionid: data.unionid,
                                appUserId: data.appUserId,
                                appUserInfo: data.appUserInfo,
                                wxUserInfo: data.wxUserInfo,
                                isNewWxmpUser: data.isNewWxmpUser
                            }).then(function(data) {
                                resolve(data);
                            });
                        }).catch(function() {
                            reject();
                        });
                    }
                });
            });
        }
        // ------------------------------LOGIN_PAGE---------------------------------
        // 发送授权得到的用户微信信息判断是否注册过APP,注册过直接登录APP返回用户态
        // deprecated
        }, {
        key: "loginWithWeixinUserInfo",
        value: function loginWithWeixinUserInfo() {
            var data = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            data.platform = this.platform;
            var token = this.getUserInfo().token || "";
            return (0, _user.postUserInfoToServerAndGetSid)(data, token);
        }
        // 在loginWithWeixinUserInfo基础上提前更新code
        }, {
        key: "loginWithWeixinUserInfoAndCode",
        value: function loginWithWeixinUserInfoAndCode() {
            var _this3 = this;
            var data = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            return new Promise(function(resolve, reject) {
                // 先刷新auth
                _this3.loginWithCode({
                    noAutoGoToLogin: true,
                    forceWeixinLogin: true
                }).then(function() {
                    data.platform = _this3.platform;
                    var token = _this3.getUserInfo().token || "";
                    (0, _user.postUserInfoToServerAndGetSid)(data, token).then(function(res) {
                        resolve(res);
                    }).catch(function() {
                        reject();
                        wx.showToast({
                            title: "登录失败，请稍候重试",
                            icon: "none",
                            duration: 2e3
                        });
                    });
                });
            });
        }
        // 通过授权手机号获取用户信息
        }, {
        key: "loginWidthEncryptedData",
        value: function loginWidthEncryptedData(_ref) {
            var encryptedData = _ref.encryptedData, iv = _ref.iv;
            var _getUserInfo = this.getUserInfo(), token = _getUserInfo.token, openid = _getUserInfo.openid;
            var data = {
                encryptedData: encryptedData,
                iv: iv,
                platform: this.platform,
                openid: openid
            };
            return (0, _user.WXMobileLogin)(data, token || "");
        }
        // 打开设置页面重新授权
        }, {
        key: "openSettingModal",
        value: function openSettingModal(successCB, failCB) {
            var config = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
            var title = config.title, confirmText = config.confirmText, cancelText = config.cancelText, content = config.content;
            _api2.default.showModal({
                title: title || "打开设置页面重新授权",
                content: content,
                confirmText: confirmText || "去设置",
                cancelText: cancelText || "取消",
                success: function success(data) {
                    if (data.confirm) {
                        _api2.default.openSetting({
                            success: function success(res) {
                                successCB(res);
                            }
                        });
                    } else {
                        failCB && failCB();
                    }
                }
            });
        }
    } ]);
    return User;
}();

exports.default = new User();