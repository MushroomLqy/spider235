Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.shortenNumber = shortenNumber;

function shortenNumber(num) {
    if (!/^\d+$/.test(num)) {
        console.error("参数需要是自然数");
        return num;
    }
    if (num < 1e4) {
        return String(parseInt(String(num), 10));
    }
    var newNum = Math.round(num / 1e3) / 10;
    // ensure it only has one-digital decimal.
        if (newNum < 1e4) {
        return String(newNum) + "万";
    }
    newNum = Math.round(newNum / 1e3) / 10;
    return String(newNum) + "亿";
}