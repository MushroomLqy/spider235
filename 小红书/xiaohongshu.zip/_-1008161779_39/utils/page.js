Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.DEFAULT_PAGINATION_ARGS = exports.DEFAULT_PAGINATION = exports.getNavigationBarInfo = exports.getScreenRatio = exports.getTrueFullScreenHeight = exports.getTrueScreenHeight = exports.getTopSectionHeight = exports.getTrueStatusBarHeight = exports.getNavigationBarHeight = exports.getNavigationTabBarHeight = exports.androidDeviationHeight = exports.isShowBackIcon = exports.isShowHomePage = exports.widthHeightLikeWhichPhoneModel = exports.getSystemInfo = exports.IPHONE_X = exports.IPHONE_8P = exports.IPHONE_8 = exports.IPHONE_5 = undefined;

exports.hasMorePage = hasMorePage;

exports.createNextPageArgs = createNextPageArgs;

exports.mapPage = mapPage;

var _path = require("./path");

var _string = require("./string");

var _routes = require("../routes");

var _api = require("./api");

var _api2 = _interopRequireDefault(_api);

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

var IPHONE_5 = exports.IPHONE_5 = "iPhone 5";

var IPHONE_8 = exports.IPHONE_8 = "iPhone 8";

var IPHONE_8P = exports.IPHONE_8P = "iPhone 8P";

var IPHONE_X = exports.IPHONE_X = "iPhone X";

var getSystemInfo = exports.getSystemInfo = function getSystemInfo() {
    var result = _api2.default.getSystemInfoSync();
    return result;
};

var noCareLiveSystemInfo = getSystemInfo();

var isAndroid = function isAndroid() {
    var systemInfo = noCareLiveSystemInfo;
    return systemInfo.platform === "android";
};

var widthHeightLikeWhichPhoneModel = exports.widthHeightLikeWhichPhoneModel = function widthHeightLikeWhichPhoneModel() {
    var systemInfo = noCareLiveSystemInfo;
    if (systemInfo.windowWidth <= 320) {
        return IPHONE_5;
    } else if (systemInfo.windowWidth === 375 && systemInfo.widthHeight === 667) {
        return IPHONE_8;
    } else if (systemInfo.windowWidth >= 375 && systemInfo.windowWidth <= 414) {
        return IPHONE_8P;
    } else if (systemInfo.windowWidth === 375 && systemInfo.windowHeight >= 736) {
        return IPHONE_X;
    }
};

var isShowHomePage = exports.isShowHomePage = function isShowHomePage(path) {
    var list = [ _routes.RouteMap.HomePage, _routes.RouteMap.StoreHomePage, _routes.RouteMap.UserCenterPage, _routes.RouteMap.ExperienceProduct, _routes.RouteMap.GameCompetition, _routes.RouteMap.GameCompetitionChoice, _routes.RouteMap.GameCompetitionLoading, _routes.RouteMap.GameCompetitionResult ];
    var result = true;
    list.some(function(item) {
        if (item === path) {
            result = false;
            return true;
        }
    });
    return result;
};

var isShowBackIcon = exports.isShowBackIcon = function isShowBackIcon(path) {
    var list = [ _routes.RouteMap.GameCompetitionChoice, _routes.RouteMap.GameCompetitionLoading ];
    var result = true;
    list.some(function(item) {
        if (item === path) {
            result = false;
            return true;
        }
    });
    return result;
};

var androidDeviationHeight = exports.androidDeviationHeight = 3;

var getNavigationTabBarHeight = exports.getNavigationTabBarHeight = function getNavigationTabBarHeight() {
    var systemInfo = getSystemInfo();
    return systemInfo.windowHeight - systemInfo.windowHeight;
};

var rpx2px = function rpx2px(rpx, windowWidth) {
    return rpx * windowWidth / 750;
};

var getNavigationBarHeight = exports.getNavigationBarHeight = function getNavigationBarHeight() {
    var height = 88;
    var _getSystemInfo = getSystemInfo(), windowWidth = _getSystemInfo.windowWidth;
    if (isAndroid()) {
        height = 100;
    }
    return Math.floor(rpx2px(height, windowWidth));
};

var getTrueStatusBarHeight = exports.getTrueStatusBarHeight = function getTrueStatusBarHeight() {
    var systemInfo = getSystemInfo();
    var height = systemInfo.statusBarHeight;
    if (isAndroid()) {
        height += 3;
    }
    return height;
};

var getTopSectionHeight = exports.getTopSectionHeight = function getTopSectionHeight() {
    var systemInfo = getSystemInfo();
    var navigationBarTrueHeight = getNavigationBarHeight();
    // let statusBarHeight = getTrueStatusBarHeight()
        var height = systemInfo.statusBarHeight + navigationBarTrueHeight;
    if (isAndroid()) {
        height -= 5;
    }
    return height;
};

var getTrueScreenHeight = exports.getTrueScreenHeight = function getTrueScreenHeight() {
    var systemInfo = getSystemInfo();
    var height = systemInfo.windowHeight - getTopSectionHeight();
    if (isAndroid() && systemInfo.windowHeight <= systemInfo.windowHeight) {
        height = systemInfo.windowHeight - getTopSectionHeight();
    }
    return height;
};

var getTrueFullScreenHeight = exports.getTrueFullScreenHeight = function getTrueFullScreenHeight() {
    var systemInfo = getSystemInfo();
    var fullHeight = getTrueScreenHeight();
    if (isAndroid() && systemInfo.windowHeight !== systemInfo.windowHeight) {
        fullHeight += systemInfo.statusBarHeight;
    }
    return fullHeight;
};

var getScreenRatio = exports.getScreenRatio = function getScreenRatio() {
    var systemInfo = getSystemInfo();
    var width = systemInfo.windowWidth;
    var height = systemInfo.windowHeight;
    var ratio = height / width;
    return ratio >= 1.9;
};

var getNavigationBarInfo = exports.getNavigationBarInfo = function getNavigationBarInfo() {
    var result = {
        canCustom: true,
        noShow: false
    };
    var systemInfo = _api2.default.getSystemInfoSync();
    // eslint-disable-line
        var canUseVersion = "6.6.0";
    if ((0, _string.compareVersion)(systemInfo.version, canUseVersion) === -1) {
        result.canCustom = false;
    }
    var currentPage = (0, _path.getPageUrl)();
    _routes.NoNavigationBarRoutes.some(function(route) {
        if (currentPage.route === route) {
            result.noShow = true;
            return true;
        }
    });
    return result;
};

var DEFAULT_PAGINATION = exports.DEFAULT_PAGINATION = {
    PAGE: 1,
    PAGE_SIZE: 10,
    HAS_MORE: true
};

var DEFAULT_PAGINATION_ARGS = exports.DEFAULT_PAGINATION_ARGS = {
    page: DEFAULT_PAGINATION.PAGE,
    pageSize: DEFAULT_PAGINATION.PAGE_SIZE,
    hasMore: DEFAULT_PAGINATION.HAS_MORE
};

function hasMorePage() {
    var pagination = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    pagination = pagination || {};
    return Boolean(pagination.hasMore);
}

function createNextPageArgs() {
    var pagination = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    if (pagination && !pagination.hasMore) {
        console.log("[page] call create next page with hasMore=false");
        // eslint-disable-line
        }
    return {
        page: pagination.page + 1,
        pageSize: pagination.pageSize,
        hasMore: pagination.hasMore
    };
}

function mapPage(oldList) {
    var newList = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];
    var pagination = arguments[2];
    var page = pagination.page, pageSize = pagination.pageSize;
    var hasMore = void 0;
    var list = void 0;
    if (newList.length === pageSize) {
        hasMore = true;
    } else if (newList.length < pageSize) {
        hasMore = false;
    } else {
        console.log("[page] pageSize is not matched, except: " + pageSize + ", now " + newList.length);
        // eslint-disable-line
                hasMore = true;
    }
    if (page === 1) {
        list = newList;
    } else if (page > 1) {
        list = oldList.concat(newList);
    }
    return {
        list: list,
        pagination: {
            page: page,
            pageSize: pageSize,
            hasMore: hasMore
        }
    };
}