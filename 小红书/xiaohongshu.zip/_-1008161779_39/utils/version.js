Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.versionCompare = versionCompare;

function versionToNumber(version, length, exponent) {
    var arr;
    if (arguments.length < 3) {
        return 0;
    }
    arr = version.split(".");
    version = 0;
    arr.forEach(function(value, index, array) {
        version += value * Math.pow(10, length * exponent - 1);
        length--;
    });
    return version;
}

function versionCompare(version, targetVersion, exponent) {
    var getVersionNumber, length;
    exponent = exponent || 2;
    if (!version || !targetVersion) {
        throw new Error("Need two versions to compare!");
    }
    if (version === targetVersion) {
        return 0;
    }
    length = Math.max(version.split(".").length, targetVersion.split(".").length);
    getVersionNumber = function(length, exponent) {
        return function(version) {
            return versionToNumber(version, length, exponent);
        };
    }(length, exponent);
    version = getVersionNumber(version);
    targetVersion = getVersionNumber(targetVersion);
    return version > targetVersion ? 1 : version < targetVersion ? -1 : 0;
}