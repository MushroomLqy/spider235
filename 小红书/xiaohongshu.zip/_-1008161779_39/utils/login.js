Object.defineProperty(exports, "__esModule", {
    value: true
});

var _user = require("./user");

var _user2 = _interopRequireDefault(_user);

var _abTest = require("./ab-test");

var _abTest2 = _interopRequireDefault(_abTest);

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

var isShowLoginModal = false;

// 冷启动才能出现
exports.default = {
    canShowLoginModal: function canShowLoginModal() {
        if (isShowLoginModal) {
            return false;
        }
        if (_abTest2.default.getABTestFlagValue("wx_mp_login_modal") !== 1) {
            return false;
        }
        var pages = getCurrentPages();
        // eslint-disable-line
                var currentPage = pages && pages.length > 0 ? pages[pages.length - 1] : null;
        // 中转的页面不展示
                if (!currentPage || currentPage.options && currentPage.options.redirect_path) {
            return false;
        }
        // 已授权登录用户不展示
                if (_user2.default.getUserId()) {
            return false;
        }
        isShowLoginModal = true;
        return true;
    },
    isAuth: function isAuth(scope) {
        return new Promise(function(resolve) {
            wx.getSetting({
                success: function success(res) {
                    if (!res.authSetting["scope." + scope]) {
                        resolve(false);
                    } else {
                        resolve(true);
                    }
                },
                fail: function fail() {
                    resolve(false);
                }
            });
        });
    },
    saveUserInfo: function saveUserInfo() {
        var userInfo = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
        _user2.default.setUserInfo({
            token: userInfo.userId,
            openid: userInfo.openid,
            sid: userInfo.sessionId,
            authorization: userInfo.authorization,
            appUserId: userInfo.appUserId,
            appUserInfo: userInfo.appUserInfo,
            isPhoneLogin: userInfo.isPhoneLogin
        });
    },
    goToSetting: function goToSetting() {
        _user2.default.openSettingModal(function(modalRes) {
            if (modalRes.authSetting["scope.userInfo"]) {}
        });
    }
};