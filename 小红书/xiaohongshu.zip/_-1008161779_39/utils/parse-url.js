Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.isUriProtocol = isUriProtocol;

exports.isUriSymbol = isUriSymbol;

exports.transUriSymbolToSafe = transUriSymbolToSafe;

exports.transUriProtocolToSafe = transUriProtocolToSafe;

exports.transUriToSafe = transUriToSafe;

exports.changeQuery = changeQuery;

exports.cleanSpecialKeys = cleanSpecialKeys;

exports.getAbsoluteLink = getAbsoluteLink;

exports.setSafeProtocol = setSafeProtocol;

var _urlParse = require("./../karin_npm/url-parse/index.js");

var _urlParse2 = _interopRequireDefault(_urlParse);

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

var URI_PROTOCOL = /^https?:/;

var URI_SYMBOL = /^\/\//;

function isUriProtocol(apiKey) {
    return URI_PROTOCOL.test(apiKey);
}

function isUriSymbol(apiKey) {
    return URI_SYMBOL.test(apiKey);
}

function transUriSymbolToSafe(apiKey) {
    return apiKey.replace(URI_SYMBOL, "https://");
}

function transUriProtocolToSafe(apiKey) {
    return apiKey.replace(URI_PROTOCOL, "https:");
}

function transUriToSafe(apiKey) {
    if (isUriProtocol(apiKey)) {
        return transUriProtocolToSafe(apiKey);
    }
    if (isUriSymbol(apiKey)) {
        return transUriSymbolToSafe(apiKey);
    }
    return apiKey;
}

function changeQuery() {
    var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var link = options.link, type = options.type, key = options.key, value = options.value;
    if (!link) {
        return "";
    }
    if (!type) {
        return link;
    }
    var setType = "set";
    var removeType = "remove";
    if ([ setType, removeType ].indexOf(type) === -1) {
        return link;
    }
    var parsedurl = (0, _urlParse2.default)(link);
    var setValue = value || "";
    var arr = [];
    var returnArr = [];
    var hasKey = false;
    if (parsedurl.query.indexOf("?") > -1) {
        arr = parsedurl.query.split("?")[1].split("&");
    }
    arr.forEach(function(item) {
        if (type === removeType) {
            if (item.indexOf(key + "=") === -1) {
                returnArr.push(item);
            }
        } else if (type === setType) {
            if (item.indexOf(key + "=") > -1) {
                hasKey = true;
                returnArr.push(key + "=" + setValue);
            } else {
                returnArr.push(item);
            }
        }
    });
    if (type === setType && !hasKey) {
        returnArr.push(key + "=" + setValue);
    }
    parsedurl.set("query", "?" + returnArr.join("&"));
    return parsedurl.toString();
}

function cleanSpecialKeys() {
    var link = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
    var result = link;
    result = result.replace("?sid", "?mp_env=2&sid");
    result = result.replace(/[&|?]sid=session\.[\d]{19}/g, "");
    return result;
}

function getAbsoluteLink() {
    var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var link = options.link;
    if (!link) {
        return "";
    }
    var pagesHost = "pages.xiaohongshu.com";
    var normalHost = "www.xiaohongshu.com";
    var pagesPathRegex = [ /\/goods\/[\S]{24}/, /\/vendor\/[\S]{24}\/events\/[\S]{24}/ ];
    if (link.indexOf("/") !== 0 && link.indexOf("http") !== 0) {
        link = "//" + link;
    }
    var parsedurl = (0, _urlParse2.default)(link);
    // 补充协议 ip 地址的path不强制转成https
        if ([ pagesHost, normalHost ].indexOf(parsedurl.hostname) > -1 || !parsedurl.hostname) {
        parsedurl.set("protocol", "https:");
    }
    // 补充host
        if (!parsedurl.host || parsedurl.hostname === "127.0.0.1") {
        parsedurl.set("host", normalHost);
        parsedurl.set("protocol", "https:");
        var needPagesHost = false;
        pagesPathRegex.some(function(check) {
            if (check.test(parsedurl.pathname)) {
                needPagesHost = true;
                return true;
            }
        });
        if (needPagesHost) {
            parsedurl.set("host", pagesHost);
        }
    }
    return parsedurl.toString();
}

function setSafeProtocol() {
    var link = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
    if (!link) {
        return link;
    }
    var parsedurl = (0, _urlParse2.default)(link);
    parsedurl.set("protocol", "https:");
    return parsedurl.toString();
}