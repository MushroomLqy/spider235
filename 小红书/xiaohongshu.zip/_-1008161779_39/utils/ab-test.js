Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function() {
    function defineProperties(target, props) {
        for (var i = 0; i < props.length; i++) {
            var descriptor = props[i];
            descriptor.enumerable = descriptor.enumerable || false;
            descriptor.configurable = true;
            if ("value" in descriptor) descriptor.writable = true;
            Object.defineProperty(target, descriptor.key, descriptor);
        }
    }
    return function(Constructor, protoProps, staticProps) {
        if (protoProps) defineProperties(Constructor.prototype, protoProps);
        if (staticProps) defineProperties(Constructor, staticProps);
        return Constructor;
    };
}();

var _api = require("./api");

var _api2 = _interopRequireDefault(_api);

var _enum = require("./enum");

var _feApiSign = require("./fe-api-sign");

var _system = require("../services/system");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}

var AbTest = function() {
    function AbTest() {
        _classCallCheck(this, AbTest);
        this.gotDataFromApi = false;
        this.isFetchingApi = false;
        this.queues = [];
        // ab缓存数据
                this.cacheDatas = null;
    }
    _createClass(AbTest, [ {
        key: "privateGetCacheDatas",
        value: function privateGetCacheDatas() {
            if (this.cacheDatas) {
                return this.cacheDatas;
            }
            var datas = _api2.default.getStorageSync(_enum.STORAGE_KEY.AB_TEST);
            var _ref = datas || {}, expIds = _ref.expIds, flags = _ref.flags;
            this.cacheDatas = {
                expIds: expIds || [],
                flags: flags || {}
            };
            return this.cacheDatas;
        }
    }, {
        key: "init",
        value: function init() {
            var _this = this;
            var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            var setReadyAndclear = function setReadyAndclear() {
                _this.gotDataFromApi = true;
                _this.clearQueue();
            };
            var self = this;
            // 这里要小心，所有链路都需要清空队列
                        return new Promise(function(resolve) {
                var _ref2 = options || {}, openid = _ref2.openid;
                if (!openid || _this.gotDataFromApi) {
                    // 清除队列
                    setReadyAndclear();
                    resolve();
                    return;
                }
                (0, _system.getAbTest)({
                    type: "wechat",
                    openid: openid
                }).then(function(data) {
                    var formatedData = {
                        expIds: data.expIds || [],
                        flags: data.flags || [],
                        expIdsTrace: data.expIdsTrace || ""
                    };
                    self.cacheDatas = formatedData;
                    _api2.default.setStorageSync(_enum.STORAGE_KEY.AB_TEST, formatedData);
                    // 清除队列
                                        setReadyAndclear();
                    resolve();
                }).catch(function() {
                    // 清除队列
                    setReadyAndclear();
                    resolve();
                });
            });
        }
    }, {
        key: "clearQueue",
        value: function clearQueue() {
            if (this.queues && this.queues.length > 0) {
                this.queues.forEach(function(callback) {
                    callback && callback();
                });
                this.queues = [];
            }
        }
    }, {
        key: "AddQueue",
        value: function AddQueue(doSomething) {
            this.queues.push(doSomething);
        }
    }, {
        key: "checkReady",
        value: function checkReady() {
            return this.gotDataFromApi;
        }
    }, {
        key: "getExpIdsTrace",
        value: function getExpIdsTrace() {
            var datas = this.privateGetCacheDatas();
            return datas.expIdsTrace || "";
        }
    }, {
        key: "getExpIds",
        value: function getExpIds() {
            var datas = this.privateGetCacheDatas();
            return datas.expIds || [];
        }
    }, {
        key: "getABTestFlagValue",
        value: function getABTestFlagValue(strA, strB) {
            var datas = this.privateGetCacheDatas();
            var _ref3 = datas || {}, expIds = _ref3.expIds, flags = _ref3.flags;
            var result = void 0;
            flags = flags || {};
            expIds = expIds || [];
            // 通过实验组id 查找
                        if (strA && strB && strB === "exp") {
                expIds.some(function(exp) {
                    if (exp.indexOf(strA) === 0) {
                        result = exp.substr(strA.length, 1);
                        return true;
                    }
                });
            }
            // 通过flag查找
                        var flagValue = flags[strA];
            if (flagValue !== undefined) {
                result = flagValue;
            }
            return result;
        }
    } ]);
    return AbTest;
}();

exports.default = new AbTest();