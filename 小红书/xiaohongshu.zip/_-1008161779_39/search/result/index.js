// search/result/index.js
Page({data: {}})