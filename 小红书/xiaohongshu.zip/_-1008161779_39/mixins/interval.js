Object.defineProperty(exports, "__esModule", {
    value: true
});

var _interval = require("../utils/interval");

var _interval2 = _interopRequireDefault(_interval);

var _path = require("../utils/path");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

var IntervalMixinIsHided = {};

exports.default = Behavior({
    data: {
        IntervalMixinPageKey: null
    },
    created: function created() {
        var _getPageUrl = (0, _path.getPageUrl)(), url = _getPageUrl.url;
        this.data.IntervalMixinPageKey = url;
    },
    IntervalMixinSleep: function IntervalMixinSleep() {
        _interval2.default.sleep(this.data.IntervalMixinPageKey);
    },
    IntervalMixinWakeUp: function IntervalMixinWakeUp() {
        _interval2.default.wakeUp(this.data.IntervalMixinPageKey);
    },
    onUnload: function onUnload() {
        this.IntervalMixinSleep();
    },
    onHide: function onHide() {
        var _getPageUrl2 = (0, _path.getPageUrl)(), url = _getPageUrl2.url;
        IntervalMixinIsHided[url] = true;
        this.IntervalMixinSleep();
    },
    onShow: function onShow() {
        var _getPageUrl3 = (0, _path.getPageUrl)(), url = _getPageUrl3.url;
        if (IntervalMixinIsHided[url]) {
            this.IntervalMixinWakeUp();
        }
    }
});