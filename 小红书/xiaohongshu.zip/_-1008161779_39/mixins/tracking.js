Object.defineProperty(exports, "__esModule", {
    value: true
});

var _enum = require("../utils/enum");

var _api = require("../utils/api");

var _api2 = _interopRequireDefault(_api);

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

exports.default = Behavior({
    data: {
        user: {
            openid: "",
            id: ""
        },
        xhsgs: "",
        xhsGS: ""
    },
    created: function created(info) {
        var _this = this;
        var globalData = _api2.default.getGlobalData();
        var promise = globalData.promise;
        if (promise) {
            promise.then(function() {
                _this.mixinsInitInfo(info);
            });
        }
    },
    mixinsInitInfo: function mixinsInitInfo(info) {
        var _wx$getStorageSync = wx.getStorageSync(_enum.STORAGE_KEY.USER_INFO), openid = _wx$getStorageSync.openid, token = _wx$getStorageSync.token, sid = _wx$getStorageSync.sid;
        // eslint-disable-line
                this.data.user = {
            openid: openid,
            id: token,
            sid: sid
        };
        this.data.xhsgs = info.xhs_g_s || info.xhsGS;
        this.data.xhsGS = info.xhs_g_s || info.xhsGS;
    }
});