Object.defineProperty(exports, "__esModule", {
    value: true
});

var _path = require("../utils/path");

var _user = require("../utils/user");

var _user2 = _interopRequireDefault(_user);

var _api = require("../utils/api");

var _api2 = _interopRequireDefault(_api);

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

var MAX_NAVIGATE_TO_LOGIN_PAGE_COUNT = 2;

exports.default = Behavior({
    created: function created() {
        if (!_user2.default.checkLogin() && _api2.default.$instance.globalData.promise) {
            _api2.default.$instance.globalData.promise.then(function() {
                var data = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
                console.log("login", data);
                // eslint-disable-line
                                if (!data.sid) {
                    // 用户超过30秒未登录则在切换页面的时候再提醒一次
                    var now = Date.now();
                    var lastNavigateToLoginTime = _api2.default.$instance.globalData.navigateToLoginPageTime;
                    if (_api2.default.$instance.globalData.navigateToLoginPageCount < MAX_NAVIGATE_TO_LOGIN_PAGE_COUNT && (!lastNavigateToLoginTime || now - lastNavigateToLoginTime > 3e4)) {
                        _api2.default.$instance.globalData.navigateToLoginPageCount++;
                        _api2.default.$instance.globalData.navigateToLoginPageTime = now;
                        (0, _path.navigateTo)("LoginIndex");
                    }
                }
            }, function(err) {
                // 异常情况
                console.log("login-fail", err);
                // eslint-disable-line
                        });
        }
    }
});