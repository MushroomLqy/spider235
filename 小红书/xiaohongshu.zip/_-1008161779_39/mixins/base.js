Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.default = BaseMixin;

var _checkLogin = require("./check-login");

var _checkLogin2 = _interopRequireDefault(_checkLogin);

var _tracker = require("./tracker");

var _tracker2 = _interopRequireDefault(_tracker);

var _newbie = require("./newbie");

var _newbie2 = _interopRequireDefault(_newbie);

var _follow = require("./follow");

var _follow2 = _interopRequireDefault(_follow);

var _tracking = require("./tracking");

var _tracking2 = _interopRequireDefault(_tracking);

var _interval = require("./interval");

var _interval2 = _interopRequireDefault(_interval);

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

var MixinMap = {
    CheckLoginMixin: _checkLogin2.default,
    TrackerMixin: _tracker2.default,
    NewbieMixin: _newbie2.default,
    FollowMixin: _follow2.default,
    TrackingMixin: _tracking2.default,
    IntervalMixin: _interval2.default
};

function BaseMixin(ops) {
    var result = [];
    var defaultOps = {
        CheckLoginMixin: true,
        TrackerMixin: true,
        IntervalMixin: true
    };
    var mergedOps = Object.assign({}, defaultOps, ops);
    for (var key in MixinMap) {
        if (mergedOps && mergedOps[key]) {
            result.push(MixinMap[key]);
        }
    }
    return result;
}