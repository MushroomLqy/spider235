Object.defineProperty(exports, "__esModule", {
    value: true
});

var _api = require("../utils/api");

var _api2 = _interopRequireDefault(_api);

var _enum = require("../utils/enum");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

exports.default = Behavior({
    data: {
        newbieFlag: {}
    },
    created: function created() {
        var newbieFlag = _api2.default.getStorageSync(_enum.STORAGE_KEY.NEWBIE_FLAG);
        this.newbieFlag = newbieFlag;
    }
});