Object.defineProperty(exports, "__esModule", {
    value: true
});

var _track = require("../utils/track");

var _api = require("../utils/api");

var _api2 = _interopRequireDefault(_api);

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

exports.default = {
    onLoad: function onLoad() {
        var globalData = _api2.default.getGlobalData();
        var promise = globalData.promise;
        if (promise) {
            promise.then(function() {
                (0, _track.trackPageview)();
            });
        }
    },
    // 左上角返回
    onUnload: function onUnload() {
        (0, _track.trackApm)({
            action: "page_unload"
        });
    }
};