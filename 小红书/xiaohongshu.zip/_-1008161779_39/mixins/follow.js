Object.defineProperty(exports, "__esModule", {
    value: true
});

var _api = require("../utils/api");

var _api2 = _interopRequireDefault(_api);

var _appuser = require("../services/appuser");

var _tracker = require("../services/tracker");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

exports.default = Behavior({
    methods: {
        handleFollow: function handleFollow() {
            var _this = this;
            var item = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            if (item && [ "follows", "both" ].indexOf(item.fstatus) === -1) {
                this.followAppUser(item);
            } else if (item && [ "none" ].indexOf(item.fstatus) === -1) {
                _api2.default.showModal({
                    title: "是否取消关注",
                    confirmText: "确认",
                    cancelText: "取消",
                    success: function success(data) {
                        if (data.confirm) {
                            _this.unfollowAppUser(item);
                        }
                    }
                });
            } else if (item && item.hasOwnProperty("followed") && !item.followed) {
                this.followAppUser(item);
            } else if (item && item.hasOwnProperty("followed") && item.followed) {
                _api2.default.showModal({
                    title: "是否取消关注",
                    // content: '需要获取您的公开信息（昵称、头像等），请到小程序的设置中打开用户信息授权',
                    confirmText: "确认",
                    cancelText: "取消",
                    success: function success(data) {
                        if (data.confirm) {
                            _this.unfollowAppUser(item);
                        }
                    }
                });
            }
        },
        followAppUser: function followAppUser(user) {
            var _this2 = this;
            (0, _appuser.followUser)({
                userId: user.userid || user.id
            }).then(function() {
                _tracker.wxTrack.call(_this2, {
                    action: "follow-tap",
                    label: "follow-button",
                    property: user.userid || user.id
                });
                if (user.hasOwnProperty("followed")) {
                    user.followed = true;
                } else {
                    user.fstatus = "follows";
                }
            });
        },
        unfollowAppUser: function unfollowAppUser(user) {
            var _this3 = this;
            (0, _appuser.unfollowUser)({
                userId: user.userid || user.id
            }).then(function() {
                _tracker.wxTrack.call(_this3, {
                    action: "unfollow-tap",
                    label: "unfollow-button",
                    property: user.userid || user.id
                });
                if (user.hasOwnProperty("followed")) {
                    user.followed = false;
                } else {
                    user.fstatus = "none";
                }
            });
        }
    }
});