// pages/common/login/index.js
Page({data: {}})