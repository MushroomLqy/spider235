// pages/common/login/privacy.js
Page({data: {}})