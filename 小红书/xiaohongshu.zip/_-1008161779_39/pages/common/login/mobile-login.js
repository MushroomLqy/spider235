// pages/common/login/mobile-login.js
Page({data: {}})