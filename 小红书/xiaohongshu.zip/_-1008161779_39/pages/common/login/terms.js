// pages/common/login/terms.js
Page({data: {}})