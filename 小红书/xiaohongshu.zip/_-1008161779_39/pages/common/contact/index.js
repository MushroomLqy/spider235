// pages/common/contact/index.js
Page({data: {}})