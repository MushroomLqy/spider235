// pages/common/not-found/index.js
Page({data: {}})