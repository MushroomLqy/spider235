// pages/common/feedback/index.js
Page({data: {}})