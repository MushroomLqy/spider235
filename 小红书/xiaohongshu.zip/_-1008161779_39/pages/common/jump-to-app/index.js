// pages/common/jump-to-app/index.js
Page({data: {}})