// pages/common/error/index.js
Page({data: {}})