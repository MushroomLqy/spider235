// pages/common/privacy-policy/index.js
Page({data: {}})