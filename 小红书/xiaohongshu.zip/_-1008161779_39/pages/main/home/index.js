var _regenerator = require("./../../../karin_npm/babel-runtime/regenerator/index.js");

var _regenerator2 = _interopRequireDefault(_regenerator);

var _Base = require("./../../../karin_npm/Base64/base64.js");

var _Base2 = _interopRequireDefault(_Base);

var _tracker = require("../../../mixins/tracker");

var _tracker2 = _interopRequireDefault(_tracker);

var _vuefy = require("../../../libs/vuefy.js");

var _eventBus = require("../../../libs/event-bus");

var _eventBus2 = _interopRequireDefault(_eventBus);

var _mp = require("../../../libs/@xhs/protobuf-mp-chakra-tracker/mp.js");

var _track = require("../../../utils/track");

var _verify = require("../../../utils/verify");

var _verify2 = _interopRequireDefault(_verify);

var _path = require("../../../utils/path");

var _user = require("../../../utils/user");

var _user2 = _interopRequireDefault(_user);

var _api = require("../../../utils/api");

var _api2 = _interopRequireDefault(_api);

var _abTest = require("../../../utils/ab-test.js");

var _abTest2 = _interopRequireDefault(_abTest);

var _storage = require("../../../utils/storage");

var _tracker3 = require("../../../services/tracker");

var _note = require("../../../services/note");

var _noteSearch = require("../../../services/note-search");

var _homepage = require("../../../services/homepage");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

function _objectWithoutProperties(obj, keys) {
    var target = {};
    for (var i in obj) {
        if (keys.indexOf(i) >= 0) continue;
        if (!Object.prototype.hasOwnProperty.call(obj, i)) continue;
        target[i] = obj[i];
    }
    return target;
}

function _asyncToGenerator(fn) {
    return function() {
        var gen = fn.apply(this, arguments);
        return new Promise(function(resolve, reject) {
            function step(key, arg) {
                try {
                    var info = gen[key](arg);
                    var value = info.value;
                } catch (error) {
                    reject(error);
                    return;
                }
                if (info.done) {
                    resolve(value);
                } else {
                    return Promise.resolve(value).then(function(value) {
                        step("next", value);
                    }, function(err) {
                        step("throw", err);
                    });
                }
            }
            return step("next");
        });
    };
}

// import { activityBannerEntry } from '../../../services/home'
var HOME_PAGE_FEEDS_KEY = "HOME_PAGE_FEEDS";

var REFRESH_FEEDS_NOTES_LENGTH = _api2.default.$instance.globalData.isIOS ? 120 : 80;

var toastTimeout = null;

function replaceWebp2jpg() {
    var fileName = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
    var ext = fileName.substring(fileName.lastIndexOf("."), fileName.length);
    if (ext === ".webp") {
        fileName = fileName.slice(0, fileName.lastIndexOf(".")) + ".jpg";
    }
    return fileName;
}

function checkIndexInArr(arr, num) {
    return Object.prototype.toString.call(arr) === "[object Array]" && arr.length > num;
}

Page({
    $eagletPageMeta: {
        // 业务埋点页面
        pageInstance: "explore_feed",
        // 比如 note_id, user_id
        instanceId: function instanceId() {
            return "";
        },
        // 是否需要开启监听曝光打点
        needImpression: false,
        pageview: false
    },
    data: {
        navigationBarConfig: {
            titleText: "小红书",
            backgroundColor: "#FFFFFF",
            textStyle: "black"
        },
        showTopContainerSkeleton: true,
        showFeedsSkeleton: true,
        skeletonsCategoryList: [ , , , , ,  ],
        // eslint-disable-line
        categoryList: [],
        categoryActiveIndex: 0,
        isFetchingNoteList: false,
        skeletonsNoteList: [ , , , ,  ],
        // eslint-disable-line
        noteList: [],
        noteListPage: 1,
        isLastFailGetNoteList: false,
        pageSize: 20,
        searchDefaultValue: "",
        searchPlaceholder: "",
        isRefreshing: false,
        scrollTop: 0,
        isFirstLogin: false,
        isNeverFillInRecommendTagForm: false,
        canLike: true,
        showActivityEntry: false,
        containerHeight: 0,
        isShowAddMp: false,
        isShowBanner: false,
        isLoadMoreNoteList: false,
        isLoginStatus: null,
        scrollIntoViewId: "",
        banner: {},
        canLaunchApp: false,
        geo: "",
        showLoginModal: false,
        showLoginModalSource: ""
    },
    mixins: [ _tracker2.default ],
    handleCloseLoginModal: function handleCloseLoginModal() {
        this.setData({
            showLoginModal: false
        });
    },
    handleMaskTap: function handleMaskTap() {
        this.setData({
            isShowAddMp: false
        });
    },
    handleTapBanner: function handleTapBanner() {
        // trackNormalData({
        //   action: 'click_activity_from_homepage',
        // })
        // navigateTo('ActivityValentineIndex')
        if (!this.data.banner.link) {
            return;
        }
        (0, _track.trackNormalData)({
            action: "click_activity_banner"
        });
        if (this.data.banner.link.indexOf("/") === 0) {
            wx.navigateTo({
                url: this.data.banner.link
            });
        } else {
            (0, _path.navigateTo)("Webview", {
                link: encodeURIComponent(this.data.banner.link)
            });
        }
    },
    handleTapCategory: function handleTapCategory(e) {
        var _this = this;
        var _e$currentTarget$data = e.currentTarget.dataset, index = _e$currentTarget$data.index, item = _e$currentTarget$data.item;
        var backToTop = function backToTop() {
            _api2.default.pageScrollTo({
                scrollTop: 0,
                duration: 100
            });
        };
        (0, _track.trackClick)({
            label: "category",
            property: item.oid,
            context: {}
        });
        // 当前页回到顶部
                if (index === this.data.categoryActiveIndex && this.data.noteList.length > 0) {
            backToTop();
            return;
        }
        this.setData({
            isFetchingNoteList: false,
            isRefreshing: false,
            categoryActiveIndex: index,
            noteList: []
        });
        // this.scrollTop = 0
                if (item.name === "附近") {
            var renderNoteListByLocation = function renderNoteListByLocation() {
                var data = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
                // eslint-disable-line
                                var geoJSON = {
                    latitude: data.latitude,
                    longitude: data.longitude
                };
                _this.data.geo = _Base2.default.btoa(JSON.stringify(geoJSON));
                _this.renderNoteList({
                    clearList: true,
                    oid: item.oid,
                    geo: _this.data.geo
                });
            };
            _api2.default.getLocation().then(function(data) {
                renderNoteListByLocation(data);
            }, function() {
                _user2.default.openSettingModal(function(modalRes) {
                    (0, _track.trackNormalData)({
                        action: "click",
                        label: "confrim_auth_location"
                    });
                    if (modalRes.authSetting["scope.userLocation"]) {
                        setTimeout(function() {
                            _api2.default.getLocation().then(function(data) {
                                renderNoteListByLocation(data);
                            });
                            (0, _track.trackNormalData)({
                                action: "click",
                                label: "auth_location_success"
                            });
                        }, 0);
                    }
                }, function() {
                    (0, _track.trackNormalData)({
                        action: "click",
                        label: "cancel_auth_location"
                    });
                }, {
                    title: "还不知道你在哪个城市呢",
                    content: "打开“位置信息”查看更多",
                    confirmText: "去授权",
                    cancelText: "取消"
                });
            });
        } else {
            this.data.geo = "";
            this.renderNoteList({
                oid: item.oid,
                clearList: true
            });
        }
    },
    handleSearch: function handleSearch() {
        var searchDefaultValue = this.data.searchDefaultValue;
        if (_abTest2.default.getABTestFlagValue("wx_mp_login_modal") === 1 && !_user2.default.getUserId()) {
            this.setData({
                showLoginModal: true,
                showLoginModalSource: "search-input"
            });
            return;
        }
        _user2.default.ensureLogin().then(function() {
            (0, _track.trackClick)({
                label: "search_input",
                context: {}
            });
            (0, _path.navigateTo)("SearchIndex", {
                defaultValue: searchDefaultValue
            });
        });
    },
    handleScrollBottom: function handleScrollBottom() {
        this.fetchMoreNoteList();
    },
    handleScrollPullDown: function handleScrollPullDown() {
        var _this2 = this;
        var postData = {};
        var currentCategory = this.getCurrentCategory();
        (0, _track.trackNormalData)({
            action: "refresh",
            property: currentCategory.oid
        });
        postData = {
            oid: currentCategory.oid,
            clearList: true
        };
        this.setData({
            isRefreshing: true
        });
        this.renderNoteList(postData).then(function() {
            var res = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
            if (res && res.length > 0) {
                _this2.setData({
                    isRefreshing: false
                });
            }
            _api2.default.stopPullDownRefresh();
        });
    },
    getCategoryList: function getCategoryList() {
        var _this3 = this;
        return _asyncToGenerator(/* */ _regenerator2.default.mark(function _callee() {
            var CATEGORY_KEY, isLogin, cacheCategoryList, isMale, postData, result;
            return _regenerator2.default.wrap(function _callee$(_context) {
                while (1) {
                    switch (_context.prev = _context.next) {
                      case 0:
                        CATEGORY_KEY = "CATEGORY";
                        isLogin = _user2.default.checkLogin();
                        cacheCategoryList = (0, _storage.getStorageSync)(CATEGORY_KEY) || [];
                        isMale = _user2.default.isMale();
                        // 兴趣采集页面后重新拉取categories
                                                postData = {
                            isMale: isMale
                        };
                        result = [];
                        _context.prev = 6;
                        _context.next = 9;
                        return (0, _homepage.getHomeFeedsCategories)(postData);

                      case 9:
                        result = _context.sent;
                        _context.next = 16;
                        break;

                      case 12:
                        _context.prev = 12;
                        _context.t0 = _context["catch"](6);
                        console.warn("get category list err", _context.t0);
                        // eslint-disable-line
                        // 降级方案
                                                if (checkIndexInArr(cacheCategoryList, 0)) {
                            result = cacheCategoryList;
                        }

                      case 16:
                        if (result && result.length > 0) {
                            // 登录状态下下次直接走缓存
                            if (isLogin) {
                                (0, _storage.setStorage)({
                                    key: CATEGORY_KEY,
                                    data: result
                                });
                            }
                        } else {
                            // 默认分类
                            result = (0, _homepage.getDefaultCategories)();
                        }
                        return _context.abrupt("return", result);

                      case 18:
                      case "end":
                        return _context.stop();
                    }
                }
            }, _callee, _this3, [ [ 6, 12 ] ]);
        }))();
    },
    // 格式化笔记列表
    formatNoteList: function formatNoteList() {
        var noteList = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
        var result = noteList.map(function(item) {
            var firstImage = item.cover || {};
            var user = item.user || {};
            var imageUrl = replaceWebp2jpg(firstImage.url);
            item.image = {
                originalUrl: firstImage.url,
                url: imageUrl,
                width: firstImage.width,
                height: firstImage.height
            };
            item.user = {
                image: user.image,
                nickname: user.nickname,
                userid: user.id,
                followed: user.followed,
                redOfficialVerified: user.redOfficialVerified
            };
            return item;
        });
        return result;
    },
    setNoteListCache: function setNoteListCache() {
        var noteList = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
        try {
            if (this.data.categoryActiveIndex !== 0) {
                return;
            }
            var copyNoteList = JSON.parse(JSON.stringify(noteList));
            (0, _storage.setStorage)({
                key: HOME_PAGE_FEEDS_KEY,
                data: copyNoteList
            }).then(function() {
                console.info("set Storage note list success", copyNoteList.length);
                // eslint-disable-line
                        });
        } catch (err) {
            console.warn("set Storage note list fail", err);
            // eslint-disable-line
                }
    },
    getNoteList: function getNoteList() {
        var _this4 = this;
        var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
        return _asyncToGenerator(/* */ _regenerator2.default.mark(function _callee2() {
            var _data, noteList, noteListPage, pageSize, geo, oid, clearList, isLogin, defaultOid, page, cursorScore, postData, result, newPageResult, resultInfo, scrollIntoViewId, noNewNoteList, checkLimitLength;
            return _regenerator2.default.wrap(function _callee2$(_context2) {
                while (1) {
                    switch (_context2.prev = _context2.next) {
                      case 0:
                        _data = _this4.data, noteList = _data.noteList, noteListPage = _data.noteListPage, 
                        pageSize = _data.pageSize, geo = _data.geo;
                        oid = options.oid, clearList = options.clearList;
                        isLogin = _user2.default.checkLogin();
                        defaultOid = isLogin ? "homefeed_recommend" : "recommend";
                        page = noteListPage;
                        cursorScore = noteList.length > 0 ? noteList[noteList.length - 1].cursorScore || noteList[noteList.length - 1].id : "";
                        if (clearList) {
                            page = 1;
                            cursorScore = "";
                        }
                        oid = oid || defaultOid;
                        postData = {
                            category: oid,
                            cursorScore: cursorScore,
                            geo: geo,
                            page: page,
                            pageSize: pageSize
                        };
                        if (_abTest2.default.getABTestFlagValue("wechat_note_video_use_gif") === 1) {
                            postData.needGifCover = true;
                        }
                        result = noteList;
                        newPageResult = [];
                        resultInfo = {};
                        scrollIntoViewId = "";
                        // 部分情况下cursorScore过期 取回homefeed的data为空,将最后一个笔记中cursorScore置为空
                                                if (_this4.data.isLastFailGetNoteList && postData.cursorScore) {
                            postData.cursorScore = "";
                        }
                        _this4.setData({
                            isLastFailGetNoteList: false
                        });
                        _context2.prev = 16;
                        _context2.next = 19;
                        return (0, _homepage.getHomeFeeds)(postData);

                      case 19:
                        newPageResult = _context2.sent;
                        newPageResult = _this4.formatNoteList(newPageResult || []);
                        // 设置缓存防止下次接口挂掉时直接显示
                                                _context2.next = 26;
                        break;

                      case 23:
                        _context2.prev = 23;
                        _context2.t0 = _context2["catch"](16);
                        _this4.setData({
                            isLastFailGetNoteList: true
                        });

                        // apiUtil.showToast({
                        //   title: '请求超时',
                        //   icon: 'none'
                        // })
                                              case 26:
                        noNewNoteList = !newPageResult || newPageResult.length === 0;
                        // 没有结果
                                                if (!noNewNoteList) {
                            _context2.next = 31;
                            break;
                        }
                        resultInfo.noNewResult = true;
                        _this4.setData({
                            isLastFailGetNoteList: true
                        });
                        return _context2.abrupt("return", {
                            result: result,
                            resultInfo: resultInfo
                        });

                      case 31:
                        checkLimitLength = function checkLimitLength() {
                            var arr = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
                            if (arr.length < REFRESH_FEEDS_NOTES_LENGTH) {
                                return arr;
                            }
                            var sliceStart = arr.length - 15;
                            var pageSize = _this4.data.pageSize;
                            arr = arr.slice(sliceStart);
                            scrollIntoViewId = "page-scroll-start";
                            console.warn("性能长度限制，只保留", arr.length);
                            // eslint-disable-line
                                                        toastTimeout = setTimeout(function() {
                                // eslint-disable-line
                                _api2.default.showToast({
                                    icon: "none",
                                    title: "为你推荐" + pageSize + "条新笔记"
                                });
                            }, 2e3);
                            return arr;
                        };
                        // 重置的情况
                                                if (clearList) {
                            result = newPageResult;
                        } else {
                            result = checkLimitLength(result).concat(newPageResult);
                        }
                        return _context2.abrupt("return", {
                            result: result,
                            resultInfo: resultInfo,
                            scrollIntoViewId: scrollIntoViewId
                        });

                      case 34:
                      case "end":
                        return _context2.stop();
                    }
                }
            }, _callee2, _this4, [ [ 16, 23 ] ]);
        }))();
    },
    renderNoteList: function renderNoteList() {
        var _this5 = this;
        var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
        return new Promise(function(resolve, reject) {
            if (_this5.data.isFetchingNoteList) {
                reject();
                return;
            }
            _this5.setData({
                isFetchingNoteList: true
            });
            _this5.getNoteList(options).then(function() {
                var data = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
                var result = data.result, resultInfo = data.resultInfo, scrollIntoViewId = data.scrollIntoViewId;
                var hasOldNoteList = checkIndexInArr(_this5.data.notelist, 0);
                var hasNewNoteList = checkIndexInArr(result, 0);
                _this5.setData({
                    showFeedsSkeleton: false,
                    isFetchingNoteList: false
                });
                // 如果有已存在列表了，新的请求没有拿到数据就停止
                                if (resultInfo.noResult && hasOldNoteList) {
                    reject();
                    return;
                }
                // 降级方案，没有任何结果就返回缓存的数据
                                if (_this5.data.categoryActiveIndex === 0 && !hasNewNoteList && !hasOldNoteList) {
                    console.warn("首页推荐降级方案", result);
                    // eslint-disable-line
                                        result = (0, _storage.getStorageSync)(HOME_PAGE_FEEDS_KEY) || [];
                }
                _this5.setData({
                    noteList: result,
                    scrollIntoViewId: scrollIntoViewId
                });
                resolve(result, resultInfo);
            });
        });
    },
    // 渲染分类
    renderCategoryList: function renderCategoryList() {
        var _this6 = this;
        return _asyncToGenerator(/* */ _regenerator2.default.mark(function _callee3() {
            var categoryList;
            return _regenerator2.default.wrap(function _callee3$(_context3) {
                while (1) {
                    switch (_context3.prev = _context3.next) {
                      case 0:
                        _context3.next = 2;
                        return _this6.getCategoryList();

                      case 2:
                        categoryList = _context3.sent;
                        _this6.setData({
                            categoryList: categoryList,
                            showTopContainerSkeleton: false
                        });

                      case 4:
                      case "end":
                        return _context3.stop();
                    }
                }
            }, _callee3, _this6);
        }))();
    },
    initSearchPlaceHolder: function initSearchPlaceHolder() {
        var _this7 = this;
        return _asyncToGenerator(/* */ _regenerator2.default.mark(function _callee4() {
            var result, placeholders, item;
            return _regenerator2.default.wrap(function _callee4$(_context4) {
                while (1) {
                    switch (_context4.prev = _context4.next) {
                      case 0:
                        result = {
                            placeholder: "搜索小红书的笔记",
                            defaultValue: ""
                        };
                        if (_user2.default.checkLogin()) {
                            _context4.next = 3;
                            break;
                        }
                        return _context4.abrupt("return", result);

                      case 3:
                        _context4.prev = 3;
                        _context4.next = 6;
                        return (0, _noteSearch.getHotSearch)();

                      case 6:
                        placeholders = _context4.sent;
                        // 防止没有长度报错
                                                if (checkIndexInArr(placeholders, 0)) {
                            item = placeholders[0] || {};
                            result.placeholder = "大家都在搜“" + item.name + "”";
                            result.defaultValue = item.name;
                        }
                        _context4.next = 12;
                        break;

                      case 10:
                        _context4.prev = 10;
                        _context4.t0 = _context4["catch"](3);

                      case 12:
                        return _context4.abrupt("return", result);

                      case 13:
                      case "end":
                        return _context4.stop();
                    }
                }
            }, _callee4, _this7, [ [ 3, 10 ] ]);
        }))();
    },
    initBasic: function initBasic() {
        this.setData({
            noteListPage: 1,
            categoryActiveIndex: 0
        });
        this.renderCategoryList();
        this.renderNoteList({
            clearList: true,
            canCache: true
        });
    },
    initSecondary: function initSecondary() {
        var _this8 = this;
        var initSearchPlaceHolder = this.initSearchPlaceHolder;
        var renderSearch = function renderSearch() {
            // eslint-disable-line
            return initSearchPlaceHolder().then(function() {
                var result = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
                _this8.setData({
                    searchPlaceholder: result.placeholder,
                    searchDefaultValue: result.defaultValue
                });
            });
        };
        renderSearch();
    },
    getCurrentCategory: function getCurrentCategory() {
        var category = {
            name: "推荐",
            oid: "homefeed_recommend"
        };
        var _data2 = this.data, categoryList = _data2.categoryList, categoryActiveIndex = _data2.categoryActiveIndex;
        if (checkIndexInArr(categoryList, categoryActiveIndex)) {
            category = categoryList[categoryActiveIndex];
        }
        return category;
    },
    fetchMoreNoteList: function fetchMoreNoteList() {
        var _this9 = this;
        var _data3 = this.data, categoryList = _data3.categoryList, noteList = _data3.noteList;
        if (this.data.isLoadMoreNoteList) {
            console.warn("拦截more note list");
            // eslint-disable-line
                        return;
        }
        if (!checkIndexInArr(categoryList, 0) || !checkIndexInArr(noteList, 0)) {
            return;
        }
        this.setData({
            isLoadMoreNoteList: true
        });
        var currentCategory = this.getCurrentCategory();
        var oid = currentCategory.oid;
        var postData = {
            oid: oid
        };
        (0, _track.trackNormalData)({
            action: "more-feeds",
            property: oid
        });
        this.setData({
            noteListPage: this.data.noteListPage + 1
        });
        this.renderNoteList(postData).then(function() {
            _this9.setData({
                isLoadMoreNoteList: false
            });
        }).catch(function() {
            _this9.setData({
                isLoadMoreNoteList: false
            });
        });
    },
    initEventBus: function initEventBus() {
        var _this10 = this;
        _eventBus2.default.on("likeTaped", function(id) {
            var changeNoteItem = null;
            var changeNoteItemIndex = -1;
            if (checkIndexInArr(_this10.data.noteList, 0)) {
                _this10.data.noteList.some(function(item, index) {
                    if (id === item.id) {
                        changeNoteItem = item;
                        changeNoteItemIndex = index;
                        return true;
                    }
                });
            }
            if (!changeNoteItem) {
                return;
            }
            var isLiked = changeNoteItem.isLiked;
            var method = _note.likeNote;
            var action = "like-increase";
            if (isLiked) {
                method = _note.dislikeNote;
                action = "like-decrease";
            }
            method({
                noteId: id
            }).then(function(res) {
                // eslint-disable-line
                _tracker3.wxTrack.call(_this10, {
                    action: action,
                    property: id
                });
                changeNoteItem.likes = isLiked ? --changeNoteItem.likes : ++changeNoteItem.likes;
                changeNoteItem.isLiked = !isLiked;
                var newNoteList = _this10.data.noteList;
                newNoteList[changeNoteItemIndex] = changeNoteItem;
                _this10.setData({
                    noteList: newNoteList
                });
            });
        });
    },
    setBanner: function setBanner() {
        var homefeed = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
        var from = homefeed.from, to = homefeed.to, link = homefeed.link, image = homefeed.image;
        if (!link || !from || !to || !image) {
            return;
        }
        var current = new Date();
        var showBanner = _abTest2.default.getABTestFlagValue("wxmp_jay_banner");
        if (showBanner === 1 && current > new Date(from) && current < new Date(to)) {
            (0, _track.trackNormalData)({
                action: "impression_activity_banner"
            });
            this.setData({
                isShowBanner: true,
                banner: {
                    image: image,
                    link: link
                }
            });
        }
    },
    redirectPage: function redirectPage() {
        var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
        if (options.redirect_path && _verify2.default.canJumpToVerifyPage()) {
            var redirect_path = options.redirect_path, otherParams = _objectWithoutProperties(options, [ "redirect_path" ]);
            // eslint-disable-line
                        var moreParams = [];
            Object.keys(otherParams).forEach(function(pageUrlKey) {
                moreParams.push(pageUrlKey + "=" + otherParams[pageUrlKey]);
            });
            var redirectPath = decodeURIComponent(redirect_path);
            redirectPath = redirectPath.indexOf("?") > -1 ? redirectPath + "&" + moreParams.join("&") : redirectPath + "?" + moreParams.join("&");
            (0, _track.trackNormalData)({
                action: "goto_page_success",
                label: "share_note",
                property: redirectPath
            });
            wx.navigateTo({
                url: redirectPath
            });
        }
    },
    onLoad: function onLoad() {
        var _this11 = this;
        var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
        var promise = _api2.default.$instance.globalData.promise;
        var newHomeFeed = {};
        this.setData({
            canLaunchApp: _api2.default.$instance.globalData.canLaunchApp
        });
        if (promise) {
            promise.then(_asyncToGenerator(/* */ _regenerator2.default.mark(function _callee5() {
                var _ref2, homefeed;
                return _regenerator2.default.wrap(function _callee5$(_context5) {
                    while (1) {
                        switch (_context5.prev = _context5.next) {
                          case 0:
                            _context5.prev = 0;
                            _context5.next = 3;
                            return (0, _homepage.getActivityBannerInfo)().catch(function() {
                                return {
                                    homefeed: {}
                                };
                            });

                          case 3:
                            _ref2 = _context5.sent;
                            homefeed = _ref2.homefeed;
                            newHomeFeed = homefeed;
                            _context5.next = 11;
                            break;

                          case 8:
                            _context5.prev = 8;
                            _context5.t0 = _context5["catch"](0);
                            console.error(_context5.t0);

                            // eslint-disable-line
                                                      case 11:
                            // app 内分享经过首页跳转
                            setTimeout(function() {
                                _this11.redirectPage(options);
                            }, 500);
                            _this11.setBanner(newHomeFeed);
                            _this11.setData({
                                isLoginStatus: _user2.default.checkLogin()
                            });
                            _this11.initSecondary();
                            _this11.initBasic();
                            // 新打点
                                                        wx.$eaglet.page.setConfig({
                                $eagletPageMeta: _this11.$eagletPageMeta
                            });
                            wx.$eaglet.page.initPage(options);
                            wx.$eaglet.page.trackPageView(_mp.tracker[601]());

                          case 19:
                          case "end":
                            return _context5.stop();
                        }
                    }
                }, _callee5, _this11, [ [ 0, 8 ] ]);
            })));
            (0, _vuefy.computed)(this, {
                launchAppParameter: function launchAppParameter() {
                    var _ref3 = _user2.default.getUserInfo() || {}, openid = _ref3.openid;
                    return "xhsdiscover://home?sourceId=miniprogram&openid=" + openid + "&position=wxmp-home-default&mpid=mewtwo";
                }
            });
        }
    },
    onShow: function onShow() {
        this.initEventBus();
        this.setData({
            canLaunchApp: _api2.default.$instance.globalData.canLaunchApp
        });
        // 登录用户需要刷新页面
                if (this.data.isLoginStatus === null || this.data.isLoginStatus) {
            return;
        }
        var newIsLoginStatus = _user2.default.checkLogin();
        if (this.data.isLoginStatus === false && newIsLoginStatus) {
            console.info("新用户刷新内容");
            // eslint-disable-line
                        this.setData({
                isLoginStatus: newIsLoginStatus
            });
            this.initBasic();
        }
    },
    onUnload: function onUnload() {
        _eventBus2.default.off("likeTaped");
        if (toastTimeout) {
            clearTimeout(toastTimeout);
        }
    },
    onHide: function onHide() {
        _eventBus2.default.off("likeTaped");
        if (toastTimeout) {
            clearTimeout(toastTimeout);
        }
    },
    onShareAppMessage: function onShareAppMessage() {
        (0, _track.trackNormalData)({
            action: "share"
        });
        return {
            title: "小红书·标记我的生活",
            path: "/pages/main/home/index"
        };
    }
});