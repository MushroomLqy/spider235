var _regenerator = require("./../../../karin_npm/babel-runtime/regenerator/index.js");

var _regenerator2 = _interopRequireDefault(_regenerator);

var _extends = Object.assign || function(target) {
    for (var i = 1; i < arguments.length; i++) {
        var source = arguments[i];
        for (var key in source) {
            if (Object.prototype.hasOwnProperty.call(source, key)) {
                target[key] = source[key];
            }
        }
    }
    return target;
};

var _tracker = require("../../../mixins/tracker");

var _tracker2 = _interopRequireDefault(_tracker);

var _vuefy = require("../../../libs/vuefy.js");

var _appuser = require("../../../services/appuser");

var _eventBus = require("../../../libs/event-bus");

var _eventBus2 = _interopRequireDefault(_eventBus);

var _mp = require("../../../libs/@xhs/protobuf-mp-chakra-tracker/mp.js");

var _note = require("../../../services/note");

var _activity = require("../../../services/activity");

var _system = require("../../../services/system");

var _page = require("../../../utils/page");

var _image = require("../../../utils/image");

var _track = require("../../../utils/track");

var _abTest = require("../../../utils/ab-test");

var _abTest2 = _interopRequireDefault(_abTest);

var _user = require("../../../utils/user");

var _user2 = _interopRequireDefault(_user);

var _api = require("../../../utils/api");

var _api2 = _interopRequireDefault(_api);

var _path = require("../../../utils/path");

var _enum = require("../../../utils/enum");

var _datetime = require("../../../utils/datetime");

var _customsMessage = require("./utils/customsMessage");

var _tag = require("./utils/tag");

var _deeplink = require("./utils/deeplink");

var _shareInfo = require("./utils/shareInfo");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}

function _asyncToGenerator(fn) {
    return function() {
        var gen = fn.apply(this, arguments);
        return new Promise(function(resolve, reject) {
            function step(key, arg) {
                try {
                    var info = gen[key](arg);
                    var value = info.value;
                } catch (error) {
                    reject(error);
                    return;
                }
                if (info.done) {
                    resolve(value);
                } else {
                    return Promise.resolve(value).then(function(value) {
                        step("next", value);
                    }, function(err) {
                        step("throw", err);
                    });
                }
            }
            return step("next");
        });
    };
}

var TYPE_VIDEO_FEED = "video-feed";

var CurrentSystemInfo = _api2.default.getSystemInfoSync();

// eslint-disable-next-line
Page({
    $eagletPageMeta: {
        // 业务埋点页面
        pageInstance: "note_detail_r10",
        // 比如 note_id, user_id
        instanceId: function instanceId(query) {
            return query.id;
        },
        // 是否需要开启监听曝光打点
        needImpression: true,
        impressionSelector: ".related-notes>>>.eaglet-impression",
        pageview: true
    },
    data: {
        noteId: "",
        noteType: "normal",
        launchAppParameter: "",
        navigationBarConfig: {},
        noteList: [],
        videoFeedList: [],
        videoFeedIndex: 0,
        // 视频笔记 feed 当前下标
        fetchedRelatedNotes: false,
        isShowSkeleton: true,
        note: {},
        navigationBarTrueHeight: (0, _page.getTopSectionHeight)(),
        canLaunchApp: false,
        screenTopNotePlaceholderHeight: 600,
        opacity: 1,
        showModal: false,
        showLaunchAppModal: false,
        refluxType: 0,
        expandType: 2,
        noteFeedCanLaunchApp: 0,
        isIphoneX: _api2.default.$instance.globalData.isIPhoneX,
        isShowShareInfoBar: false,
        brandLotteryInfoData: {},
        relatedNotesPageInfo: {
            page: 1,
            pageSize: 8
        },
        supportComment: false,
        // 是否可以评论
        canShowActivityBanner: true,
        showLoginModal: false,
        // 是否可以展示登录弹框
        showLoginModalSource: "",
        canShowVideoGif: false,
        defaultLaunchAppText: "",
        noteTags: [],
        launchAppModalDesc: "",
        launchAppModalSource: "",
        shareMomentType: 0,
        shareInfo: {},
        addMyMp: {
            hasClose: false,
            isShowAddMp: false
        },
        pageNoteType: "",
        videoSingleFeed: 0
    },
    mixins: [ _tracker2.default ],
    // life cycle
    onLoad: function onLoad() {
        var _this = this;
        var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
        return _asyncToGenerator(/* */ _regenerator2.default.mark(function _callee() {
            var _ref, id, type, appuid, scene, pageNoteType, videoFeedList, launchAppParameter, commonObj, note, initPageTrackData, isUseNormalNote;
            return _regenerator2.default.wrap(function _callee$(_context) {
                while (1) {
                    switch (_context.prev = _context.next) {
                      case 0:
                        _ref = options || {}, id = _ref.id, type = _ref.type, appuid = _ref.appuid, scene = _ref.scene;
                        pageNoteType = "normal";
                        videoFeedList = [];
                        // 判断属否来自二维码
                                                if (scene && !id && scene.length === 24) {
                            id = scene;
                        }
                        _context.next = 6;
                        return _this.initABTest({
                            id: id,
                            appuid: appuid,
                            type: type
                        });

                      case 6:
                        launchAppParameter = (0, _deeplink.getNoteDeepLink)(id, type);
                        // 设置从 query 获取的基础信息
                                                _this.setData({
                            launchAppParameter: launchAppParameter
                        });
                        commonObj = {
                            noteId: id,
                            noteType: type || "",
                            startLoadTime: Date.now(),
                            canLaunchApp: _api2.default.$instance.globalData.canLaunchApp,
                            shareUserId: appuid
                        };
                        _this.setData(_extends({}, commonObj));
                        // 渠道归因打点
                                                (0, _system.postRecord)({
                            noteId: id,
                            pasteboard: ""
                        });
                        // 老打点
                                                (0, _track.trackPageview)();
                        _this.initSafety();
                        _this.initAddMyMp();
                        _context.next = 16;
                        return _this.fetchNote(id);

                      case 16:
                        // 判断展示普通笔记样式，还是 video feed
                        note = _this.data.note;
                        // 新打点
                                                initPageTrackData = function initPageTrackData() {
                            // 新打点
                            wx.$eaglet.page.setConfig({
                                $eagletPageMeta: _this.$eagletPageMeta
                            });
                            wx.$eaglet.page.startImpression();
                            wx.$eaglet.page.initPage(options);
                        };
                        // 低版本基础库使用 老版本笔记
                                                isUseNormalNote = CurrentSystemInfo && CurrentSystemInfo.SDKVersion === "2.7.7";
                        if (!(_this.data.videoSingleFeed === 1 && note && note.type === "video" && !isUseNormalNote)) {
                            _context.next = 31;
                            break;
                        }
                        pageNoteType = TYPE_VIDEO_FEED;
                        _context.next = 23;
                        return _this.fetchRelatedNotes(pageNoteType);

                      case 23:
                        videoFeedList = _this.data.videoFeedList;
                        if (_this.data.note) {
                            videoFeedList.unshift(_this.data.note);
                            _this.initShareInfo(_this.data.note);
                        }
                        videoFeedList = _this.formatVideoFeedList(videoFeedList);
                        _this.initVideoNote();
                        initPageTrackData();
                        wx.$eaglet.page.trackPageView(_mp.tracker[2104]({
                            shareUserId: appuid
                        }));
                        _context.next = 39;
                        break;

                      case 31:
                        _this.fetchRelatedNotes();
                        _this.initNormalNote();
                        initPageTrackData();
                        wx.$eaglet.page.trackPageView(_mp.tracker[2565]({
                            shareUserId: appuid
                        }));
                        _this.fetchNoteTags(id);
                        _this.fetchActivityBanner();
                        _this.initImageStickers(id);
                        _this.fetchBrandLottery(id);

                      case 39:
                        _this.setData({
                            pageNoteType: pageNoteType,
                            videoFeedList: videoFeedList
                        });
                        (0, _vuefy.computed)(_this, {
                            illegalInfo: function illegalInfo() {
                                var note = this.data.note;
                                if (note && note.illegalInfo) {
                                    return note.illegalInfo;
                                } else if (note.noNoteWhenApiSuccess) {
                                    return {
                                        desc: "该笔记暂时无法查看"
                                    };
                                } else if (note.noNoteWhenApiError) {
                                    return {
                                        desc: note.errorMsg
                                    };
                                }
                                return "";
                            }
                        });

                      case 41:
                      case "end":
                        return _context.stop();
                    }
                }
            }, _callee, _this);
        }))();
    },
    onPageScroll: function onPageScroll() {
        wx.$eaglet.page.debounceImpression();
    },
    onShow: function onShow() {
        wx.$eaglet.page.resetPage();
        wx.$eaglet.page.startImpression();
        this.initEventBus();
    },
    onHide: function onHide() {
        this.removeEventBus();
        wx.$eaglet.flush();
    },
    onUnload: function onUnload() {
        this.removeEventBus();
        wx.$eaglet.page.stopImpression();
        wx.$eaglet.page.destroyPage();
    },
    onReachBottom: function onReachBottom() {
        this.fetchRelatedNotes();
    },
    onShareAppMessage: function onShareAppMessage() {
        var _data = this.data, shareInfo = _data.shareInfo, pageNoteType = _data.pageNoteType, videoFeedIndex = _data.videoFeedIndex, noteId = _data.noteId;
        var imageUrl = void 0;
        var title = void 0;
        var id = shareInfo.noteId || noteId;
        var type = shareInfo.noteType;
        var _userUtil$getUserInfo = _user2.default.getUserInfo(), appUserId = _userUtil$getUserInfo.appUserId, openid = _userUtil$getUserInfo.openid;
        var isNoteFeed = pageNoteType === TYPE_VIDEO_FEED;
        var args = {
            id: id,
            type: type,
            appuid: appUserId,
            mpoid: openid,
            shareImageType: "old"
        };
        if (shareInfo.shareTitle) {
            title = shareInfo.shareTitle;
        }
        // 分享图多重兜底
                if (shareInfo.shareImageUrl) {
            imageUrl = shareInfo.shareImageUrl;
            args.shareImageType = "new";
        } else if (shareInfo.image) {
            imageUrl = shareInfo.image;
        } else if (shareInfo.cover) {
            imageUrl = shareInfo.cover.url;
        }
        var backupTitle = "小红书·标记我的生活";
        // 分享文案兜底
                if (shareInfo.user) {
            backupTitle = "@" + shareInfo.user.nickname + " 发了一篇笔记，快点来看吧！";
        }
        (0, _track.trackNormalData)({
            action: "share",
            property: id
        });
        if (isNoteFeed) {
            var trackId = videoFeedIndex === 0 ? 2121 : 2122;
            wx.$eaglet.push(_mp.tracker[trackId]({
                objectPosition: videoFeedIndex + 1,
                noteId: id,
                noteType: "video_note",
                authorId: appUserId || "Null"
            }));
        } else {
            wx.$eaglet.push(_mp.tracker[2713]({
                objectPosition: 1,
                noteId: id,
                noteType: type === "video" ? "video_note" : "short_note",
                authorId: appUserId || "Null"
            }));
        }
        return {
            title: title || backupTitle,
            desc: "小红书·标记我的生活",
            path: (0, _path.makeSharePath)("NoteDetail", args),
            imageUrl: imageUrl
        };
    },
    // self-defining function
    fetchNote: function fetchNote(id) {
        var _this2 = this;
        return _asyncToGenerator(/* */ _regenerator2.default.mark(function _callee2() {
            var noteData, noNoteWhenApiSuccess, noNoteWhenApiError, errorMsg, launchAppParameter, customMessageCardInfo, note, image, currentNoteReplyInfo, noteWebviewUrl;
            return _regenerator2.default.wrap(function _callee2$(_context2) {
                while (1) {
                    switch (_context2.prev = _context2.next) {
                      case 0:
                        noteData = void 0;
                        noNoteWhenApiSuccess = false;
                        noNoteWhenApiError = false;
                        errorMsg = "";
                        launchAppParameter = _this2.data.launchAppParameter;
                        customMessageCardInfo = void 0;
                        _context2.prev = 6;
                        _context2.next = 9;
                        return (0, _note.getSingleNote)({
                            id: id
                        });

                      case 9:
                        _context2.t0 = _context2.sent;
                        if (_context2.t0) {
                            _context2.next = 12;
                            break;
                        }
                        _context2.t0 = [];

                      case 12:
                        noteData = _context2.t0;
                        if (!noteData.id) {
                            noNoteWhenApiSuccess = true;
                        }
                        _context2.next = 22;
                        break;

                      case 16:
                        _context2.prev = 16;
                        _context2.t1 = _context2["catch"](6);
                        noNoteWhenApiError = true;
                        errorMsg = _context2.t1.detail && _context2.t1.detail.msg ? _context2.t1.detail.msg : "服务器开小差了";
                        launchAppParameter = (0, _deeplink.getNoteDeepLink)("", "normal", {}, "xhsdiscover://home");
                        (0, _track.trackApm)({
                            action: "get-single-note-err"
                        });

                      case 22:
                        if (!noteData) {
                            (0, _track.trackApm)({
                                action: "get-notefeed-null"
                            });
                        }
                        note = {
                            noNoteWhenApiSuccess: noNoteWhenApiSuccess,
                            noNoteWhenApiError: noNoteWhenApiError,
                            errorMsg: errorMsg
                        };
                        if (noteData && noteData.id) {
                            note = noteData;
                        }
                        image = {};
                        currentNoteReplyInfo = {};
                        noteWebviewUrl = (0, _customsMessage.getAbsoluteWebviewUrl)("https://www.xiaohongshu.com/discovery/item/" + note.id);
                        if (note && note.cover) {
                            note.cover.url = note.cover.url.replace("1080", "800");
                            image = note.cover;
                            customMessageCardInfo = {
                                title: note.title,
                                desc: note.desc.substr(0, 30),
                                img: image.url
                            };
                            launchAppParameter = (0, _deeplink.getNoteDeepLink)(note.id, note.type);
                            currentNoteReplyInfo = {
                                sessionFrom: JSON.stringify({
                                    url: noteWebviewUrl,
                                    thumbUrl: image.url,
                                    description: note.title,
                                    title: "点我，查看精彩内容！",
                                    deeplink: launchAppParameter
                                })
                            };
                        }
                        note.swiperHeight = CurrentSystemInfo.windowWidth * image.height / image.width || 0;
                        note.isExpand = false;
                        note.isFirst = false;
                        _this2.setData({
                            note: note,
                            launchAppParameter: launchAppParameter,
                            customMessageCardInfo: customMessageCardInfo,
                            currentNoteReplyInfo: currentNoteReplyInfo,
                            opacity: 0,
                            isShowSkeleton: false,
                            canShowLoginModal: true
                        });

                      case 33:
                      case "end":
                        return _context2.stop();
                    }
                }
            }, _callee2, _this2, [ [ 6, 16 ] ]);
        }))();
    },
    fetchNoteTags: function fetchNoteTags(id) {
        var _this3 = this;
        (0, _note.getNoteTags)({
            id: id
        }).then(function(data) {
            if (!data) {
                return;
            }
            var note = _this3.data.note;
            _this3.setData({
                noteTags: data
            });
            _this3.initShareInfo(note, data);
        });
    },
    fetchBrandLottery: function fetchBrandLottery(id) {
        var enableBrandLottery = false;
        var self = this;
        var _data2 = this.data, _data2$note = _data2.note, note = _data2$note === undefined ? {} : _data2$note, launchAppParameter = _data2.launchAppParameter;
        var currentNote = {};
        var image = void 0;
        if (note) {
            currentNote = note;
            if (currentNote.cover) {
                image = currentNote.cover;
                enableBrandLottery = currentNote.enableBrandLottery;
            }
        }
        if (enableBrandLottery) {
            (0, _note.getBrandLotteryInfo)({
                noteId: id
            }).then(function() {
                var data = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
                var hasJoin = data.hasJoin;
                var actionBtn = hasJoin ? "已报名" : "去报名";
                self.setData({
                    brandLotteryInfoData: _extends({}, data, {
                        show: true,
                        actionBtn: actionBtn,
                        customMessageReplyInfo: {
                            sessionFrom: JSON.stringify({
                                form: "brand-lottery",
                                thumbUrl: image.url,
                                description: currentNote.title,
                                title: "点我，报名抽奖活动！",
                                deeplink: launchAppParameter
                            })
                        }
                    })
                });
            });
        }
    },
    fetchActivityBanner: function fetchActivityBanner() {
        var _this4 = this;
        var _data3 = this.data, noteId = _data3.noteId, canShowActivityBanner = _data3.canShowActivityBanner;
        if (!canShowActivityBanner) {
            return;
        }
        (0, _activity.getActivityBanner)({
            noteId: noteId,
            platform: "weixin"
        }).then(function(activityBannerInfo) {
            _this4.setData({
                activityBannerInfo: activityBannerInfo
            });
        });
    },
    fetchRelatedNotes: function fetchRelatedNotes(pageNoteType) {
        var _this5 = this;
        return _asyncToGenerator(/* */ _regenerator2.default.mark(function _callee3() {
            var _data4, _data4$note, note, relatedNotesPageInfo, noteId, canShowVideoGif, page, pageSize, id, noteType, newPage, isNoteFeed, currentNote, relatedNotes, userInfo, openid, method, newNoteList;
            return _regenerator2.default.wrap(function _callee3$(_context3) {
                while (1) {
                    switch (_context3.prev = _context3.next) {
                      case 0:
                        _data4 = _this5.data, _data4$note = _data4.note, note = _data4$note === undefined ? {} : _data4$note, 
                        relatedNotesPageInfo = _data4.relatedNotesPageInfo, noteId = _data4.noteId, canShowVideoGif = _data4.canShowVideoGif;
                        page = relatedNotesPageInfo.page, pageSize = relatedNotesPageInfo.pageSize;
                        id = noteId;
                        noteType = 1;
                        newPage = page + 1;
                        isNoteFeed = pageNoteType === TYPE_VIDEO_FEED;
                        if (note) {
                            currentNote = note;
                            if (currentNote.type === "video") {
                                noteType = 2;
                            }
                        }
                        relatedNotes = [];
                        userInfo = _user2.default.getUserInfo();
                        openid = userInfo.openid;
                        method = isNoteFeed ? _note.getRelatedNoteFeed : _note.getRelatedNotes;
                        _context3.prev = 11;
                        _context3.next = 14;
                        return method({
                            id: id,
                            openId: openid,
                            page: page,
                            pageSize: pageSize,
                            noteType: noteType,
                            needVideo: canShowVideoGif,
                            needCount: true
                        });

                      case 14:
                        _context3.t0 = _context3.sent;
                        if (_context3.t0) {
                            _context3.next = 17;
                            break;
                        }
                        _context3.t0 = [];

                      case 17:
                        relatedNotes = _context3.t0;
                        _this5.setData({
                            relatedNotesPageInfo: {
                                pageSize: pageSize,
                                page: newPage
                            }
                        });
                        _context3.next = 24;
                        break;

                      case 21:
                        _context3.prev = 21;
                        _context3.t1 = _context3["catch"](11);
                        (0, _track.trackApm)({
                            action: "get-related-notes-err"
                        });

                      case 24:
                        relatedNotes = relatedNotes.map(function(note) {
                            var _ref2 = note || {}, id = _ref2.id, cover = _ref2.cover, title = _ref2.title, desc = _ref2.desc, type = _ref2.type;
                            return _extends({}, note, {
                                image: cover,
                                id: id,
                                title: title || desc,
                                typeStr: type
                            });
                        });
                        newNoteList = isNoteFeed ? [].concat(_this5.data.videoFeedList, _this5.formatVideoFeedList(relatedNotes)) : [].concat(_this5.data.noteList, relatedNotes);
                        if (isNoteFeed) {
                            if (!relatedNotes || relatedNotes.length === 0) {
                                wx.showToast({
                                    title: "暂无更多内容，刷新试试",
                                    icon: "none"
                                });
                            }
                            _this5.setData({
                                videoFeedList: newNoteList,
                                fetchedRelatedNotes: true
                            });
                        } else {
                            _this5.setData({
                                noteList: newNoteList,
                                fetchedRelatedNotes: true
                            });
                        }

                      case 27:
                      case "end":
                        return _context3.stop();
                    }
                }
            }, _callee3, _this5, [ [ 11, 21 ] ]);
        }))();
    },
    formatVideoFeedList: function formatVideoFeedList(videoFeedList) {
        var result = videoFeedList.map(function(note) {
            var itemLaunchAppParameter = (0, _deeplink.getNoteDeepLink)(note.id, note.type);
            return _extends({}, note, {
                itemLaunchAppParameter: itemLaunchAppParameter,
                isPlaying: true,
                isEnd: false,
                imageList: [ note.cover ]
            });
        });
        return result;
    },
    initNormalNote: function initNormalNote() {
        this.setData({
            navigationBarConfig: {
                titleText: "笔记详情",
                backgroundColor: "#FFFFFF",
                textStyle: "black"
            }
        });
    },
    initVideoNote: function initVideoNote() {
        this.$eagletPageMeta.pageInstance = "video_feed";
        this.setData({
            navigationBarConfig: {
                titleText: "",
                backgroundColor: "transparent",
                textStyle: "white"
            }
        });
    },
    initAddMyMp: function initAddMyMp() {
        var _this6 = this;
        var pinMiniProgramTime = wx.getStorageSync(_enum.STORAGE_KEY.PIN_MINI_PROGRAM_FLAG);
        // eslint-disable-line
                var userInfo = wx.getStorageSync(_enum.STORAGE_KEY.USER_INFO) || {};
        // eslint-disable-line
                var isNewWxmpUser = userInfo.isNewWxmpUser;
        var now = new Date().getTime();
        if (!pinMiniProgramTime) {
            pinMiniProgramTime = now;
            this.setData({
                addMyMp: _extends({}, this.data.addMyMp, {
                    isShowAddMp: true
                })
            });
            if (isNewWxmpUser) {
                this.setData({
                    addMyMp: _extends({}, this.data.addMyMp, {
                        hasClose: true
                    })
                });
            } else {
                setTimeout(function() {
                    _this6.setData({
                        addMyMp: _extends({}, _this6.data.addMyMp, {
                            isShowAddMp: false
                        })
                    });
                }, 3e3);
            }
            wx.setStorage({
                key: _enum.STORAGE_KEY.PIN_MINI_PROGRAM_FLAG,
                data: pinMiniProgramTime
            });
            return;
        }
        if (pinMiniProgramTime && now - pinMiniProgramTime > (0, _datetime.getTimeStampByDay)(7)) {
            this.setData({
                addMyMp: _extends({}, this.data.addMyMp, {
                    isShowAddMp: true
                })
            });
            if (isNewWxmpUser) {
                this.setData({
                    addMyMp: _extends({}, this.data.addMyMp, {
                        hasClose: true
                    })
                });
            } else {
                setTimeout(function() {
                    _this6.setData({
                        addMyMp: _extends({}, _this6.data.addMyMp, {
                            isShowAddMp: false
                        })
                    });
                }, 3e3);
            }
            pinMiniProgramTime = now;
            wx.setStorage({
                key: _enum.STORAGE_KEY.PIN_MINI_PROGRAM_FLAG,
                data: pinMiniProgramTime
            });
        }
    },
    initSafety: function initSafety() {
        var needLogin = _abTest2.default.getABTestFlagValue("wx_mp_openid_need_login") === 1;
        if (needLogin && !_user2.default.getUserId()) {
            (0, _path.navigateTo)("LoginIndex", {
                theme: "openidForce"
            });
        }
    },
    initImageStickers: function initImageStickers(id) {
        var _this7 = this;
        return _asyncToGenerator(/* */ _regenerator2.default.mark(function _callee4() {
            var res, note, currentimageList;
            return _regenerator2.default.wrap(function _callee4$(_context4) {
                while (1) {
                    switch (_context4.prev = _context4.next) {
                      case 0:
                        _context4.next = 2;
                        return (0, _note.getNoteImageStickers)(id);

                      case 2:
                        res = _context4.sent;
                        note = _this7.data.note;
                        currentimageList = [];
                        if (note && note.imageList) {
                            currentimageList = note.imageList;
                        }
                        note.imageTags = _tag.TagUtil.prototype.transform(res, currentimageList.map(function(item) {
                            return item.fileId;
                        }));
                        _this7.setData({
                            note: note
                        });

                      case 8:
                      case "end":
                        return _context4.stop();
                    }
                }
            }, _callee4, _this7);
        }))();
    },
    initABTest: function initABTest() {
        var _this8 = this;
        return _asyncToGenerator(/* */ _regenerator2.default.mark(function _callee5() {
            var isShowNewCallbackStyle, showNewCallbackStyle, refluxType, expandType, noteFeedCanLaunchApp, isShowShareInfoBar, supportComment, videoSingleFeed, shareMomentType;
            return _regenerator2.default.wrap(function _callee5$(_context5) {
                while (1) {
                    switch (_context5.prev = _context5.next) {
                      case 0:
                        isShowNewCallbackStyle = void 0;
                        showNewCallbackStyle = void 0;
                        refluxType = void 0;
                        expandType = void 0;
                        noteFeedCanLaunchApp = void 0;
                        isShowShareInfoBar = void 0;
                        supportComment = void 0;
                        videoSingleFeed = 0;
                        shareMomentType = 0;
                        _context5.prev = 9;
                        _context5.next = 12;
                        return _api2.default.$instance.globalData.promise;

                      case 12:
                        noteFeedCanLaunchApp = _api2.default.$instance.globalData.canLaunchApp ? 1 : 0;
                        supportComment = _abTest2.default.getABTestFlagValue("wechat_support_comment") === 1;
                        showNewCallbackStyle = _abTest2.default.getABTestFlagValue("growth_wx_mp_note_callback") || 0;
                        refluxType = _abTest2.default.getABTestFlagValue("growth_wx_mp_note_reflux_type") || 0;
                        expandType = 2;
                        isShowShareInfoBar = _abTest2.default.getABTestFlagValue("isShowShareInfoBar") || false;
                        shareMomentType = _abTest2.default.getABTestFlagValue("wx_mp_show_share_btn");
                        videoSingleFeed = _abTest2.default.getABTestFlagValue("wx_mp_video_single_feed");
                        _context5.next = 25;
                        break;

                      case 22:
                        _context5.prev = 22;
                        _context5.t0 = _context5["catch"](9);
                        (0, _track.trackApm)({
                            action: "init_ab_error"
                        });

                      case 25:
                        _context5.t1 = showNewCallbackStyle;
                        _context5.next = _context5.t1 === 1 ? 28 : 30;
                        break;

                      case 28:
                        isShowNewCallbackStyle = true;
                        return _context5.abrupt("break", 32);

                      case 30:
                        isShowNewCallbackStyle = false;
                        return _context5.abrupt("break", 32);

                      case 32:
                        _this8.setData({
                            supportComment: supportComment,
                            refluxType: refluxType,
                            expandType: expandType,
                            isShowShareInfoBar: isShowShareInfoBar,
                            noteFeedCanLaunchApp: noteFeedCanLaunchApp,
                            isShowNewCallbackStyle: isShowNewCallbackStyle,
                            canShowVideoGif: true,
                            shareMomentType: shareMomentType,
                            videoSingleFeed: videoSingleFeed
                        });

                      case 33:
                      case "end":
                        return _context5.stop();
                    }
                }
            }, _callee5, _this8, [ [ 9, 22 ] ]);
        }))();
    },
    initShareInfo: function initShareInfo(note, noteTags) {
        var _this9 = this;
        // 生成分享信息
                (0, _shareInfo.initShareInfo)({
            canvasId: "share-canvas",
            note: note,
            noteTags: noteTags
        }).then(function(info) {
            if (info) {
                _this9.setData({
                    shareInfo: _extends({}, info, {
                        noteId: note.id,
                        noteType: note.type,
                        cover: note.cover,
                        user: note.user
                    })
                });
            }
        });
    },
    initEventBus: function initEventBus() {
        var _this10 = this;
        _eventBus2.default.on("showMpModal", function() {
            _this10.setData({
                showModal: true
            });
        });
        _eventBus2.default.on("closeMpModal", function() {
            _this10.setData({
                showModal: false,
                customConfirmModalDesc: ""
            });
        });
        _eventBus2.default.on("showLaunchAppModal", function() {
            _this10.setData({
                launchAppModalDesc: "",
                launchAppModalSource: "note-expand",
                showLaunchAppModal: true
            });
        });
        _eventBus2.default.on("closeLaunchAppModal", function() {
            _this10.setData({
                showLaunchAppModal: false
            });
        });
        _eventBus2.default.on("goToLogin", function(_ref3) {
            var source = _ref3.source;
            if (_abTest2.default.getABTestFlagValue("wx_mp_login_modal") === 1) {
                _this10.setData({
                    showLoginModalSource: source,
                    showLoginModal: true
                });
            } else {
                (0, _path.navigateTo)("LoginIndex", {
                    source: source
                });
            }
        });
    },
    removeEventBus: function removeEventBus() {
        _eventBus2.default.off("showMpModal");
        _eventBus2.default.off("closeMpModal");
        _eventBus2.default.off("showLaunchAppModal");
        _eventBus2.default.off("closeLaunchAppModal");
        _eventBus2.default.off("goToLogin");
    },
    handleCloseModal: function handleCloseModal() {
        this.setData({
            showLoginModal: false
        });
    },
    handleSetVideoFeedListValue: function handleSetVideoFeedListValue(e) {
        var _e$detail = e.detail, index = _e$detail.index, key = _e$detail.key, value = _e$detail.value;
        var update = "videoFeedList[" + index + "]." + key;
        this.setData(_defineProperty({}, update, value));
    },
    handleSetVideoFeedListObjectValue: function handleSetVideoFeedListObjectValue(e) {
        var _e$detail2 = e.detail, index = _e$detail2.index, value = _e$detail2.value;
        var update = "videoFeedList[" + index + "]";
        this.setData(_defineProperty({}, update, value));
    },
    handlehandleresetVideoFeedNote: function handlehandleresetVideoFeedNote(e) {
        var id = e.detail.id;
        var videoFeedList = this.data.videoFeedList;
        var findIndex = videoFeedList.findIndex(function(item) {
            return item.id === id;
        });
        var update = "videoFeedList[" + findIndex + "]";
        this.setData(_defineProperty({}, update, _extends({}, videoFeedList[findIndex], {
            isPlaying: true,
            isEnd: false
        })));
    },
    handleFetchMoreVideoFeed: function handleFetchMoreVideoFeed() {
        this.fetchRelatedNotes(TYPE_VIDEO_FEED);
    },
    handleChangeVideoFeedNote: function handleChangeVideoFeedNote(e) {
        var id = e.detail.id;
        var _data5 = this.data, videoFeedList = _data5.videoFeedList, shareUserId = _data5.shareUserId;
        var findIndex = videoFeedList.findIndex(function(item) {
            return item.id === id;
        });
        if (findIndex > -1) {
            wx.$eaglet.page.initPage({
                id: id
            });
            var trackId = findIndex === 0 ? 2104 : 2187;
            wx.$eaglet.page.trackPageView(_mp.tracker[trackId]({
                trackId: "None",
                shareUserId: shareUserId
            }));
            this.initShareInfo(videoFeedList[findIndex]);
            this.setData({
                videoFeedIndex: findIndex
            });
        }
    },
    handleFollowAppUser: function handleFollowAppUser(detail) {
        var _this11 = this;
        var _data6 = this.data, videoFeedIndex = _data6.videoFeedIndex, videoFeedList = _data6.videoFeedList;
        var user = detail.user;
        var index = -1;
        videoFeedList.forEach(function(val, valIndex) {
            if (val.id === detail.id) {
                index = valIndex;
            }
        });
        var key = "user.isFollowed";
        var update = "videoFeedList[" + index + "]." + key;
        if (!user.isFollowed) {
            if (videoFeedIndex === 0) {
                wx.$eaglet.page.trackPageView(_mp.tracker[2140]({
                    objectPosition: videoFeedIndex + 1,
                    noteId: detail.id,
                    noteType: "video_note",
                    authorId: user.id,
                    userId: _user2.default.getUserId()
                }));
            } else {
                wx.$eaglet.page.trackPageView(_mp.tracker[2141]({
                    adsTarget_trackId: "",
                    // eslint-disable-line
                    noteTarget_trackId: "",
                    // eslint-disable-line
                    objectPosition: videoFeedIndex + 1,
                    noteId: detail.id,
                    noteType: "video_note",
                    authorId: user.id,
                    userId: _user2.default.getUserId()
                }));
            }
            (0, _appuser.followUser)({
                userId: user.id
            }).then(function() {
                (0, _track.trackNormalData)({
                    action: "follow-tap",
                    label: "follow-button",
                    property: user.id
                });
                _this11.setData(_defineProperty({}, update, true));
            });
        } else {
            (0, _appuser.unfollowUser)({
                userId: user.id
            }).then(function() {
                (0, _track.trackNormalData)({
                    action: "unfollow-tap",
                    label: "unfollow-button",
                    property: user.id
                });
                _this11.setData(_defineProperty({}, update, false));
            });
        }
    },
    handleFocuseOn: function handleFocuseOn(note) {
        var _this12 = this;
        return _asyncToGenerator(/* */ _regenerator2.default.mark(function _callee6() {
            var detail;
            return _regenerator2.default.wrap(function _callee6$(_context6) {
                while (1) {
                    switch (_context6.prev = _context6.next) {
                      case 0:
                        detail = note.detail.detail;
                        _context6.next = 3;
                        return _user2.default.ensureLogin();

                      case 3:
                        _this12.handleFollowAppUser(detail);

                      case 4:
                      case "end":
                        return _context6.stop();
                    }
                }
            }, _callee6, _this12);
        }))();
    }
});