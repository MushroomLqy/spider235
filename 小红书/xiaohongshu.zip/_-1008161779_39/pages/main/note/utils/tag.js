Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.TagUtil = undefined;

var _createClass = function() {
    function defineProperties(target, props) {
        for (var i = 0; i < props.length; i++) {
            var descriptor = props[i];
            descriptor.enumerable = descriptor.enumerable || false;
            descriptor.configurable = true;
            if ("value" in descriptor) descriptor.writable = true;
            Object.defineProperty(target, descriptor.key, descriptor);
        }
    }
    return function(Constructor, protoProps, staticProps) {
        if (protoProps) defineProperties(Constructor.prototype, protoProps);
        if (staticProps) defineProperties(Constructor, staticProps);
        return Constructor;
    };
}();

var _icons = require("../../../../utils/icons");

function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}

var TagUtil = exports.TagUtil = function() {
    function TagUtil() {
        _classCallCheck(this, TagUtil);
    }
    _createClass(TagUtil, [ {
        key: "transform",
        value: function transform() {
            var source = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
            var fileidList = arguments[1];
            var ret = fileidList.map(function(fileId) {
                var rst = [];
                source.some(function(item) {
                    if (item.fileid === fileId) {
                        rst = item.stickers.floating.map(function(r) {
                            var newObject = {};
                            try {
                                newObject.anchorCenter = JSON.parse("[" + r.anchorCenter.replace("{", "").replace("}", "") + "]");
                                newObject.containerSize = JSON.parse("[" + r.containerSize.replace("{", "").replace("}", "") + "]");
                                newObject.unitCenter = JSON.parse("[" + r.unitCenter.replace("{", "").replace("}", "") + "]");
                            } catch (error) {
                                return r;
                            }
                            newObject.icon = (0, _icons.getStickerUrl)(r.type);
                            if (r.type === "audio") {
                                newObject.duration = (r.audioInfo.duration / 1e3).toFixed(0);
                            }
                            var isRight = r.style === 1;
                            var x = newObject.unitCenter[0] * 100;
                            var y = newObject.unitCenter[1] * 100;
                            var textMaxWidth = 206;
                            var widthItem = 4;
                            if (isRight && x >= 55 || !isRight && x <= 45) {
                                widthItem = 10;
                            }
                            if (isRight && x <= 20 || !isRight && x >= 80) {
                                widthItem = 1.28;
                                newObject.innerStyle = !isRight ? "margin-left: -65%;" : "margin-left: -50%;";
                            } else {
                                newObject.innerStyle = "margin-left: -50%;";
                            }
                            if (isRight) {
                                textMaxWidth = (100 - x) * widthItem;
                            } else {
                                textMaxWidth = x * widthItem;
                            }
                            newObject.textStyle = "max-width: " + textMaxWidth + "rpx;";
                            return Object.assign({}, r, newObject);
                        });
                    }
                    return item.fileid === fileId;
                });
                return rst;
            });
            // let ret = source.map(item => {
            //   let rst = []
            //   if (!item.stickers.floating) {
            //     return rst
            //   } else {
            //     return item.stickers.floating.map(r => {
            //       let newObject = {}
            //       try {
            //         newObject.anchorCenter = JSON.parse('[' + r.anchorCenter.replace('{', '').replace('}', '') + ']')
            //         newObject.containerSize = JSON.parse('[' + r.containerSize.replace('{', '').replace('}', '') + ']')
            //         newObject.unitCenter = JSON.parse('[' + r.unitCenter.replace('{', '').replace('}', '') + ']')
            //       } catch (error) {
            //         return r
            //       }
            //       newObject.icon = getStickerUrl(r.type)
            //       if (r.type === 'audio') {
            //         newObject.duration = (r.audioInfo.duration / 1000).toFixed(0)
            //       }
            //       let isRight = (r.style === 1)
            //       let x = newObject.unitCenter[0] * 100
            //       let y = newObject.unitCenter[1] * 100
            //       let textMaxWidth = 206
            //       let widthItem = 4
            //       if (isRight && x >= 55 || !isRight && x <= 45) {
            //         widthItem = 10
            //       }
            //       if (isRight && x <= 20 || !isRight && x >= 80) {
            //         widthItem = 1.28
            //         newObject.innerStyle = !isRight
            //           ? 'margin-left: -65%;'
            //           : 'margin-left: -50%;'
            //       } else {
            //         newObject.innerStyle = 'margin-left: -50%;'
            //       }
            //       if (isRight) {
            //         textMaxWidth = (100 - x) * widthItem
            //       } else {
            //         textMaxWidth = x * widthItem
            //       }
            //       newObject.textStyle = `max-width: ${textMaxWidth}rpx;`
            //       return Object.assign({}, r, newObject)
            //     })
            //   }
            // })
                        return ret;
        }
    } ]);
    return TagUtil;
}();