Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.getNoteDeepLink = undefined;

var _user = require("../../../../utils/user");

var _user2 = _interopRequireDefault(_user);

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

// 获取笔记 deeplink
var getNoteDeepLink = exports.getNoteDeepLink = function getNoteDeepLink(id, type) {
    var params = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    var otherDeeplink = arguments[3];
    var _ref = _user2.default.getUserInfo() || {}, openid = _ref.openid;
    var moreParams = [ "openid=" + openid ];
    Object.keys(params).forEach(function(key) {
        moreParams.push(key + "=" + params[key]);
    });
    var moreParamsStr = moreParams.join("&");
    if (moreParams.length > 0) {
        moreParamsStr = "&" + moreParamsStr;
    }
    if (type === "video") {
        var videoDeeplink = otherDeeplink ? otherDeeplink : "xhsdiscover://video_feed/" + id;
        return videoDeeplink + "?sourceId=miniprogram&feedType=video" + moreParamsStr;
    }
    var normalDeeplink = otherDeeplink ? otherDeeplink : "xhsdiscover://portrait_feed/" + id;
    return normalDeeplink + "?sourceId=miniprogram&feedType=normal&title=%e7%ac%94%e8%ae%b0" + moreParamsStr;
};