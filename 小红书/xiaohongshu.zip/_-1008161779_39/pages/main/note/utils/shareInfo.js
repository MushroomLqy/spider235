Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.initShareInfo = undefined;

var _regenerator = require("./../../../../karin_npm/babel-runtime/regenerator/index.js");

var _regenerator2 = _interopRequireDefault(_regenerator);

var initShareInfo = exports.initShareInfo = function() {
    var _ref = _asyncToGenerator(/* */ _regenerator2.default.mark(function _callee() {
        var info = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
        var CDN_ORIGIN, _ref2, canvasId, note, noteTags, shareInfo, _ref3, imageList, likes, user, type, context, canvasWidth, canvasHeight, _ref4, nickname, imageInfo, videoIcon, imageInfoArray, i, image, avatarInfo, noteTagInfo, likedCountTextInfo, drawCanvas, resInfo;
        return _regenerator2.default.wrap(function _callee$(_context) {
            while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    CDN_ORIGIN = "https://ci.xiaohongshu.com";
                    _ref2 = info || {}, canvasId = _ref2.canvasId, note = _ref2.note, noteTags = _ref2.noteTags;
                    shareInfo = {};
                    CanvasUtil.initCanvas(canvasId);
                    _ref3 = note || {}, imageList = _ref3.imageList, likes = _ref3.likes, user = _ref3.user, 
                    type = _ref3.type;
                    context = CanvasUtil.context;
                    canvasWidth = 210;
                    canvasHeight = 168;
                    _ref4 = user || {}, nickname = _ref4.nickname;
                    shareInfo.shareTitle = "@" + nickname + " 发了一篇笔记，快点来看吧！";
                    if (note.title) {
                        shareInfo.shareTitle = note.title;
                    } else if (note.desc) {
                        shareInfo.shareTitle = note.desc;
                    }
                    context.setFillStyle("white");
                    context.fillRect(0, 0, canvasWidth, canvasHeight);
                    if (imageList && imageList.length) {
                        _context.next = 15;
                        break;
                    }
                    return _context.abrupt("return");

                  case 15:
                    if (!(imageList.length < 3)) {
                        _context.next = 40;
                        break;
                    }
                    if (imageList[0].fileId) {
                        _context.next = 18;
                        break;
                    }
                    return _context.abrupt("return");

                  case 18:
                    _context.prev = 18;
                    imageInfo = {
                        x: 0,
                        y: 22,
                        width: 210,
                        height: 146,
                        radius: 2
                    };
                    imageInfo.path = CDN_ORIGIN + "/" + imageList[0].fileId + "?imageMogr2/crop/" + imageInfo.width * 2 + "x" + imageInfo.height * 2 + "/gravity/center";
                    _context.next = 23;
                    return CanvasUtil.drawImageWithRadius(imageInfo);

                  case 23:
                    _context.next = 28;
                    break;

                  case 25:
                    _context.prev = 25;
                    _context.t0 = _context["catch"](18);
                    return _context.abrupt("return");

                  case 28:
                    if (!(type === "video")) {
                        _context.next = 38;
                        break;
                    }
                    _context.prev = 29;
                    videoIcon = {
                        path: "https://ci.xiaohongshu.com/91b3be0e-c47e-4bdd-85f0-857675c29bc6",
                        x: 90,
                        y: 80,
                        width: 30,
                        height: 30
                    };
                    _context.next = 33;
                    return CanvasUtil.drawImage(videoIcon);

                  case 33:
                    _context.next = 38;
                    break;

                  case 35:
                    _context.prev = 35;
                    _context.t1 = _context["catch"](29);
                    return _context.abrupt("return");

                  case 38:
                    _context.next = 58;
                    break;

                  case 40:
                    // 图片超过三张
                    imageInfoArray = [ {
                        x: 0,
                        y: 22,
                        width: 133,
                        height: 146,
                        radius: 2
                    }, {
                        x: 135,
                        y: 22,
                        width: 75,
                        height: 72,
                        radius: 2
                    }, {
                        x: 135,
                        y: 96,
                        width: 75,
                        height: 72,
                        radius: 2
                    } ];
                    i = 0;

                  case 42:
                    if (!(i < 3)) {
                        _context.next = 58;
                        break;
                    }
                    _context.prev = 43;
                    image = imageInfoArray[i];
                    if (imageList[i].fileId) {
                        _context.next = 47;
                        break;
                    }
                    return _context.abrupt("return");

                  case 47:
                    image.path = CDN_ORIGIN + "/" + imageList[i].fileId + "?imageView2/1/w/" + imageInfoArray[i].width * 3 + "/h/" + imageInfoArray[i].height * 3;
                    _context.next = 50;
                    return CanvasUtil.drawImageWithRadius(image);

                  case 50:
                    _context.next = 55;
                    break;

                  case 52:
                    _context.prev = 52;
                    _context.t2 = _context["catch"](43);
                    return _context.abrupt("return");

                  case 55:
                    i++;
                    _context.next = 42;
                    break;

                  case 58:
                    if (!(noteTags && noteTags.length)) {
                        _context.next = 70;
                        break;
                    }
                    _context.prev = 59;
                    avatarInfo = {
                        path: "https://fe-img-qc.xhscdn.com/15a0f3538fc4d9f9fcd852d0537f09d709547340",
                        x: 9,
                        y: 10,
                        width: 12
                    };
                    noteTagInfo = {
                        text: noteTags[0].name,
                        color: "#5B92E1",
                        x: 18,
                        y: 14,
                        size: 10,
                        align: "left"
                    };
                    _context.next = 64;
                    return CanvasUtil.drawAvatar(avatarInfo);

                  case 64:
                    CanvasUtil.drawText(noteTagInfo);
                    _context.next = 70;
                    break;

                  case 67:
                    _context.prev = 67;
                    _context.t3 = _context["catch"](59);
                    return _context.abrupt("return");

                  case 70:
                    // 如果有点赞数，显示点赞数
                    if (typeof likes === "number") {
                        likedCountTextInfo = {
                            text: getNum(likes, 1) + " 次赞",
                            color: "#666666",
                            x: 205,
                            y: 14,
                            size: 10,
                            align: "right"
                        };
                        CanvasUtil.drawText(likedCountTextInfo);
                    }
                    drawCanvas = function drawCanvas() {
                        return new Promise(function(resolve) {
                            context.draw(true, function() {
                                setTimeout(function() {
                                    resolve();
                                }, 500);
                            });
                        });
                    };
                    _context.next = 74;
                    return drawCanvas();

                  case 74:
                    resInfo = void 0;
                    _context.prev = 75;
                    _context.next = 78;
                    return _api2.default.canvasToTempFilePath({
                        canvasId: canvasId,
                        width: 210,
                        height: 168,
                        destWidth: 840,
                        destHeight: 672,
                        fileType: "png"
                    });

                  case 78:
                    resInfo = _context.sent;
                    _context.next = 84;
                    break;

                  case 81:
                    _context.prev = 81;
                    _context.t4 = _context["catch"](75);
                    return _context.abrupt("return");

                  case 84:
                    if (resInfo && resInfo.tempFilePath) {
                        shareInfo.shareImageUrl = resInfo.tempFilePath;
                    }
                    return _context.abrupt("return", shareInfo);

                  case 86:
                  case "end":
                    return _context.stop();
                }
            }
        }, _callee, this, [ [ 18, 25 ], [ 29, 35 ], [ 43, 52 ], [ 59, 67 ], [ 75, 81 ] ]);
    }));
    return function initShareInfo() {
        return _ref.apply(this, arguments);
    };
}();

var _canvas = require("../../../../utils/canvas");

var _canvas2 = _interopRequireDefault(_canvas);

var _api = require("../../../../utils/api");

var _api2 = _interopRequireDefault(_api);

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

function _asyncToGenerator(fn) {
    return function() {
        var gen = fn.apply(this, arguments);
        return new Promise(function(resolve, reject) {
            function step(key, arg) {
                try {
                    var info = gen[key](arg);
                    var value = info.value;
                } catch (error) {
                    reject(error);
                    return;
                }
                if (info.done) {
                    resolve(value);
                } else {
                    return Promise.resolve(value).then(function(value) {
                        step("next", value);
                    }, function(err) {
                        step("throw", err);
                    });
                }
            }
            return step("next");
        });
    };
}

var CanvasUtil = new _canvas2.default();

var getNum = function getNum(num) {
    var point = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 2;
    if (num >= 1e4) {
        return Number((num / 1e4).toFixed(point)) + "万";
    }
    if (num >= 1e8) {
        return Number((num / 1e8).toFixed(point)) + "亿";
    }
    return num;
};