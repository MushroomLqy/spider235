Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.getAbsoluteWebviewUrl = getAbsoluteWebviewUrl;

var customsMessageGroupId = exports.customsMessageGroupId = "5d158bfa7517820001de6a17";

function getAbsoluteWebviewUrl() {
    var link = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
    var character = link.includes("?") ? "&" : "?";
    return "" + link + character + "utm_source=social&groupid=" + customsMessageGroupId;
}