var _discovery = require("../../../../../utils/discovery");

var _vuefy = require("../../../../../libs/vuefy.js");

Component({
    behaviors: [],
    properties: {
        desc: {
            type: String
        },
        hashTag: {
            type: Array
        },
        ats: {
            type: Array
        },
        isExpand: Boolean,
        canLaunchApp: Boolean,
        expandButtonStyle: {
            type: Number,
            value: 0
        },
        launchAppParameter: String,
        customMessageReplyInfo: Object,
        customMessageCardInfo: {
            type: Object,
            default: {}
        },
        expandType: {
            type: Number,
            value: 0
        },
        noteTags: {
            type: Array
        }
    },
    data: {
        formatedDesc: []
    },
    // 生命周期函数，可以为函数，或一个在methods段中定义的方法名
    attached: function attached() {},
    moved: function moved() {},
    detached: function detached() {},
    ready: function ready() {
        (0, _vuefy.computed)(this, {
            formatedDesc: function formatedDesc() {
                var desc = this.data.desc;
                var hashTags = this.data.hashTag || [];
                var ats = this.data.ats || [];
                var arr = [];
                var descArr = desc.split("\n");
                arr = descArr.map(function(item) {
                    return (0, _discovery.getFormatedExpressionArr)(item, hashTags, ats);
                });
                return arr;
            }
        });
    },
    // 组件所在页面的生命周期函数
    show: function show() {},
    methods: {
        handleTriggerExpand: function handleTriggerExpand(e) {
            var canExpand = e.detail.canExpand;
            this.triggerEvent("triggerexpand", {
                canExpand: canExpand
            });
        }
    }
});