var _api = require("../../../../../utils/api");

var _api2 = _interopRequireDefault(_api);

var _track = require("../../../../../utils/track");

var _user = require("../../../../../utils/user");

var _user2 = _interopRequireDefault(_user);

var _path = require("../../../../../utils/path");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

Component({
    behaviors: [],
    properties: {
        note: Object,
        showExpand: Boolean
    },
    attached: function attached() {
        var _this = this;
        this.setData({
            showExpandBut: this.properties.showExpand
        });
        var CurrentSystemInfo = _api2.default.$instance.globalData.systemInfo;
        var px2rpx = function px2rpx(rpx) {
            return rpx * 750 / CurrentSystemInfo.windowWidth;
        };
        this.createSelectorQuery().select(".video-content-box").boundingClientRect(function(res) {
            var rpxHeight = px2rpx(res.height);
            _this.triggerEvent("setUnexpandHeight", res.height);
            if (rpxHeight > 92) {
                _this.setData({
                    showExpand: true
                });
            }
            _this.setData({
                isExpand: false,
                initFinished: true
            });
        }).exec();
    },
    data: {
        showExpandBut: false
    },
    methods: {
        handleFocuseOn: function handleFocuseOn() {
            this.triggerEvent("focuse", this.properties.note);
        },
        handleExpand: function handleExpand() {
            this.triggerEvent("expand");
        },
        handleTapAvatar: function handleTapAvatar() {
            var id = this.properties.note.user.id;
            (0, _track.trackNormalData)({
                action: "avatar-tap",
                label: "author-avatar",
                property: id
            });
            _user2.default.ensureLogin().then(function() {
                (0, _path.navigateTo)("AuthorPage", {
                    author_id: id
                });
            });
        }
    }
});