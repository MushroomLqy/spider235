var _regenerator = require("./../../../../../karin_npm/babel-runtime/regenerator/index.js");

var _regenerator2 = _interopRequireDefault(_regenerator);

var _extends = Object.assign || function(target) {
    for (var i = 1; i < arguments.length; i++) {
        var source = arguments[i];
        for (var key in source) {
            if (Object.prototype.hasOwnProperty.call(source, key)) {
                target[key] = source[key];
            }
        }
    }
    return target;
};

var _deeplink = require("../../utils/deeplink");

var _path = require("../../../../../utils/path");

var _api = require("../../../../../utils/api");

var _api2 = _interopRequireDefault(_api);

var _image = require("../../../../../utils/image");

var _abTest = require("../../../../../utils/ab-test");

var _abTest2 = _interopRequireDefault(_abTest);

var _system = require("../../../../../utils/system");

var _system2 = _interopRequireDefault(_system);

var _track = require("../../../../../utils/track");

var _author = require("../../../../../services/author");

var _vuefy = require("../../../../../libs/vuefy.js");

var _eventBus = require("../../../../../libs/event-bus");

var _eventBus2 = _interopRequireDefault(_eventBus);

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

function _asyncToGenerator(fn) {
    return function() {
        var gen = fn.apply(this, arguments);
        return new Promise(function(resolve, reject) {
            function step(key, arg) {
                try {
                    var info = gen[key](arg);
                    var value = info.value;
                } catch (error) {
                    reject(error);
                    return;
                }
                if (info.done) {
                    resolve(value);
                } else {
                    return Promise.resolve(value).then(function(value) {
                        step("next", value);
                    }, function(err) {
                        step("throw", err);
                    });
                }
            }
            return step("next");
        });
    };
}

var time = void 0;

var bannerCallBackIsImpressioned = false;

Component({
    behaviors: [],
    properties: {
        images: Object,
        imageTags: Array,
        swiperHeight: Number,
        noteIndex: String,
        isShowNewCallbackStyle: Boolean,
        launchAppParameter: String,
        authorId: String,
        noteId: String
    },
    data: {
        current: 1,
        showOtherNotes: false,
        // swiperHeight: 0,
        opacity: 0,
        zindex: 0,
        stickerPointData: {},
        hideTag: false,
        moreNotes: null,
        noLaunchApp: false
    },
    // 生命周期函数，可以为函数，或一个在methods段中定义的方法名
    attached: function attached() {},
    moved: function moved() {},
    detached: function detached() {},
    ready: function() {
        var _ref = _asyncToGenerator(/* */ _regenerator2.default.mark(function _callee() {
            var lastScaleNum, animationTime, stickerPointAnimation;
            return _regenerator2.default.wrap(function _callee$(_context) {
                while (1) {
                    switch (_context.prev = _context.next) {
                      case 0:
                        bannerCallBackIsImpressioned = false;
                        _context.next = 3;
                        return _api2.default.$instance.globalData.promise;

                      case 3:
                        this.setData({
                            noLaunchApp: !_api2.default.$instance.globalData.canLaunchApp,
                            showOtherNotes: _abTest2.default.getABTestFlagValue("wx_mp_swiper_other_notes") === 1
                        });
                        (0, _vuefy.computed)(this, {
                            formatedImages: function formatedImages() {
                                return this.data.images.map(function(item) {
                                    return Object.assign({}, item, {
                                        url: (0, _image.getFormatedUrl)({
                                            url: item.url,
                                            width: 800,
                                            quality: 85
                                        })
                                    });
                                });
                            },
                            showCallBackBanner: function showCallBackBanner() {
                                var result = this.data.isShowNewCallbackStyle && this.data.images.length === this.data.current;
                                // 增加曝光打点
                                                                if (!bannerCallBackIsImpressioned && result) {
                                    (0, _track.trackNormalData)({
                                        action: "launch_app_track_data",
                                        property: "swiper_last_image",
                                        label: "impression"
                                    });
                                    bannerCallBackIsImpressioned = true;
                                }
                                return result;
                            }
                        });
                        lastScaleNum = 1;
                        animationTime = 1e3;
                        stickerPointAnimation = wx.createAnimation({
                            transformOrigin: "50% 50%",
                            duration: animationTime,
                            timingFunction: "ease",
                            delay: 0
                        });

                        // globalIntervalInstance.addIntervalTask(() => {
                        //   this.setData({
                        //     stickerPointData: {}
                        //   })
                        //   let nowScaleNum = (lastScaleNum === 1) ?
                        //     0.4 :
                        //     1
                        //   stickerPointAnimation.scale(nowScaleNum, nowScaleNum).step()
                        //   lastScaleNum = nowScaleNum
                        //   this.setData({
                        //     stickerPointData: stickerPointAnimation.export()
                        //   })
                        // }, animationTime)
                                              case 8:
                      case "end":
                        return _context.stop();
                    }
                }
            }, _callee, this);
        }));
        function ready() {
            return _ref.apply(this, arguments);
        }
        return ready;
    }(),
    // 组件所在页面的生命周期函数
    show: function show() {},
    methods: {
        handleSaveImage: function handleSaveImage(e) {
            if (!_api2.default.$instance.globalData.canLaunchApp) {
                return;
            }
            console.log("!!", e);
            var index = e.target.dataset.index;
            (0, _track.trackNormalData)({
                action: "long_press_image_swiper",
                property: index
            });
            _eventBus2.default.emit("longPressSaveImage");
        },
        handleAudioTagTap: function handleAudioTagTap() {
            _eventBus2.default.emit("tapAudioTagTap");
        },
        handleSwiperTagTap: function handleSwiperTagTap(e) {
            if (!e || !e.currentTarget || !e.currentTarget.dataset || !e.currentTarget.dataset.sticker) {
                return;
            }
            var sticker = e.currentTarget.dataset.sticker;
            var goodsStr = "/goods/";
            var userStr = "/user/";
            var link = sticker.event.value.link || "";
            var startGoodsStrIndex = link.indexOf(goodsStr);
            var startUserStrIndex = link.indexOf(userStr);
            var isGoods = sticker.type === "goods";
            var isUser = sticker.type === "user";
            var isPages = link.indexOf("/page/") > -1 || link.indexOf("/tag/") > -1;
            if (isGoods) {
                var id = link.substr(startGoodsStrIndex + goodsStr.length, 24);
                (0, _path.navigateTo)("Webview", {
                    link: "/goods/" + id
                });
                return;
            }
            if (isUser) {
                var _id = link.substr(startUserStrIndex + userStr.length, 24);
                (0, _path.navigateTo)("AuthorPage", {
                    id: _id
                });
                return;
            }
            if (!isPages || !link) {
                (0, _path.navigateTo)("SearchResult", {
                    keyValue: sticker.event.value.name
                });
                return;
            }
            (0, _path.navigateTo)("Webview", {
                link: link
            });
        },
        handleSwiperItemTap: function handleSwiperItemTap() {
            this.setData({
                hideTag: !this.data.hideTag
            });
        },
        handleImageLoad: function handleImageLoad(e) {
            if (!e || !e.target || !e.target.dataset || e.target.dataset.index === undefined) {
                return;
            }
            if (e.target.dataset.index === 0 && this.data.noteIndex === "0") {
                this.triggerEvent("firstImageSwitched");
            }
            this.setData({
                opacity: 1,
                zindex: 1
            });
        },
        handleOtherNoteItemTap: function handleOtherNoteItemTap(e) {
            var currentTarget = e.currentTarget;
            var noteId = currentTarget.dataset.id;
            (0, _track.trackNormalData)({
                action: "open_image_swiper_other_note",
                property: noteId
            });
            (0, _path.navigateTo)("NoteDetail", {
                id: noteId
            });
        },
        handleNoteImageSwitched: function handleNoteImageSwitched(e) {
            var _this = this;
            if (!e || !e.detail || e.detail.current === undefined) {
                return;
            }
            var current = e.detail.current;
            var newCurrent = Math.min(this.data.images.length, current + 1);
            if (this.data.showOtherNotes && current + 1 === this.data.images.length) {
                (0, _track.trackNormalData)({
                    action: "impression_image_swiper_other_notes"
                });
            }
            if (newCurrent === this.data.images.length) {
                var systemInfo = _system2.default.getSystemInfo();
                if (!this.data.moreNotes) {
                    (0, _author.getNoteUser)({
                        userId: this.data.authorId,
                        page: 1,
                        pageSize: 10
                    }).then(function() {
                        var data = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
                        var moreNotes = data.filter(function(item) {
                            return item.id !== _this.data.noteId;
                        });
                        moreNotes.length = moreNotes.length > 6 ? 6 : moreNotes.length;
                        if (systemInfo.windowWidth > _this.data.swiperHeight) {
                            moreNotes.length = moreNotes.length > 3 ? 3 : moreNotes.length;
                        }
                        moreNotes = moreNotes.map(function(newNote) {
                            var launchAppParameter = (0, _deeplink.getNoteDeepLink)(newNote.id, newNote.type);
                            return _extends({}, newNote, {
                                launchAppParameter: launchAppParameter
                            });
                        });
                        _this.setData({
                            moreNotes: moreNotes
                        });
                    });
                }
            }
            this.setData({
                current: newCurrent
            });
            this.triggerEvent("noteImageSwitched", {
                current: newCurrent
            });
        }
    }
});