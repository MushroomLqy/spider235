var _icons = require("../../../../../utils/icons");

var _icons2 = _interopRequireDefault(_icons);

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

Component({
    behaviors: [],
    properties: {
        imageSrc: String,
        isOfficialVerified: Boolean,
        width: {
            type: Number,
            value: 80
        },
        hasBorder: Boolean
    },
    data: {
        officalVerifiedSrc: (0, _icons.getAbsoluteUrl)("ci.xiaohongshu.com", _icons2.default.officalVerified)
    },
    // 生命周期函数，可以为函数，或一个在methods段中定义的方法名
    attached: function attached() {},
    moved: function moved() {},
    detached: function detached() {},
    ready: function ready() {},
    // 组件所在页面的生命周期函数
    show: function show() {},
    methods: {
        handleAvatarError: function handleAvatarError() {
            this.setData({
                imageSrc: "http://ci.xiaohongshu.com/4dbf6dd3-7611-4625-90f3-91928fe0e4b0"
            });
        }
    }
});