Component({
    options: {
        multipleSlots: true
    },
    behaviors: [],
    properties: {
        showModal: Boolean,
        user: Object,
        modalWidth: Number,
        background: String
    },
    data: {
        showModal: false
    },
    // 生命周期函数，可以为函数，或一个在methods段中定义的方法名
    attached: function attached() {},
    moved: function moved() {},
    detached: function detached() {},
    ready: function ready() {},
    // 组件所在页面的生命周期函数
    show: function show() {},
    methods: {
        handleTabCloseModal: function handleTabCloseModal() {
            this.setData({
                showModal: false
            });
        },
        handleTabConfirm: function handleTabConfirm() {
            var user = this.data.user;
            this.triggerEvent("unfollowAppUser", {
                user: user
            });
            this.setData({
                showModal: false
            });
        }
    }
});