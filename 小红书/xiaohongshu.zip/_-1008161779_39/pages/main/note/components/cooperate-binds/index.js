var _path = require("../../../../../utils/path");

var _user = require("../../../../../utils/user");

var _user2 = _interopRequireDefault(_user);

var _track = require("../../../../../utils/track");

var _vuefy = require("../../../../../libs/vuefy.js");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

Component({
    options: {},
    behaviors: [],
    properties: {
        cooperateBinds: Array
    },
    data: {},
    // 生命周期函数，可以为函数，或一个在methods段中定义的方法名
    attached: function attached() {},
    moved: function moved() {},
    detached: function detached() {},
    ready: function ready() {
        (0, _vuefy.computed)(this, {
            formatedBrands: function formatedBrands() {
                var cooperateBinds = this.data.cooperateBinds;
                if (cooperateBinds.length > 0) {
                    cooperateBinds.map(function(item, index) {
                        if (index < cooperateBinds.length - 1) {
                            item.name = item.name + "、";
                        }
                    });
                }
                return cooperateBinds;
            }
        });
    },
    // 组件所在页面的生命周期函数
    show: function show() {},
    methods: {
        handleTapedCooperate: function handleTapedCooperate(e) {
            var _e$target$dataset = e.target.dataset, cooperateid = _e$target$dataset.cooperateid, link = _e$target$dataset.link;
            (0, _track.trackNormalData)({
                action: "click_cooperate_tag",
                property: cooperateid,
                label: !!link
            });
            if (link) {
                _user2.default.ensureLogin().then(function() {
                    (0, _path.navigateTo)("AuthorPage", {
                        id: cooperateid
                    });
                });
            }
        }
    }
});