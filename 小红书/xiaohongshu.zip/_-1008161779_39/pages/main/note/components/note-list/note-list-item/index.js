var _path = require("../.../../../../../../../utils/path");

var _track = require("../.../../../../../../../utils/track");

Component({
    properties: {
        note: Object,
        refluxType: {
            type: Number,
            value: 0
        },
        noLaunchApp: Boolean
    },
    data: {
        normalImageClass: "",
        gifImageClass: "hide",
        isLazyLoad: true
    },
    // 生命周期函数，可以为函数，或一个在methods段中定义的方法名
    attached: function attached() {// attached
    },
    moved: function moved() {// moved
    },
    detached: function detached() {// detached
    },
    methods: {
        handlGifLoaded: function handlGifLoaded() {
            this.setData({
                normalImageClass: "hide",
                gifImageClass: ""
            });
        },
        handleLaunchApp: function handleLaunchApp() {
            this.triggerEvent("feedItemLaunched");
        },
        handleNoteItemTap: function handleNoteItemTap() {
            var _ref = this.data.note || {}, id = _ref.id, objectPosition = _ref.objectPosition, trackId = _ref.trackId, eagletClick = _ref.eagletClick;
            if (!id) {
                return;
            }
            try {
                if (eagletClick) {
                    wx.$eaglet.push(eagletClick);
                }
            } catch (error) {
                console.error(error);
                // eslint-disable-line
                        }
            (0, _track.trackNormalData)({
                action: "note_card_click",
                label: JSON.stringify({
                    objectPosition: objectPosition,
                    trackId: trackId
                }),
                property: id
            });
            (0, _path.navigateTo)("NoteDetail", {
                id: id
            });
        },
        handleUserTap: function handleUserTap() {
            var _ref2 = this.data.note || {}, user = _ref2.user;
            var _ref3 = user || {}, id = _ref3.id;
            if (!id) {
                return;
            }
            (0, _path.navigateTo)("AuthorPage", {
                id: id
            });
        },
        handleLikeTap: function handleLikeTap() {
            return;
        }
    }
});