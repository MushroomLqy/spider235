var _vuefy = require("../../../../../libs/vuefy");

var _discovery = require("../../../../../utils/discovery");

var _api = require("../../../../../utils/api");

var _api2 = _interopRequireDefault(_api);

var _deeplink = require("../../utils/deeplink");

var _mp = require("../../../../../libs/@xhs/protobuf-mp-chakra-tracker/mp.js");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

var typeMap = {
    normal: "short_note",
    video: "video_note",
    multi: "long_note"
};

function getDoubleColumnNotes() {
    var notes = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
    var isFirstLogin = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
    var isNeverFillInRecommendTagForm = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
    if (!notes.length) {
        return {
            leftNotes: [],
            rightNotes: []
        };
    }
    var leftNotes = [];
    var rightNotes = [];
    var leftNotesHWRate = 0;
    var rightNotesHWRate = 0;
    notes.forEach(function(item, index) {
        var coverHWRate = void 0;
        var objectPosition = index + 1;
        item.objectPosition = objectPosition;
        // launch app 相关
                item.launchAppParameter = (0, _deeplink.getNoteDeepLink)(item.id, item.type, {
            position: "wxmp_note_feed",
            trackId: item.trackId
        });
        item.customMessageReplyInfo = {
            sessionFrom: JSON.stringify({
                url: "https://www.xiaohongshu.com/discovery/item/" + item.id + "?utm_source=social&groupid=5d158bfa7517820001de6a17",
                thumbUrl: item.cover.url,
                description: item.title,
                title: "点我，查看精彩内容！",
                deeplink: item.launchAppParameter
            })
        };
        item.customMessageCardInfo = {
            title: item.title,
            img: item.cover.url
        };
        item.launchAppTrackValue = JSON.stringify({
            id: item.id,
            objectPosition: objectPosition,
            trackId: item.trackId
        });
        item.trackData = JSON.stringify({
            label: "note_card",
            property: item.id,
            context: {},
            timeStamp: new Date().getTime()
        });
        item.impression = {
            id: item.id,
            // eaglet-identifier 用来标记改节点是否被曝光过
            eagletImpression: JSON.stringify(_mp.tracker[2577]({
                objectPosition: objectPosition,
                noteId: item.id,
                trackId: item.trackId,
                noteType: typeMap[item.type] || "short_note",
                authorId: item.user.id
            })),
            // eaglet-impression 为具体的点位信息
            offset: "-82/0/y"
        };
        item.eagletClick = _mp.tracker[2578]({
            objectPosition: objectPosition,
            noteId: item.id,
            trackId: item.trackId,
            noteType: typeMap[item.type] || "short_note",
            authorId: item.user.id
        });
        // 压缩图片
                if (item.image && item.image.url) {
            item.image.url = item.image.url.replace("imageView2/2/w/540/", "imageView2/2/w/400/q/85/");
        }
        // 如果没有标题就用正文当标题
                if (!item.title) {
            item.title = (0, _discovery.getNoTagNoFaceIconText)(item.desc);
        } else {
            item.title = (0, _discovery.getNoTagNoFaceIconText)(item.title);
        }
        if (item.videoInfo) {
            coverHWRate = item.videoInfo.height / item.videoInfo.width;
        } else {
            coverHWRate = item.image.height / item.image.width;
        }
        if (rightNotesHWRate < leftNotesHWRate) {
            rightNotesHWRate += coverHWRate;
            rightNotes.push(item);
        } else {
            leftNotesHWRate += coverHWRate;
            leftNotes.push(item);
        }
    });
    return {
        leftNotes: leftNotes,
        rightNotes: rightNotes
    };
}

Component({
    properties: {
        noteList: Array,
        refluxType: {
            type: Number,
            value: 0
        },
        launchAppParameter: String
    },
    data: {
        noLaunchApp: !_api2.default.$instance.globalData.canLaunchApp || _api2.default.$instance.globalData.noteFeedLaunched
    },
    // 生命周期函数，可以为函数，或一个在methods段中定义的方法名
    attached: function attached() {// attached
    },
    moved: function moved() {// moved
    },
    detached: function detached() {// detached
    },
    ready: function ready() {
        this.setData({
            noLaunchApp: !_api2.default.$instance.globalData.canLaunchApp || _api2.default.$instance.globalData.noteFeedLaunched
        });
        (0, _vuefy.computed)(this, {
            doubleColumnNotes: function doubleColumnNotes() {
                return getDoubleColumnNotes(this.data.noteList, this.isFirstLogin, this.isNeverFillInRecommendTagForm);
            }
        });
    },
    pageLifetimes: {
        show: function show() {},
        // 组件所在页面的生命周期函数
        hide: function hide() {}
    },
    methods: {
        handleFeedItemLaunched: function handleFeedItemLaunched() {
            _api2.default.$instance.globalData.noteFeedLaunched = true;
            this.setData({
                noLaunchApp: true
            });
        }
    }
});