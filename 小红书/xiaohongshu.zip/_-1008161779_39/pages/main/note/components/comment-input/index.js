var _track = require("../../../../../utils/track");

var _user = require("../../../../../utils/user");

var _user2 = _interopRequireDefault(_user);

var _comment = require("../../../../../services/comment.js");

var _mp = require("../../../../../libs/@xhs/protobuf-mp-chakra-tracker/mp.js");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

var apiProcessing = false;

var userInfo = _user2.default.getUserInfo();

Component({
    behaviors: [],
    properties: {
        noteId: String,
        authorId: String,
        commentId: {
            type: String,
            value: ""
        },
        commentHolder: {
            type: String,
            value: "写评论..."
        },
        focus: {
            type: Boolean,
            value: false
        },
        hasMask: {
            type: Boolean,
            value: true
        }
    },
    data: {
        avatar: userInfo && userInfo.appUserInfo && userInfo.appUserInfo.avatar,
        content: "",
        adjustPosition: true,
        inputStyle: "",
        isFocus: false
    },
    methods: {
        handleToComment: function handleToComment() {
            var _this = this;
            var _data = this.data, content = _data.content, noteId = _data.noteId, commentId = _data.commentId, authorId = _data.authorId;
            this.triggerEvent("hideCommentInput");
            if (!content || apiProcessing) {
                return;
            }
            apiProcessing = true;
            _user2.default.ensureLogin().then(function() {
                if (!content) {
                    apiProcessing = false;
                    return;
                }
                (0, _comment.comment)({
                    content: content,
                    noteId: noteId,
                    commentId: commentId
                }).then(function() {
                    var res = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
                    apiProcessing = false;
                    (0, _track.trackNormalData)({
                        action: "comment_submit"
                    });
                    var newCommentId = res && res.length && res[0] && res[0].id;
                    wx.$eaglet.push(_mp.tracker[2573]({
                        commentId: newCommentId,
                        isReply: false,
                        parentCommentId: "",
                        rootCommentId: "",
                        noteId: noteId,
                        authorId: authorId,
                        inDemoMode: false
                    }));
                    wx.showToast({
                        title: "评论已发布",
                        icon: "none"
                    });
                    _this.triggerEvent("commented");
                    _this.setData({
                        content: ""
                    });
                }).catch(function(e) {
                    apiProcessing = false;
                    if (e.detail && e.detail.msg) {
                        wx.showToast({
                            title: e.detail.msg,
                            icon: "none"
                        });
                    }
                });
            });
        },
        handleClickInput: function handleClickInput() {},
        // eslint-disable-line
        handleInputBlur: function handleInputBlur() {
            var _this2 = this;
            setTimeout(function() {
                if (apiProcessing) {
                    return;
                }
                _this2.triggerEvent("blur");
            }, 100);
        },
        handleHideInput: function handleHideInput() {
            this.triggerEvent("blur");
        },
        handleInputValue: function handleInputValue(e) {
            this.setData({
                content: e.detail.value
            });
        }
    }
});