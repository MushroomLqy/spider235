var _discovery = require("../../../../../utils/discovery");

var _user = require("../../../../../utils/user");

var _user2 = _interopRequireDefault(_user);

var _vuefy = require("../../../../../libs/vuefy.js");

var _path = require("../../../../../utils/path");

var _api = require("../../../../../utils/api");

var _api2 = _interopRequireDefault(_api);

var _customsMessage = require("../../utils/customsMessage");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

Component({
    behaviors: [],
    properties: {
        commentsCount: Number,
        commentList: Array,
        noteId: String,
        isNewStyle: Boolean,
        launchAppParameter: String,
        refluxType: {
            type: Number,
            value: 0
        },
        canLaunchApp: Boolean,
        customMessageCardInfo: {
            type: Object,
            default: {}
        },
        showCommentInput: Boolean
    },
    data: {
        formatedDescArray: [],
        // commentListData: [],
        appUserAvatar: _user2.default.getUserInfo() && _user2.default.getUserInfo().appUserInfo && _user2.default.getUserInfo().appUserInfo.avatar,
        showCommentInput: false,
        focus: true,
        noLaunchApp: false
    },
    // 生命周期函数，可以为函数，或一个在methods段中定义的方法名
    attached: function attached() {},
    moved: function moved() {},
    detached: function detached() {},
    ready: function ready() {
        this.setData({
            noLaunchApp: !_api2.default.$instance.globalData.canLaunchApp || _api2.default.$instance.globalData.noteCommentLaunched
        });
        (0, _vuefy.computed)(this, {
            commentCustomMessageReplyInfo: function commentCustomMessageReplyInfo() {
                var _data = this.data, launchAppParameter = _data.launchAppParameter, customMessageCardInfo = _data.customMessageCardInfo, canLaunchApp = _data.canLaunchApp;
                var result = {
                    modalDesc: "前往小红书App，查看更多精彩评论吧!",
                    sessionFrom: JSON.stringify({
                        url: (0, _customsMessage.getAbsoluteWebviewUrl)("https://www.xiaohongshu.com/discovery/item/" + this.data.noteId),
                        title: canLaunchApp ? "【点击下载小红书APP】" : "点我，查看更多评论！",
                        deeplink: launchAppParameter,
                        thumbUrl: customMessageCardInfo ? customMessageCardInfo.img : ""
                    })
                };
                return result;
            },
            commentLaunchAppParameter: function commentLaunchAppParameter() {
                return this.data.launchAppParameter + "&position=wxmp_note_comment";
            },
            commentListData: function commentListData() {
                var commentListData = this.data.commentList.map(function(item) {
                    var desc = item.content;
                    var descArr = desc.split("\n");
                    var formatedDesc = descArr.map(function(item) {
                        return (0, _discovery.getFormatedExpressionArr)(item, [], []);
                    });
                    return Object.assign({}, item, {
                        formatedDesc: formatedDesc
                    });
                });
                return commentListData;
            }
        });
        // this.setData({
        //   commentListData: commentListData
        // })
        // this.setData({
        // appUserAvatar: User.getUserInfo().appUserInfo.avatar
        // })
        },
    // 组件所在页面的生命周期函数
    show: function show() {},
    methods: {
        handleGoCommentPage: function handleGoCommentPage() {
            var noteId = this.data.noteId;
            _user2.default.ensureLogin().then(function() {
                (0, _path.navigateTo)("NoteCommentDetail", {
                    id: noteId
                });
            });
        },
        handleLaunchApp: function handleLaunchApp() {
            _api2.default.$instance.globalData.noteCommentLaunched = true;
            this.setData({
                noLaunchApp: true
            });
        },
        handleShowCommentInput: function handleShowCommentInput() {
            var _this = this;
            var noteId = this.data.noteId;
            _user2.default.ensureLogin().then(function() {
                // if (SystemUtil.isAndroid() && this.data.commentList.length > 0) {
                //   navigateTo('NoteCommentDetail', {
                //     id: noteId
                //   })
                //   return
                // }
                _this.setData({
                    commentid: "",
                    showCommentInput: true
                });
            });
        }
    }
});