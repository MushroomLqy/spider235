var _regenerator = require("./../../../../../karin_npm/babel-runtime/regenerator/index.js");

var _regenerator2 = _interopRequireDefault(_regenerator);

var _vuefy = require("../../../../../libs/vuefy.js");

var _track = require("../../../../../utils/track");

var _eventBus = require("../../../../../libs/event-bus");

var _eventBus2 = _interopRequireDefault(_eventBus);

var _mp = require("../../../../../libs/@xhs/protobuf-mp-chakra-tracker/mp.js");

var _user = require("../../../../../utils/user");

var _user2 = _interopRequireDefault(_user);

var _path = require("../../../../../utils/path");

var _note = require("../../../../../services/note");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

function _asyncToGenerator(fn) {
    return function() {
        var gen = fn.apply(this, arguments);
        return new Promise(function(resolve, reject) {
            function step(key, arg) {
                try {
                    var info = gen[key](arg);
                    var value = info.value;
                } catch (error) {
                    reject(error);
                    return;
                }
                if (info.done) {
                    resolve(value);
                } else {
                    return Promise.resolve(value).then(function(value) {
                        step("next", value);
                    }, function(err) {
                        step("throw", err);
                    });
                }
            }
            return step("next");
        });
    };
}

var LIKE_ICON_SRC = "./assets/like_white_fill.svg";

var UNLIKE_ICON_SRC = "./assets/like_white.svg";

var COMMENT_ICON_SRC = "./assets/comment_white.svg";

var COLLECT_ICON_SRC = "./assets/collect_white_fill.svg";

var UNCOLLECT_ICON_SRC = "./assets/collect_white.svg";

Component({
    properties: {
        note: Object,
        launchAppParameter: String,
        videoNoteId: String,
        canLaunchApp: Boolean,
        isLaunchError: Boolean,
        feedIndex: Number
    },
    data: {
        noteId: "",
        hasLiked: false,
        hasCollect: false,
        likeNum: 0,
        commentNum: 0,
        collectNum: 0
    },
    // 生命周期函数，可以为函数，或一个在methods段中定义的方法名
    ready: function ready() {
        (0, _vuefy.computed)(this, {
            likeIconSrc: function likeIconSrc() {
                return this.data.note && this.data.note.isLiked ? LIKE_ICON_SRC : UNLIKE_ICON_SRC;
            },
            likeNumText: function likeNumText() {
                return this.data.note && this.data.note.likes ? this.formatNum(this.data.note.likes) : "点赞";
            },
            commentIconSrc: function commentIconSrc() {
                return COMMENT_ICON_SRC;
            },
            commentNumText: function commentNumText() {
                return this.data.note && this.data.note.comments ? this.formatNum(this.data.note.comments) : "评论";
            },
            collectIconSrc: function collectIconSrc() {
                return this.data.note && this.data.note.isCollected ? COLLECT_ICON_SRC : UNCOLLECT_ICON_SRC;
            },
            collectNumText: function collectNumText() {
                return this.data.note && this.data.note.collects ? this.formatNum(this.data.note.collects) : "收藏";
            }
        });
    },
    methods: {
        handleTapLike: function handleTapLike() {
            var _this = this;
            return _asyncToGenerator(/* */ _regenerator2.default.mark(function _callee() {
                var note, id, isLiked, method;
                return _regenerator2.default.wrap(function _callee$(_context) {
                    while (1) {
                        switch (_context.prev = _context.next) {
                          case 0:
                            if (_user2.default.getUserId()) {
                                _context.next = 3;
                                break;
                            }
                            _eventBus2.default.emit("goToLogin", {
                                source: "note-like"
                            });
                            return _context.abrupt("return");

                          case 3:
                            note = _this.data.note || {};
                            id = note.id, isLiked = note.isLiked;
                            method = isLiked ? _note.dislikeNote : _note.likeNote;
                            (0, _track.trackNormalData)({
                                action: "immersion-like-tap",
                                label: "footer-action-bar",
                                property: id
                            });
                            _context.prev = 7;
                            _context.next = 10;
                            return method({
                                noteId: id
                            });

                          case 10:
                            (0, _track.trackNormalData)({
                                action: isLiked ? "immersion-like-decrease" : "immersion-like-increase",
                                label: "footer-action-bar",
                                property: id
                            });
                            _this.triggerEvent("actionChange", "like");
                            if (!isLiked) {
                                wx.$eaglet.push(_mp.tracker[2107]({
                                    objectPosition: _this.data.feedIndex + 1,
                                    noteId: id,
                                    trackId: "Null",
                                    noteType: "video_note",
                                    authorId: note.user.id
                                }));
                            }
                            _context.next = 17;
                            break;

                          case 15:
                            _context.prev = 15;
                            _context.t0 = _context["catch"](7);

                          case 17:
                          case "end":
                            return _context.stop();
                        }
                    }
                }, _callee, _this, [ [ 7, 15 ] ]);
            }))();
        },
        handleTapCollect: function handleTapCollect() {
            var _this2 = this;
            return _asyncToGenerator(/* */ _regenerator2.default.mark(function _callee2() {
                var _data, note, feedIndex, id, isCollected, method;
                return _regenerator2.default.wrap(function _callee2$(_context2) {
                    while (1) {
                        switch (_context2.prev = _context2.next) {
                          case 0:
                            _data = _this2.data, note = _data.note, feedIndex = _data.feedIndex;
                            id = note.id, isCollected = note.isCollected;
                            method = isCollected ? _note.deleteCollectNote : _note.collectNote;
                            if (_user2.default.getUserId()) {
                                _context2.next = 6;
                                break;
                            }
                            _eventBus2.default.emit("goToLogin", {
                                source: "note-collect"
                            });
                            return _context2.abrupt("return");

                          case 6:
                            _context2.prev = 6;
                            _context2.next = 9;
                            return method({
                                noteId: id
                            });

                          case 9:
                            _this2.triggerEvent("actionChange", "collect");
                            if (!isCollected) {
                                if (feedIndex === 0) {
                                    wx.$eaglet.push(_mp.tracker[2112]({
                                        objectPosition: _this2.data.feedIndex + 1,
                                        noteId: id,
                                        noteType: "video_note",
                                        authorId: note.user.id
                                    }));
                                } else {
                                    wx.$eaglet.push(_mp.tracker[2113]({
                                        adsTarget_trackId: "None",
                                        // eslint-disable-line
                                        noteTarget_trackId: "None",
                                        // eslint-disable-line
                                        objectPosition: _this2.data.feedIndex + 1,
                                        noteId: id,
                                        noteType: "video_note",
                                        authorId: note.user.id
                                    }));
                                }
                            }
                            _context2.next = 15;
                            break;

                          case 13:
                            _context2.prev = 13;
                            _context2.t0 = _context2["catch"](6);

                          case 15:
                          case "end":
                            return _context2.stop();
                        }
                    }
                }, _callee2, _this2, [ [ 6, 13 ] ]);
            }))();
        },
        handleTapAuthor: function handleTapAuthor(e) {
            var id = e.currentTarget.dataset.id;
            (0, _track.trackNormalData)({
                action: "immersion-author-tap",
                label: "author-avatar",
                property: id
            });
            _user2.default.ensureLogin().then(function() {
                (0, _path.navigateTo)("AuthorPage", {
                    author_id: id
                });
            });
        },
        handleShowComment: function handleShowComment() {
            if (!_user2.default.getUserId()) {
                _eventBus2.default.emit("goToLogin", {
                    source: "note-comments"
                });
                return;
            }
            var _data2 = this.data, feedIndex = _data2.feedIndex, note = _data2.note;
            var id = note.id, comments = note.comments;
            if (feedIndex === 0) {
                wx.$eaglet.push(_mp.tracker[2161]({
                    objectPosition: this.data.feedIndex + 1,
                    noteId: id,
                    noteType: "video_note",
                    authorId: note.user.id
                }));
            } else {
                wx.$eaglet.push(_mp.tracker[2163]({
                    adsTarget_trackId: "None",
                    // eslint-disable-line
                    noteTarget_trackId: "None",
                    // eslint-disable-line
                    objectPosition: this.data.feedIndex + 1,
                    noteId: id,
                    noteType: "video_note",
                    authorId: note.user.id
                }));
            }
            (0, _track.trackNormalData)({
                action: "immersion-comment-tap",
                label: "footer-action-bar",
                property: id
            });
            if (comments) {
                this.triggerEvent("showComment", id);
            }
        },
        // 内部函数
        formatNum: function formatNum() {
            var num = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
            if (num >= 1e4) {
                num = Math.round((num / 1e4).toFixed(1) * 10) / 10;
                return num + "万";
            }
            return num;
        }
    }
});