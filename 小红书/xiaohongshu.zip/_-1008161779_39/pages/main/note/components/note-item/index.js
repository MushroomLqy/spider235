var _appuser = require("../../../../../services/appuser");

var _note = require("../../../../../services/note");

var _path = require("../../../../../utils/path");

var _track = require("../../../../../utils/track");

var _user = require("../../../../../utils/user");

var _user2 = _interopRequireDefault(_user);

var _vuefy = require("../../../../../libs/vuefy.js");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

function _toConsumableArray(arr) {
    if (Array.isArray(arr)) {
        for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) {
            arr2[i] = arr[i];
        }
        return arr2;
    } else {
        return Array.from(arr);
    }
}

Component({
    behaviors: [],
    properties: {
        renderNoteListData: Array,
        user: Object,
        poi: Object,
        note: Object,
        commentList: Array,
        imageTags: Array,
        swiperHeight: Number,
        isExpand: Boolean,
        isFirst: Boolean,
        isShowPinchTip: Boolean,
        isShowBanner: Boolean,
        index: String,
        coverImgUrl: String,
        startLoadTime: Number,
        noteItemHeight: {
            type: Number,
            observer: function observer(newVal, oldVal) {
                if (oldVal > 0 && newVal !== oldVal) {
                    this.setData({
                        isSettingHeight: false
                    });
                }
            }
        },
        expandButtonStyle: {
            type: Number,
            value: 0
        },
        shareButtonStyle: {
            type: Number,
            value: 0
        }
    },
    data: {
        isFollowed: null,
        isSettingHeight: false,
        subComment: [],
        commentsTotal: 0,
        isAddComment: false,
        videoList: [],
        current: 1,
        showFollowModal: false,
        opacity: 1
    },
    // 生命周期函数，可以为函数，或一个在methods段中定义的方法名
    attached: function attached() {// console.log('------------note-item-attached', Date.now())
    },
    moved: function moved() {// console.log('------------note-item-moved', Date.now())
    },
    detached: function detached() {// console.log('------------note-item-detached', Date.now())
    },
    ready: function ready() {
        (0, _vuefy.computed)(this, {
            isShowLocation: function isShowLocation() {
                return Object.keys(this.data.poi).length !== 0;
            },
            totalImgCount: function totalImgCount() {
                var note = this.data.note;
                return Number(note.imageList.length);
            },
            showFirstImage: function showFirstImage() {
                var _data = this.data, index = _data.index, note = _data.note;
                if (note.type && note.type === "normal") {
                    return index === "0";
                } else {
                    return false;
                }
            },
            isIllegal: function isIllegal() {
                var note = this.data.note;
                return note.illegalInfo || false;
            }
        });
        var _data2 = this.data, user = _data2.user, note = _data2.note, commentList = _data2.commentList, renderNoteListData = _data2.renderNoteListData;
        var videoList = [];
        var _data3 = this.data, startLoadTime = _data3.startLoadTime, index = _data3.index;
        if (index === "0" && note.type === "video") {
            var itemReadyTime = Date.now();
            var videoFMP = itemReadyTime - startLoadTime;
            (0, _track.trackNormalData)({
                action: "videoFMP",
                property: videoFMP
            });
        }
        renderNoteListData.forEach(function(element) {
            if (element.noteList[0].type === "video") {
                videoList.push(element.noteList[0].video.id);
            }
        });
        this.triggerEvent("ready");
        this.setData({
            subComment: commentList,
            commentsTotal: note.commentsCount,
            videoList: videoList
        });
        if (user && user.hasOwnProperty("followed")) {
            this.setData({
                isFollowed: user.followed
            });
        }
    },
    // 组件所在页面的生命周期函数
    show: function show() {// onshow
    },
    methods: {
        handleTriggerExpand: function handleTriggerExpand(e) {
            var canExpand = e.detail.canExpand;
            this.setData({
                isSettingHeight: true
            });
            this.triggerEvent("triggerexpand", {
                canExpand: canExpand
            });
        },
        handleTriggleFollow: function handleTriggleFollow() {
            var _data4 = this.data, isFollowed = _data4.isFollowed, user = _data4.user;
            if (!isFollowed) {
                this._followAppUser(user);
                // eslint-disable-line no-underscore-dangle
                        } else {
                this.setData({
                    showFollowModal: true
                });
            }
        },
        handleTapAvatar: function handleTapAvatar(e) {
            var id = e.currentTarget.dataset.id;
            (0, _track.trackNormalData)({
                action: "avatar-tap",
                label: "author-avatar",
                property: id
            });
            _user2.default.ensureLogin().then(function() {
                (0, _path.navigateTo)("AuthorPage", {
                    author_id: id
                });
            });
        },
        handleCreateComment: function handleCreateComment(e) {
            if (e.detail && e.detail.noteId) {
                this._fetchNoteSummaryComment({
                    // eslint-disable-line no-underscore-dangle
                    id: e.detail.noteId
                });
            }
        },
        handleShareIcon: function handleShareIcon(index) {
            this.selectComponent("#note-action-bar-" + index).handleTapShare();
        },
        handleTapPoi: function handleTapPoi() {
            var poi = this.data.poi;
            if (poi.link) {
                (0, _path.navigateTo)("Webview", {
                    link: poi.link
                });
            }
        },
        handleNoteImageSwitched: function handleNoteImageSwitched(e) {
            var current = e.detail.current;
            this.setData({
                current: current
            });
        },
        handleBackhome: function handleBackhome() {
            var note = this.data.note;
            if (note.type === "video" && this && this.selectComponent && this.selectComponent("#note")) {
                this.selectComponent("#note").handleBackhome();
            }
        },
        handleHasReaded: function handleHasReaded() {
            if (this.selectComponent("#pinch-tip")) {
                this.selectComponent("#pinch-tip").handleHasReaded();
            }
        },
        handleFirstImageSwitched: function handleFirstImageSwitched() {
            this.triggerEvent("firstImageLoaded");
            this.setData({
                opacity: 0
            });
        },
        handleBannerTap: function handleBannerTap() {
            (0, _track.trackNormalData)({
                action: "click_welfare_activity_from_new_notedetail"
            });
            (0, _path.navigateTo)("Webview", {
                link: encodeURIComponent("https://pages.xiaohongshu.com/event/page/sale/5cb4293493bdfc70d2a208c9")
            });
        },
        // 内部函数
        _followAppUser: function _followAppUser(user) {
            var _this = this;
            (0, _appuser.followUser)({
                userId: user.id
            }).then(function() {
                (0, _track.trackNormalData)({
                    action: "follow-tap",
                    label: "follow-button",
                    property: user.id
                });
                _this.setData({
                    isFollowed: true
                });
            });
        },
        _unfollowAppUser: function _unfollowAppUser(e) {
            var _this2 = this;
            var user = e.detail.user;
            (0, _appuser.unfollowUser)({
                userId: user.id
            }).then(function() {
                (0, _track.trackNormalData)({
                    action: "unfollow-tap",
                    label: "unfollow-button",
                    property: user.id
                });
                _this2.setData({
                    isFollowed: false
                });
            });
        },
        _fetchNoteSummaryComment: function _fetchNoteSummaryComment(_ref) {
            var _this3 = this;
            var id = _ref.id;
            var subComment = this.data.subComment;
            (0, _note.getNoteCommentDetail)({
                noteId: id,
                pageSize: 1
            }).then(function(res) {
                var comments = res.comments.map(function(comment) {
                    comment.user.name = comment.user.nickname;
                    return comment;
                });
                var newSubComment = [].concat(_toConsumableArray(subComment));
                newSubComment.splice(0, 1, comments[0]);
                _this3.setData({
                    subComment: newSubComment,
                    commentsTotal: res.total,
                    isAddComment: true
                });
            });
        }
    }
});