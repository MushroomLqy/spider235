var _regenerator = require("./../../../../../karin_npm/babel-runtime/regenerator/index.js");

var _regenerator2 = _interopRequireDefault(_regenerator);

var _video = require("../../utils/video");

var _video2 = _interopRequireDefault(_video);

var _system = require("../../../../../utils/system");

var _system2 = _interopRequireDefault(_system);

var _vuefy = require("../../../../../libs/vuefy.js");

var _eventBus = require("../../../../../libs/event-bus");

var _eventBus2 = _interopRequireDefault(_eventBus);

var _track = require("../../../../../utils/track");

var _abTest = require("../../../../../utils/ab-test");

var _abTest2 = _interopRequireDefault(_abTest);

var _api = require("../../../../../utils/api");

var _api2 = _interopRequireDefault(_api);

var _path = require("../../../../../utils/path");

var _routes = require("../../../../../routes");

var _deeplink = require("../../utils/deeplink");

var _customsMessage = require("../../utils/customsMessage");

var _tracker = require("../../../../../services/tracker");

var _author = require("../../../../../services/author");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

function _asyncToGenerator(fn) {
    return function() {
        var gen = fn.apply(this, arguments);
        return new Promise(function(resolve, reject) {
            function step(key, arg) {
                try {
                    var info = gen[key](arg);
                    var value = info.value;
                } catch (error) {
                    reject(error);
                    return;
                }
                if (info.done) {
                    resolve(value);
                } else {
                    return Promise.resolve(value).then(function(value) {
                        step("next", value);
                    }, function(err) {
                        step("throw", err);
                    });
                }
            }
            return step("next");
        });
    };
}

var launchOps = _api2.default.$instance.globalData.launchOps;

var videoUtil = new _video2.default();

Component({
    behaviors: [],
    properties: {
        // images: {
        //   type: Object,
        //   value: {},
        //   observer: function(newVal) {
        //     this.setData({
        //       videoHeight: 2 * CurrentSystemInfo.windowWidth * newVal[0].height / newVal[0].width
        //     })
        //   }
        // },
        images: Object,
        video: {
            type: Object,
            value: {}
        },
        videoScale: Number,
        videoHeight: Number,
        noteId: String,
        authorId: String,
        shareImage: String,
        shareTitle: String,
        shareDesc: String,
        shareType: String,
        index: String,
        videoList: Array,
        isFirst: Boolean,
        relatedNotes: Array,
        isShowNewCallbackStyle: {
            type: Boolean,
            value: false
        },
        launchAppParameter: String,
        refluxType: {
            type: Number,
            value: 0
        },
        authorOtherNote: null
    },
    data: {
        // videoHeight: 0,
        videoIsPlaying: false,
        videoIsAlready: false,
        videoIsStoped: false,
        isShowShareBox: false,
        showVideoMpModal: false,
        isShowFullRelatedCard: false,
        showControls: false,
        showOtherControls: true,
        isAutoplay: false,
        isLoop: false,
        isMuted: false,
        showFullscreenBtn: true,
        showCenterPlayBtn: false,
        showProgress: true,
        isFullScreen: false,
        isIphoneX: false,
        videoTimeout: null,
        showHdButton: false,
        otherNoteLaunchAppParameter: "",
        canLaunchApp: false,
        otherNoteCustomMessageCardInfo: {
            title: "",
            img: "https://ci.xiaohongshu.com/6bf7dfed-29a0-404d-8939-5f1e77a6b9c2"
        },
        otherNoteCustomMessageReplyInfo: {}
    },
    // 生命周期函数，可以为函数，或一个在methods段中定义的方法名
    attached: function attached() {},
    // 在组件实例被移动到节点树另一个位置时执行
    moved: function moved() {
        var self = this;
        videoUtil.destroyAll({
            onDestroyAllCallBack: function onDestroyAllCallBack() {
                self.setData({
                    videoIsPlaying: false,
                    videoIsAlready: false
                });
            }
        });
    },
    detached: function detached() {},
    ready: function ready() {
        this.setData({
            canLaunchApp: _api2.default.$instance.globalData.canLaunchApp,
            isIphoneX: _api2.default.$instance.globalData.isIPhoneX
        });
        this.setData({
            objectFit: "cover"
        });
        (0, _vuefy.computed)(this, {
            objectFit: function objectFit() {
                var _data$video = this.data.video, video = _data$video === undefined ? {} : _data$video;
                if (video.width && video.height && video.width / video.height < 1) {
                    return "cover";
                }
                return "contain";
            },
            openType: function openType() {
                var openType = _api2.default.$instance.globalData.canLaunchApp ? "launchApp" : "contact";
                return openType;
            },
            isIOS: function isIOS() {
                var isIOS = !_system2.default.isAndroid();
                return isIOS;
            },
            isShowFullRelatedCard: function isShowFullRelatedCard() {
                var _ref = this.data || {}, isShowNewCallbackStyle = _ref.isShowNewCallbackStyle, isFullScreen = _ref.isFullScreen, videoIsPlaying = _ref.videoIsPlaying;
                return isShowNewCallbackStyle && isFullScreen && !videoIsPlaying;
            }
        });
        var self = this;
        videoUtil.destroy({
            videoIds: this.data.videoList,
            onDestroyCallBack: function onDestroyCallBack() {
                self.setData({
                    videoIsPlaying: false,
                    videoIsAlready: false
                });
            }
        });
        // wifi视频自动播放
                wx.getNetworkType({
            success: function success(status) {
                if (status && status.networkType === "wifi") {
                    // self.setData({
                    //   isAutoplay: true,
                    // })
                    videoUtil.start({
                        videoId: self.data.video.id,
                        self: self
                    });
                }
            }
        });
    },
    pageLifetimes: {
        // 组件所在页面的生命周期函数
        show: function show() {
            this.setData({
                showVideoMpModal: false
            });
        },
        hide: function hide() {
            var self = this;
            self.setData({
                videoIsPlaying: false,
                videoIsAlready: false,
                isFullScreen: false,
                showVideoMpModal: false
            });
            clearTimeout(this.videoTimeout);
        }
    },
    methods: {
        getUserOtherNote: function getUserOtherNote() {
            var _this = this;
            return _asyncToGenerator(/* */ _regenerator2.default.mark(function _callee() {
                return _regenerator2.default.wrap(function _callee$(_context) {
                    while (1) {
                        switch (_context.prev = _context.next) {
                          case 0:
                            _context.next = 2;
                            return _api2.default.$instance.globalData.promise;

                          case 2:
                            if (!(_abTest2.default.getABTestFlagValue("wx_mp_show_other_note") !== 1)) {
                                _context.next = 4;
                                break;
                            }
                            return _context.abrupt("return");

                          case 4:
                            (0, _author.getUserOtherNotes)({
                                filterNoteIds: _this.data.noteId,
                                userId: _this.data.authorId
                            }).then(function(notes) {
                                if (notes && notes.length > 0) {
                                    // 显示该作者其他笔记曝光打点
                                    (0, _track.trackNormalData)({
                                        action: "impression_author_other_note",
                                        property: _this.data.noteId
                                    });
                                    var noteData = notes[0];
                                    var getNum = function getNum(num) {
                                        if (num >= 1e4) {
                                            return (num / 1e4).toFixed(2) + "万";
                                        }
                                        if (num >= 1e8) {
                                            return (num / 1e8).toFixed(2) + "亿";
                                        }
                                        return num;
                                    };
                                    noteData.readCountStr = noteData.type === "video" ? getNum(noteData.readCount) + "次播放" : getNum(noteData.readCount) + "次阅读";
                                    noteData.btnText = noteData.type === "video" ? "立即播放" : "立即查看";
                                    noteData.title = noteData.title || noteData.user.nickname + "的笔记";
                                    var otherNoteLaunchAppParameter = (0, _deeplink.getNoteDeepLink)(noteData.id, noteData.type);
                                    _this.setData({
                                        otherNoteLaunchAppParameter: otherNoteLaunchAppParameter,
                                        otherNoteCustomMessageCardInfo: {
                                            title: noteData.title,
                                            desc: noteData.title.substr(0, 30),
                                            img: noteData.cover.url
                                        },
                                        otherNoteCustomMessageReplyInfo: {
                                            sessionFrom: JSON.stringify({
                                                title: "点我，查看这篇笔记吧！",
                                                url: (0, _customsMessage.getAbsoluteWebviewUrl)("https://www.xiaohongshu.com/discovery/item/" + noteData.id),
                                                thumbUrl: noteData.cover.url,
                                                description: noteData.title,
                                                deeplink: otherNoteLaunchAppParameter || ""
                                            })
                                        },
                                        authorOtherNote: noteData
                                    });
                                }
                            });

                          case 5:
                          case "end":
                            return _context.stop();
                        }
                    }
                }, _callee, _this);
            }))();
        },
        handleNoteDetail: function handleNoteDetail(e) {
            var noteId = e.currentTarget.dataset.noteId;
            (0, _track.trackNormalData)({
                action: "author_other_note",
                property: noteId
            });
            (0, _path.navigateTo)("NoteDetail", {
                id: noteId
            });
        },
        handleTimeupdate: function handleTimeupdate(e) {
            var _ref2 = e || {}, _ref2$detail = _ref2.detail, detail = _ref2$detail === undefined ? {} : _ref2$detail;
            var currentTime = detail.currentTime, duration = detail.duration;
            var showHdButton = false;
            if (currentTime && duration) {
                if (duration > 15 && currentTime >= 10) {
                    showHdButton = true;
                } else if (duration > 5 && duration <= 15 && currentTime >= duration - 5) {
                    showHdButton = true;
                }
                if (showHdButton && !this.data.showHdButton) {
                    // 分享态不支持
                    if (!_api2.default.$instance.globalData.canLaunchApp) {
                        return;
                    }
                    if (_abTest2.default.getABTestFlagValue("wx_mp_show_hb_ntn") !== 1) {
                        return;
                    }
                    this.triggerEvent("triggerShowHdButton");
                    this.setData({
                        showHdButton: showHdButton
                    });
                }
            }
        },
        // video play后不能立即pause 否则会报错：The play() request was interrupted by a call to pause().
        onTimeout: function onTimeout(videoId) {
            var _this2 = this;
            this.videoTimeout = setTimeout(function() {
                _this2.setData({
                    videoIsStoped: videoUtil.getIsStoped({
                        videoId: videoId
                    })
                });
            }, 50);
        },
        handlePlayIcon: function handlePlayIcon(e) {
            var videoId = e.currentTarget.dataset.id;
            videoUtil.start({
                videoId: videoId,
                self: this
            });
            this.setData({
                videoIsPlaying: videoUtil.getIsPlaying({
                    videoId: videoId
                }),
                videoIsStoped: videoUtil.getIsStoped({
                    videoId: videoId
                }),
                videoIsAlready: true,
                isShowShareBox: false,
                isFullScreen: false
            });
        },
        handleCoverPlayIcon: function handleCoverPlayIcon(e) {
            var videoId = e.currentTarget.dataset.id;
            var videoIsPlaying = this.data.videoIsPlaying;
            if (!videoIsPlaying) {
                videoUtil.start({
                    videoId: videoId,
                    self: this
                });
            }
            this.setData({
                videoIsPlaying: videoUtil.getIsPlaying({
                    videoId: videoId
                }),
                videoIsStoped: videoUtil.getIsStoped({
                    videoId: videoId
                }),
                showVideoMpModal: false
            });
        },
        handleVideo: function handleVideo(e) {
            var videoId = e.currentTarget.dataset.id;
            var _data = this.data, videoIsPlaying = _data.videoIsPlaying, isShowShareBox = _data.isShowShareBox;
            if (videoIsPlaying) {
                (0, _track.trackNormalData)({
                    action: "video-pause",
                    property: videoId
                });
                videoUtil.pause({
                    videoId: videoId
                });
            } else if (!isShowShareBox) {
                videoUtil.start({
                    videoId: videoId,
                    self: this
                });
            }
            videoIsPlaying = videoUtil.getIsPlaying({
                videoId: videoId
            });
            this.setData({
                videoIsPlaying: videoIsPlaying,
                videoIsStoped: videoUtil.getIsStoped({
                    videoId: videoId
                })
            });
        },
        handleVideoEnded: function handleVideoEnded(e) {
            var _this3 = this;
            return _asyncToGenerator(/* */ _regenerator2.default.mark(function _callee2() {
                var videoId, videoIsPlaying;
                return _regenerator2.default.wrap(function _callee2$(_context2) {
                    while (1) {
                        switch (_context2.prev = _context2.next) {
                          case 0:
                            videoId = e.currentTarget.dataset.id;
                            videoIsPlaying = _this3.data.videoIsPlaying;
                            _context2.next = 4;
                            return _this3.getUserOtherNote();

                          case 4:
                            videoUtil.ended({
                                videoId: videoId
                            });
                            videoIsPlaying = videoUtil.getIsPlaying({
                                videoId: videoId
                            });
                            _this3.setData({
                                isShowShareBox: true,
                                videoIsPlaying: videoIsPlaying
                            });
                            // video-packet
                                                        _eventBus2.default.emit("videoEnded", _this3.data.noteId);
                            (0, _track.trackNormalData)({
                                action: "video_ended",
                                property: videoId
                            });

                          case 9:
                          case "end":
                            return _context2.stop();
                        }
                    }
                }, _callee2, _this3);
            }))();
        },
        handleNoteItemPause: function handleNoteItemPause(e) {
            var videoId = e.currentTarget.dataset.id;
            videoUtil.setIsPlaying({
                videoId: videoId,
                value: false
            });
            this.setData({
                videoIsAlready: true,
                videoIsPlaying: false,
                videoIsStoped: videoUtil.getIsStoped({
                    videoId: videoId
                })
            });
        },
        handlePlay: function handlePlay(e) {
            var self = this;
            if (e && e.currentTarget && e.currentTarget.dataset && e.currentTarget.dataset.id) {
                var videoId = e.currentTarget.dataset.id;
                videoUtil.setIsPlaying({
                    videoId: videoId,
                    value: true
                });
                this.setData({
                    videoIsPlaying: videoUtil.getIsPlaying({
                        videoId: self.data.video.id
                    }),
                    videoIsAlready: true,
                    isShowShareBox: false
                });
                (0, _track.trackNormalData)({
                    action: "video-play",
                    property: videoId
                });
                this.onTimeout(videoId);
            }
        },
        handleReplay: function handleReplay(e) {
            var videoId = e.currentTarget.dataset.id;
            (0, _track.trackNormalData)({
                action: "video_replay",
                property: videoId
            });
            videoUtil.setIsPlaying({
                videoId: videoId,
                value: true
            });
            videoUtil.replay({
                videoId: videoId
            });
            this.setData({
                isShowShareBox: false,
                videoIsPlaying: videoUtil.getIsPlaying({
                    videoId: videoId
                }),
                videoIsStoped: videoUtil.getIsStoped({
                    videoId: videoId
                })
            });
        },
        handleRequestFullScreen: function handleRequestFullScreen(e) {
            var videoId = e.currentTarget.dataset.id;
            (0, _track.trackNormalData)({
                action: "video_full_screen",
                property: videoId
            });
            videoUtil.requestFullScreen({
                videoId: videoId
            });
        },
        handleFullScreenChange: function handleFullScreenChange(e) {
            if (e.detail && typeof e.detail.fullScreen === "boolean") {
                this.setData({
                    isFullScreen: e.detail.fullScreen
                });
            }
        },
        handleExitFullScreen: function handleExitFullScreen(e) {
            var videoId = e.currentTarget.dataset.id;
            videoUtil.exitFullScreen({
                videoId: videoId
            });
        },
        handleOffSound: function handleOffSound() {
            (0, _track.trackNormalData)({
                action: "video_off_sound"
            });
            this.setData({
                isMuted: true
            });
        },
        handleOnSound: function handleOnSound() {
            this.setData({
                isMuted: false
            });
        },
        handleBackhome: function handleBackhome() {
            var self = this;
            videoUtil.destroyAll({
                onDestroyAllCallBack: function onDestroyAllCallBack() {
                    self.setData({
                        videoIsPlaying: false,
                        videoIsAlready: false
                    });
                }
            });
        },
        handleTapLaunchApp: function handleTapLaunchApp(e) {
            var _getPageUrl = (0, _path.getPageUrl)(), route = _getPageUrl.route;
            var category = (0, _routes.getCategory)(route);
            var type = e.currentTarget.dataset.type;
            (0, _tracker.launchAppTrack)({
                category: category,
                url: route + "?id=" + this.properties.noteId + "&scene=" + launchOps.scene,
                label: type
            });
        },
        handleLaunchAppError: function handleLaunchAppError(e) {
            var _getPageUrl2 = (0, _path.getPageUrl)(), route = _getPageUrl2.route;
            var category = (0, _routes.getCategory)(route);
            var type = e.currentTarget.dataset.type;
            (0, _tracker.launchAppTrack)({
                category: category,
                url: route + "?id=" + this.properties.noteId + "&scene=" + launchOps.scene,
                label: type
            });
            // 视频相关打开mp-modal，需使用video标签内的mp-modal，否则安卓会有层级问题
                        if (type === "video_callback_box" || type === "video_callback_banner") {
                this.setData({
                    showVideoMpModal: true
                });
            } else {
                _eventBus2.default.emit("showMpModal");
            }
        },
        handleExitFullRelatedCard: function handleExitFullRelatedCard() {
            this.setData({
                isShowFullRelatedCard: false
            });
        },
        handleTapMaskRelatedCard: function handleTapMaskRelatedCard() {
            return;
        },
        handleCloseMpModal: function handleCloseMpModal() {
            this.setData({
                showVideoMpModal: false
            });
        }
    }
});