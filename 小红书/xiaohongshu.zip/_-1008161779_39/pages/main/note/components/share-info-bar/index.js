var _regenerator = require("./../../../../../karin_npm/babel-runtime/regenerator/index.js");

var _regenerator2 = _interopRequireDefault(_regenerator);

var _extends = Object.assign || function(target) {
    for (var i = 1; i < arguments.length; i++) {
        var source = arguments[i];
        for (var key in source) {
            if (Object.prototype.hasOwnProperty.call(source, key)) {
                target[key] = source[key];
            }
        }
    }
    return target;
};

var _vuefy = require("../../../../../libs/vuefy.js");

var _author = require("../../../../../services/author");

var _user = require("../../../../../utils/user");

var _user2 = _interopRequireDefault(_user);

var _path = require("../../../../../utils/path");

var _track = require("../../../../../utils/track");

var _api = require("../../../../../utils/api");

var _api2 = _interopRequireDefault(_api);

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

function _asyncToGenerator(fn) {
    return function() {
        var gen = fn.apply(this, arguments);
        return new Promise(function(resolve, reject) {
            function step(key, arg) {
                try {
                    var info = gen[key](arg);
                    var value = info.value;
                } catch (error) {
                    reject(error);
                    return;
                }
                if (info.done) {
                    resolve(value);
                } else {
                    return Promise.resolve(value).then(function(value) {
                        step("next", value);
                    }, function(err) {
                        step("throw", err);
                    });
                }
            }
            return step("next");
        });
    };
}

function getUserDeepLink() {
    var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var id = options.id;
    var _ref = _user2.default.getUserInfo() || {}, openid = _ref.openid;
    return "xhsdiscover://user/" + id + "?sourceId=miniprogram&openid=" + openid;
}

Component({
    behaviors: [],
    properties: {
        launchAppParameter: String,
        shareUserId: String,
        navigationBarTrueHeight: Number,
        customMessageReplyInfo: Object,
        customMessageCardInfo: {
            type: Object,
            default: {}
        }
    },
    data: {},
    // 生命周期函数，可以为函数，或一个在methods段中定义的方法名
    attached: function attached() {},
    moved: function moved() {},
    detached: function detached() {},
    ready: function() {
        var _ref2 = _asyncToGenerator(/* */ _regenerator2.default.mark(function _callee() {
            var shareUserId, userInfo, _ref3, image, nickname, redOfficialVerified, shareUserInfo;
            return _regenerator2.default.wrap(function _callee$(_context) {
                while (1) {
                    switch (_context.prev = _context.next) {
                      case 0:
                        (0, _vuefy.computed)(this, {
                            showLaunchAppBtn: function showLaunchAppBtn() {
                                return _api2.default.$instance.globalData.canLaunchApp;
                            },
                            launchAppUserParameter: function launchAppUserParameter() {
                                var shareUserId = this.properties.shareUserId;
                                return getUserDeepLink({
                                    id: shareUserId
                                });
                            },
                            userCustomMessageReplyInfo: function userCustomMessageReplyInfo() {
                                var shareUserId = this.properties.shareUserId;
                                return {
                                    sessionFrom: JSON.stringify({
                                        title: "点我，查看精彩内容！",
                                        deeplink: getUserDeepLink({
                                            id: shareUserId
                                        })
                                    })
                                };
                            }
                        });
                        (0, _track.trackNormalData)({
                            action: "impression-note-share-bar"
                        });
                        shareUserId = this.properties.shareUserId;
                        userInfo = {};
                        _context.prev = 4;
                        _context.next = 7;
                        return (0, _author.getUserInfo)({
                            userId: shareUserId
                        });

                      case 7:
                        userInfo = _context.sent;
                        _context.next = 12;
                        break;

                      case 10:
                        _context.prev = 10;
                        _context.t0 = _context["catch"](4);

                      case 12:
                        // eslint-disable-line
                        _ref3 = userInfo || {}, image = _ref3.image, nickname = _ref3.nickname, redOfficialVerified = _ref3.redOfficialVerified;
                        if (image && nickname) {
                            shareUserInfo = {
                                image: image,
                                nickname: nickname,
                                redOfficialVerified: redOfficialVerified
                            };
                            this.setData(_extends({}, shareUserInfo));
                        }

                      case 14:
                      case "end":
                        return _context.stop();
                    }
                }
            }, _callee, this, [ [ 4, 10 ] ]);
        }));
        function ready() {
            return _ref2.apply(this, arguments);
        }
        return ready;
    }(),
    methods: {
        handleUserProfile: function handleUserProfile() {
            (0, _path.navigateTo)("AuthorPage", {
                id: this.data.shareUserId
            });
        }
    }
});