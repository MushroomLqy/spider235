var _icons = require("../../../../../utils/icons");

var _icons2 = _interopRequireDefault(_icons);

var _page = require("../../../../../utils/page");

var _track = require("../../../../../utils/track");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

Component({
    behaviors: [],
    properties: {
        addMyMp: Object
    },
    data: {
        closeIcon: "https://ci.xiaohongshu.com/" + _icons2.default.close,
        addToMyMpStyle: "content",
        statusHeight: (0, _page.getTrueStatusBarHeight)()
    },
    lifetimes: {
        // 生命周期函数，可以为函数，或一个在methods段中定义的方法名
        attached: function attached() {},
        moved: function moved() {},
        detached: function detached() {},
        ready: function ready() {}
    },
    pageLifetimes: {
        // 组件所在页面的生命周期函数
        show: function show() {}
    },
    methods: {
        handleCloseAddMyMp: function handleCloseAddMyMp() {
            (0, _track.trackClick)({
                label: "close_full_screen_pin_mini_program",
                context: {},
                timeStamp: new Date().getTime()
            });
            this.triggerEvent("closeFullAddMyMp");
        }
    }
});