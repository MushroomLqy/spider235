var _vuefy = require("../../../../../libs/vuefy.js");

var _path = require("../../../../../utils/path");

var _user = require("../../../../../utils/user");

var _user2 = _interopRequireDefault(_user);

var _discovery = require("../../../../../utils/discovery");

var _track = require("../../../../../utils/track");

var _eventBus = require("../../../../../libs/event-bus");

var _eventBus2 = _interopRequireDefault(_eventBus);

var _tracker = require("../../../../../services/tracker.js");

var _system = require("../../../../../utils/system");

var _system2 = _interopRequireDefault(_system);

var _version = require("../../../../../utils/version");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

/**
 * 拿到文本的字符长度，中文字算2个字符
 * 中文unicode范围 19968 - 40869
 * 数字unicode范围 48 - 57
 * 英文字母unicode范围 65 - 90 or 97 - 122
 */ function getUnExpandFormatedDesc(formatedDesc) {
    var maxLength = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 128;
    var rst = 0;
    var rstArray = [];
    var isOverLength = false;
    var textLineLength = 0;
    if (!Array.isArray(formatedDesc)) {
        return false;
    } else {
        formatedDesc.some(function(desc) {
            var newDesc = [];
            textLineLength++;
            desc.some(function(item) {
                var newItem = void 0;
                switch (item.type) {
                  case "text":
                    for (var i = 0; i < item.text.length; i++) {
                        var j = item.text.charCodeAt(i);
                        if (j >= 19968 && j <= 40869) {
                            rst += 2;
                        } else if (j >= 48 && j <= 57) {
                            rst += 1;
                        } else if (j >= 65 && j <= 90 || j >= 97 && j <= 122) {
                            rst += 1;
                        } else {
                            rst += 2;
                        }
                        if (textLineLength > 2) {
                            isOverLength = true;
                        } else if (rst > maxLength) {
                            isOverLength = true;
                            newItem = {
                                type: "text",
                                text: item.text.substring(0, i - 8).concat("...")
                            };
                            break;
                            //跳出循环
                                                }
                    }
                    break;

                  case "image":
                    rst += 2;
                    if (textLineLength > 2) {
                        isOverLength = true;
                    } else if (rst > maxLength) {
                        isOverLength = true;
                        newItem = {
                            type: "text",
                            text: "..."
                        };
                    }
                    break;

                  case "userTag":
                    // 话题需要增加4个字符 两个空格 一个 # 或者 @
                    for (var _i = 0; _i < item.text.length; _i++) {
                        var _j = item.text.charCodeAt(_i);
                        if (_j >= 19968 && _j <= 40869) {
                            rst += 2;
                        } else if (_j >= 48 && _j <= 57) {
                            rst += 1;
                        } else if (_j >= 65 && _j <= 90 || _j >= 97 && _j <= 122) {
                            rst += 1;
                        } else {
                            rst += 2;
                        }
                    }
                    rst += 4;
                    if (textLineLength > 2) {
                        isOverLength = true;
                    } else if (rst > maxLength) {
                        isOverLength = true;
                        newItem = {
                            type: "text",
                            text: "..."
                        };
                    }
                    break;

                  case "pageTag":
                    // 话题需要增加4个字符 两个空格 一个 # 或者 @
                    for (var _i2 = 0; _i2 < item.text.length; _i2++) {
                        var _j2 = item.text.charCodeAt(_i2);
                        if (_j2 >= 19968 && _j2 <= 40869) {
                            rst += 2;
                        } else if (_j2 >= 48 && _j2 <= 57) {
                            rst += 1;
                        } else if (_j2 >= 65 && _j2 <= 90 || _j2 >= 97 && _j2 <= 122) {
                            rst += 1;
                        } else {
                            rst += 2;
                        }
                    }
                    rst += 4;
                    if (textLineLength > 2) {
                        isOverLength = true;
                    } else if (rst > maxLength) {
                        isOverLength = true;
                        newItem = {
                            type: "text",
                            text: "..."
                        };
                    }
                    break;
                }
                if (!isOverLength) {
                    newDesc.push(item);
                } else {
                    newDesc.push(newItem);
                }
                return isOverLength;
            });
            if (!isOverLength) {
                rstArray.push(desc);
            } else {
                rstArray.push(newDesc);
            }
            return isOverLength;
        });
        return {
            canExpand: isOverLength,
            unExpandFormatedDesc: rstArray
        };
    }
}

Component({
    behaviors: [],
    properties: {
        formatedDesc: Array,
        expandButtonStyle: {
            type: Number,
            value: 0
        },
        launchAppParameter: String,
        expandType: {
            type: Number,
            value: 0
        },
        canLaunchApp: Boolean,
        customMessageReplyInfo: Object,
        customMessageCardInfo: Object,
        noteTags: Array
    },
    data: {
        unExpandFormatedDesc: [],
        canExpand: false,
        versionPase: false,
        isExpand: false
    },
    // 生命周期函数，可以为函数，或一个在methods段中定义的方法名
    attached: function attached() {},
    moved: function moved() {},
    detached: function detached() {},
    ready: function ready() {
        var _this = this;
        var verCompare = (0, _version.versionCompare)(_system2.default.getSystemInfo().version, "7.0.3", 2);
        this.setData({
            versionPase: verCompare === 1
        });
        _eventBus2.default.on("expandText", function() {
            (0, _track.trackNormalData)({
                action: "expand_note_desc"
            });
            _this.setData({
                isExpand: true
            });
        });
        (0, _vuefy.computed)(this, {});
        (0, _vuefy.watch)(this, {
            formatedDesc: function formatedDesc(newVal) {
                var _properties = this.properties, expandType = _properties.expandType, canLaunchApp = _properties.canLaunchApp;
                var versionPase = this.data.versionPase;
                if (expandType === 0 || !canLaunchApp || !versionPase) {
                    var _getUnExpandFormatedD = getUnExpandFormatedDesc(newVal), unExpandFormatedDesc = _getUnExpandFormatedD.unExpandFormatedDesc, canExpand = _getUnExpandFormatedD.canExpand;
                    this.setData({
                        unExpandFormatedDesc: unExpandFormatedDesc,
                        canExpand: canExpand
                    });
                } else {
                    var self = this;
                    this.createSelectorQuery().select(".note-tags-inner").boundingClientRect(function(res) {
                        // eslint-disable-line
                        // 如果大于300px 收起展示
                        if (res.height >= 300) {
                            self.setData({
                                canExpand: true
                            });
                        }
                    }).exec();
                }
            }
        });
    },
    methods: {
        handleNoteTag: function handleNoteTag(e) {
            var _e$currentTarget$data = e.currentTarget.dataset, link = _e$currentTarget$data.link, pageId = _e$currentTarget$data.pageId;
            (0, _track.trackNormalData)({
                action: "click_note_tag",
                property: pageId
            });
            (0, _path.navigateTo)("Webview", {
                link: link
            });
        },
        handleTriggerExpand: function handleTriggerExpand() {
            this.setData({
                isExpand: !this.data.isExpand
            });
        },
        handlePageTap: function handlePageTap(e) {
            var _e$target$dataset = e.target.dataset, type = _e$target$dataset.type, link = _e$target$dataset.link;
            if (type === "goods") {
                (0, _path.navigateTo)("Webview", {
                    link: "/goods/" + (0, _discovery.getGoodsId)(link)
                });
                return;
            }
            if (type === "vendor") {
                return;
            }
            (0, _path.navigateTo)("Webview", {
                link: link
            });
        },
        handleUserTap: function handleUserTap(e) {
            var itemId = e.target.dataset.itemId;
            _user2.default.ensureLogin().then(function() {
                (0, _path.navigateTo)("AuthorPage", {
                    id: itemId
                });
            });
        }
    }
});