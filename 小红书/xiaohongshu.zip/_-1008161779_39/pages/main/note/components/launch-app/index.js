var _tracker = require("../../../../../services/tracker");

var _system = require("../../../../../services/system");

var _track = require("../../../../../utils/track");

var _path = require("../../../../../utils/path");

var _api = require("../../../../../utils/api");

var _api2 = _interopRequireDefault(_api);

var _routes = require("../../../../../routes");

var _eventBus = require("../../../../../libs/event-bus");

var _eventBus2 = _interopRequireDefault(_eventBus);

var _vuefy = require("../../../../../libs/vuefy.js");

var _mp = require("../../../../../libs/@xhs/protobuf-mp-chakra-tracker/mp.js");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

var launchOps = _api2.default.$instance.globalData.launchOps;

Component({
    behaviors: [],
    properties: {
        launchAppParameter: String,
        show: Boolean,
        noteId: String,
        source: {
            type: String,
            value: ""
        },
        otherInfo: {
            type: String,
            value: ""
        },
        canLaunchApp: Boolean,
        noLaunchApp: Boolean,
        launchAppType: {
            type: String,
            value: "default"
        },
        customMessageReplyInfo: {
            type: Object,
            default: {}
        },
        customMessageCardInfo: {
            type: Object,
            default: {}
        },
        btnText: String,
        shareCode: Boolean
    },
    data: {
        stopPropagation: true,
        isIphoneX: _api2.default.$instance.globalData.isIPhoneX
    },
    ready: function ready() {
        (0, _vuefy.computed)(this, {
            openType: function openType() {
                var openType = _api2.default.$instance.globalData.canLaunchApp && !this.data.noLaunchApp ? "launchApp" : "";
                return openType;
            },
            newLaunchAppParameter: function newLaunchAppParameter() {
                var _properties = this.properties, launchAppParameter = _properties.launchAppParameter, source = _properties.source;
                if (source) {
                    return launchAppParameter + "&position=wxmp-" + source + "&mpid=mewtwo";
                }
                return launchAppParameter;
            }
        });
    },
    methods: {
        handleShareToken: function handleShareToken(noteId) {
            (0, _system.getShareCode)({
                id: noteId,
                type: "note"
            }).then(function(data) {
                wx.setClipboardData({
                    data: data
                });
                wx.showToast({
                    title: "链接已复制，快去小红书APP查看",
                    icon: "none"
                });
            });
        },
        handleTapContact: function handleTapContact() {
            var _ref = this.data || {}, source = _ref.source, otherInfo = _ref.otherInfo;
            (0, _track.trackNormalData)({
                action: "enter_contact",
                label: source,
                property: otherInfo
            });
        },
        handleOpenModal: function handleOpenModal() {
            (0, _track.trackClick)({
                label: "open_contact_modal",
                timeStamp: new Date().getTime()
            });
        },
        handleTapLaunchApp: function handleTapLaunchApp() {
            var _getPageUrl = (0, _path.getPageUrl)(), route = _getPageUrl.route;
            var category = (0, _routes.getCategory)(route);
            var _ref2 = this.data || {}, launchAppType = _ref2.launchAppType, _ref2$source = _ref2.source, source = _ref2$source === undefined ? "" : _ref2$source, otherInfo = _ref2.otherInfo, _ref2$launchAppParame = _ref2.launchAppParameter, launchAppParameter = _ref2$launchAppParame === undefined ? "" : _ref2$launchAppParame;
            // 判断能不能被唤起
                        if (!_api2.default.$instance.globalData.canLaunchApp || this.data.noLaunchApp) {
                this.triggerEvent("onLaunchAppFail");
                return;
            }
            this.triggerEvent("onLaunchApp");
            if (source) {
                (0, _track.trackNormalData)({
                    action: "launch_app",
                    label: source,
                    property: otherInfo
                });
            } else {
                (0, _tracker.launchAppTrack)({
                    category: category,
                    url: route + "?id=" + this.properties.noteId + "&scene=" + launchOps.scene,
                    label: launchAppType
                });
            }
            var objectPosition = "";
            if (otherInfo) {
                try {
                    var parseOtherInfo = JSON.parse(otherInfo);
                    if (parseOtherInfo.objectPosition !== undefined) {
                        objectPosition = parseOtherInfo.objectPosition;
                    }
                } catch (e) {}
                // eslint-disable-line
                        }
            wx.$eaglet.push(_mp.tracker[5623]({
                channelTabName: source.replace(/-/g, "_"),
                channelTabId: (0, _path.getIdFromDeeplink)(launchAppParameter),
                objectPosition: objectPosition
            }));
        },
        handleLaunchAppSuccess: function handleLaunchAppSuccess() {
            console.log("!!!!!!!handleLaunchAppSuccess", arguments);
            // eslint-disable-line
                        var _ref3 = this.data || {}, source = _ref3.source, otherInfo = _ref3.otherInfo;
            (0, _track.trackNormalData)({
                action: "launch_app_success",
                label: source,
                property: otherInfo
            });
            this.triggerEvent("onLaunchAppSuccess");
        },
        handleLaunchAppError: function handleLaunchAppError() {
            var _getPageUrl2 = (0, _path.getPageUrl)(), route = _getPageUrl2.route;
            var category = (0, _routes.getCategory)(route);
            var _ref4 = this.data || {}, launchAppType = _ref4.launchAppType, source = _ref4.source, otherInfo = _ref4.otherInfo, customMessageReplyInfo = _ref4.customMessageReplyInfo, customMessageCardInfo = _ref4.customMessageCardInfo, launchAppParameter = _ref4.launchAppParameter;
            this.triggerEvent("onLaunchAppFail");
            if (source) {
                (0, _track.trackNormalData)({
                    action: "launch_app_fail",
                    label: source,
                    property: otherInfo
                });
            } else {
                (0, _tracker.launchAppTrack)({
                    category: category,
                    url: route + "?id=" + this.properties.noteId + "&scene=" + launchOps.scene,
                    fail: true,
                    label: launchAppType
                });
                (0, _track.trackClick)({
                    label: "open_contact_modal",
                    timeStamp: new Date().getTime()
                });
            }
            this.triggerEvent("onLaunchAppError");
            if ([ "note-default", "note-share-user-other", "note-share-user-button", "note-hd-video" ].includes(this.data.source)) {
                _eventBus2.default.emit("showMpModal", {
                    customMessageReplyInfo: customMessageReplyInfo,
                    launchAppParameter: launchAppParameter,
                    customMessageCardInfo: customMessageCardInfo
                });
            }
        }
    }
});