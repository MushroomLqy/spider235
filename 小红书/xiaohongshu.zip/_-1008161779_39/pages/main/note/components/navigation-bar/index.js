var _path = require("../../../../../utils/path");

var _track = require("../../../../../utils/track");

var _api = require("../../../../../utils/api");

var _api2 = _interopRequireDefault(_api);

var _page = require("../../../../../utils/page");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

var systemInfo = wx.getSystemInfoSync();

var isAndroid = systemInfo.platform === "android";

var windowWidth = "750rpx";

var CurrentSystemInfo = _api2.default.$instance.globalData.systemInfo;

var rpx2px = function rpx2px(rpx) {
    return rpx * systemInfo.windowWidth / 750;
};

var px2rpx = function px2rpx(rpx) {
    return rpx * 750 / CurrentSystemInfo.windowWidth;
};

Component({
    behaviors: [],
    properties: {
        navigationBarConfig: {
            type: Object,
            observer: function observer(newVal, oldVal, changedPath) {
                console.log("@@@@@@newVal", newVal);
                if (oldVal != null) {
                    this.setNavigationBar(newVal);
                }
            }
        }
    },
    data: {
        title: "",
        isIphoneX: false,
        navigationBarTrueHeight: (0, _page.getTopSectionHeight)(),
        navigationBarStyles: "",
        navigationBarIconsNum: 0,
        canUseCustomNavigationBar: true,
        noShowNavigationBar: false,
        showBackIcon: false,
        showHomePageIcon: false,
        leftSideInnerStyle: "",
        type: ""
    },
    // 生命周期函数，可以为函数，或一个在methods段中定义的方法名
    ready: function ready() {
        this.data.isIphoneX = _api2.default.$instance.globalData.isIPhoneX;
        var pages = getCurrentPages();
        var navigationBarInfo = (0, _page.getNavigationBarInfo)();
        this.data.showBackIcon = pages.length > 1;
        if (this.data.showBackIcon) {
            this.data.navigationBarIconsNum += 1;
        }
        // 是否可以使用自定义导航条
                this.data.canUseCustomNavigationBar = navigationBarInfo.canCustom;
        // 是否隐藏导航条
                this.data.noShowNavigationBar = navigationBarInfo.noShow;
        var pageContentClass = "";
        if (this.canUseCustomNavigationBar && this.noShowNavigationBar) {
            this.data.navigationBarTrueHeight = 0;
        }
        this.data.pageContentClass = pageContentClass;
        this.data.pageContainerClass = " ready";
        var leftSideInnerHeight = rpx2px(64) - 2;
        var leftSideInnerMaxWidth = rpx2px(174) - 2;
        if (isAndroid) {
            leftSideInnerHeight -= 1;
            leftSideInnerMaxWidth -= 1;
        }
        leftSideInnerHeight += "px";
        leftSideInnerMaxWidth += "px";
        this.data.leftSideInnerStyle = "height: " + leftSideInnerHeight + ";max-width: " + leftSideInnerMaxWidth + ";";
        this.setNavigationBar(this.properties.navigationBarConfig);
    },
    moved: function moved() {},
    detached: function detached() {},
    // 组件所在页面的生命周期函数
    show: function show() {},
    methods: {
        handleGoLastPage: function handleGoLastPage() {
            this.triggerEvent("navigateBack");
            (0, _track.trackNormalData)({
                action: "navigate_back"
            });
            (0, _path.navigateBack)();
        },
        handleHomePage: function handleHomePage() {
            this.triggerEvent("switchHomePage");
            (0, _track.trackNormalData)({
                action: "navigate_home_page"
            });
            (0, _path.switchTab)("HomePage");
        },
        setAllData: function setAllData() {
            this.setData({
                title: this.data.title,
                isIphoneX: this.data.isIphoneX,
                navigationBarTrueHeight: this.data.navigationBarTrueHeight,
                navigationBarStyles: this.data.navigationBarStyles,
                navigationBarIconsNum: this.data.navigationBarIconsNum,
                canUseCustomNavigationBar: this.data.canUseCustomNavigationBar,
                noShowNavigationBar: this.data.noShowNavigationBar,
                showBackIcon: this.data.showBackIcon,
                showHomePageIcon: this.data.showHomePageIcon,
                leftSideInnerStyle: this.data.leftSideInnerStyle
            });
        },
        setNavigationBar: function setNavigationBar() {
            var config = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            if (!config.textStyle) {
                console.log("**************************");
                return;
            }
            var pageUrl = (0, _path.getPageUrl)();
            var newSetData = {};
            newSetData.type = config.textStyle;
            newSetData.showHomePageIcon = (0, _page.isShowHomePage)(pageUrl.route);
            if (newSetData.showHomePageIcon) {
                newSetData.navigationBarIconsNum = this.data.navigationBarIconsNum + 1;
            }
            if (config.titleText !== undefined) {
                newSetData.title = config.titleText;
                wx.setNavigationBarTitle({
                    title: config.titleText
                });
            }
            var backgroundColor = "#ff2741";
            var color = "#ffffff";
            if (config.backgroundColor) {
                backgroundColor = config.backgroundColor;
            }
            var colorStyleMap = {
                black: "#000000",
                white: "#ffffff"
            };
            if (colorStyleMap[config.textStyle]) {
                color = colorStyleMap[config.textStyle];
            }
            var paddingTop = (0, _page.getTrueStatusBarHeight)();
            newSetData.navigationBarStyles = "color: " + color + ";background-color: " + backgroundColor + ";padding-top: " + paddingTop + "px;";
            if (wx.setNavigationBarColor) {
                wx.setNavigationBarColor({
                    frontColor: color,
                    backgroundColor: backgroundColor
                });
            }
            console.log("!!!>>>>>>>>>>>>>>>>>>>>>>>", newSetData);
            this.setData(newSetData);
            this.setAllData();
        }
    }
});