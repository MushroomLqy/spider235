Component({
    behaviors: [],
    properties: {
        launchAppParameter: String
    },
    data: {
        isTaped: false
    },
    lifetimes: {
        // 生命周期函数，可以为函数，或一个在methods段中定义的方法名
        attached: function attached() {},
        moved: function moved() {},
        detached: function detached() {},
        ready: function ready() {}
    },
    pageLifetimes: {
        // 组件所在页面的生命周期函数
        show: function show() {}
    },
    methods: {}
});