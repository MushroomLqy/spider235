var _track = require("../../../../../utils/track");

var _eventBus = require("../../../../../libs/event-bus");

var _eventBus2 = _interopRequireDefault(_eventBus);

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

Component({
    properties: {
        desc: String,
        source: String,
        modalWidth: Number,
        background: String,
        launchAppParameter: String,
        showModal: Boolean,
        customMessageCardInfo: {
            type: Object,
            default: {}
        },
        customMessageReplyInfo: {
            type: Object,
            default: {}
        }
    },
    methods: {
        handleTabLaunchAppSuccess: function handleTabLaunchAppSuccess() {
            _eventBus2.default.emit("closeLaunchAppModal");
        },
        handleTabLaunchAppFail: function handleTabLaunchAppFail() {
            (0, _track.trackClick)({
                label: "cancel_to_launch_app",
                timeStamp: new Date().getTime()
            });
            _eventBus2.default.emit("closeLaunchAppModal");
            _eventBus2.default.emit("expandText");
        },
        handleTabLaunchApp: function handleTabLaunchApp() {
            _eventBus2.default.emit("closeLaunchAppModal");
        },
        handleTabCloseModal: function handleTabCloseModal() {
            (0, _track.trackClick)({
                label: "cancel_to_launch_app",
                timeStamp: new Date().getTime()
            });
            _eventBus2.default.emit("closeLaunchAppModal");
            _eventBus2.default.emit("expandText");
        }
    }
});