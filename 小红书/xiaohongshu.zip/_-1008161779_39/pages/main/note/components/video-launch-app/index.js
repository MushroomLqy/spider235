Component({
    behaviors: [],
    properties: {},
    data: {
        launchText: "打开小红书 App 查看高清视频"
    },
    ready: function ready() {},
    show: function show() {},
    methods: {}
});