var _api = require("../../../../../utils/api");

var _api2 = _interopRequireDefault(_api);

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

Component({
    options: {
        multipleSlots: true
    },
    behaviors: [],
    properties: {
        showModal: Boolean,
        modalWidth: Number,
        background: String,
        actionType: Number,
        // 0: 只有关闭按钮 1：确认和取消按钮
        confirmButtonText: String,
        cancelButtonText: String,
        contentType: Number
    },
    data: {
        showModal: false,
        isIOS: _api2.default.$instance.globalData.isIOS
    },
    // 生命周期函数，可以为函数，或一个在methods段中定义的方法名
    attached: function attached() {},
    moved: function moved() {},
    detached: function detached() {},
    ready: function ready() {},
    // 组件所在页面的生命周期函数
    show: function show() {},
    methods: {
        handleTabCancel: function handleTabCancel() {
            this.setData({
                showModal: false
            });
        },
        handleTabConfirm: function handleTabConfirm() {
            this.triggerEvent("confirmModal");
            this.setData({
                showModal: false
            });
        }
    }
});