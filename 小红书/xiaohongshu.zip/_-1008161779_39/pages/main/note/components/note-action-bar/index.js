var _regenerator = require("./../../../../../karin_npm/babel-runtime/regenerator/index.js");

var _regenerator2 = _interopRequireDefault(_regenerator);

var _vuefy = require("../../../../../libs/vuefy.js");

var _track = require("../../../../../utils/track");

var _user = require("../../../../../utils/user");

var _user2 = _interopRequireDefault(_user);

var _api = require("../../../../../utils/api");

var _api2 = _interopRequireDefault(_api);

var _eventBus = require("../../../../../libs/event-bus");

var _eventBus2 = _interopRequireDefault(_eventBus);

var _path = require("../../../../../utils/path");

var _note = require("../../../../../services/note");

var _customsMessage = require("../../utils/customsMessage");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}

function _asyncToGenerator(fn) {
    return function() {
        var gen = fn.apply(this, arguments);
        return new Promise(function(resolve, reject) {
            function step(key, arg) {
                try {
                    var info = gen[key](arg);
                    var value = info.value;
                } catch (error) {
                    reject(error);
                    return;
                }
                if (info.done) {
                    resolve(value);
                } else {
                    return Promise.resolve(value).then(function(value) {
                        step("next", value);
                    }, function(err) {
                        step("throw", err);
                    });
                }
            }
            return step("next");
        });
    };
}

var LIKE_ICON_SRC = "../../../../../assets/images/like_red.svg";

var UNLIKE_ICON_SRC = "../../../../../assets/images/like_black.svg";

var COLLECT_ICON_SRC = "../../../../../assets/images/collect_yellow.svg";

var UNCOLLECT_ICON_SRC = "../../../../../assets/images/collect_black.svg";

var SHARE_ICON_SRC = "../../../../../assets/images/share_black.svg";

var tapMap = {
    like: {
        type: "like",
        tapNote: _note.likeNote,
        disTapNote: _note.dislikeNote,
        hasHandled: "hasLiked",
        num: "likeNum"
    },
    collect: {
        type: "collect",
        tapNote: _note.collectNote,
        disTapNote: _note.deleteCollectNote,
        hasHandled: "hasCollected",
        num: "collectNum"
    }
};

Component({
    behaviors: [],
    properties: {
        liked: Boolean,
        collected: Boolean,
        likedCount: Number,
        sharedCount: Number,
        collectedCount: Number,
        commentCount: Number,
        noteId: String,
        shareImage: String,
        shareTitle: String,
        shareDesc: String,
        shareType: String,
        index: String,
        illegalInfo: Object,
        shareButtonStyle: {
            type: Number,
            value: 0
        },
        refluxType: {
            type: Number,
            value: 0
        },
        launchAppParameter: String,
        canLaunchApp: Boolean,
        shareMomentType: Number,
        shareMomentCustomMessageInfo: Object,
        supportComment: Boolean
    },
    data: {
        shareIconSrc: SHARE_ICON_SRC,
        hasCollected: null,
        collectNum: null,
        hasLiked: null,
        likeNum: null,
        sharedNum: null
    },
    // 生命周期函数，可以为函数，或一个在methods段中定义的方法名
    attached: function attached() {},
    moved: function moved() {},
    detached: function detached() {},
    ready: function ready() {
        var _data = this.data, collected = _data.collected, collectedCount = _data.collectedCount, liked = _data.liked, likedCount = _data.likedCount, sharedCount = _data.sharedCount, commentCount = _data.commentCount;
        this.setData({
            hasCollected: collected,
            collectNum: collectedCount,
            hasLiked: liked,
            likeNum: likedCount,
            sharedNum: sharedCount,
            commentNum: commentCount
        });
        (0, _vuefy.computed)(this, {
            likeIconSrc: function likeIconSrc() {
                return this.data.hasLiked ? LIKE_ICON_SRC : UNLIKE_ICON_SRC;
            },
            collectIconSrc: function collectIconSrc() {
                return this.data.hasCollected ? COLLECT_ICON_SRC : UNCOLLECT_ICON_SRC;
            },
            likeNumText: function likeNumText() {
                var likeNum = this.data.likeNum;
                return likeNum ? this._formatNum(likeNum) : "点赞";
            },
            collectNumText: function collectNumText() {
                var collectNum = this.data.collectNum;
                return collectNum ? this._formatNum(collectNum) : "收藏";
            },
            sharedNumText: function sharedNumText() {
                var sharedNum = this.data.sharedNum;
                return sharedNum ? this._formatNum(sharedNum) : "";
            },
            commentNumText: function commentNumText() {
                var commentCount = this.data.commentCount;
                return commentCount ? this._formatNum(commentCount) : "评论";
            },
            likeCustomMessageReplyInfo: function likeCustomMessageReplyInfo() {
                return this.getCustomMessageReplyInfo("like");
            },
            collectCustomMessageReplyInfo: function collectCustomMessageReplyInfo() {
                return this.getCustomMessageReplyInfo("collect");
            },
            commentCustomMessageReplyInfo: function commentCustomMessageReplyInfo() {
                return this.getCustomMessageReplyInfo("comment");
            }
        });
    },
    methods: {
        handleSaveShareMomentImage: function handleSaveShareMomentImage() {
            this.triggerEvent("triggerShowSaveShareMoment");
        },
        handleTapCollect: function handleTapCollect() {
            this._handleTap(tapMap.collect);
        },
        handleTapLike: function handleTapLike() {
            _eventBus2.default.emit("showFullAddMp");
            this._handleTap(tapMap.like);
        },
        handleTapShare: function handleTapShare() {
            var sharedNum = this.data.sharedNum;
            this.setData({
                sharedNum: sharedNum + 1
            });
        },
        handleGoCommentPage: function handleGoCommentPage() {
            var _this = this;
            _user2.default.ensureLogin().then(function() {
                if (!_this.data.supportComment) {
                    (0, _path.navigateTo)("NoteCommentDetail", {
                        id: _this.data.noteId,
                        from: "engagebar"
                    });
                    return;
                }
                var commentNum = _this.data.commentNum;
                (0, _track.trackNormalData)({
                    action: "comment-tap",
                    label: "footer-action-bar",
                    property: commentNum
                });
                _this.triggerEvent("triggerShowCommentInput");
            });
        },
        // 内部函数
        _formatNum: function _formatNum() {
            var num = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
            if (num >= 1e4) {
                num = Math.round((num / 1e4).toFixed(1) * 10) / 10;
                return num + "万";
            }
            return num;
        },
        _checkIsIllegal: function _checkIsIllegal() {
            var illegalInfo = this.data.illegalInfo;
            if (illegalInfo && illegalInfo.status) {
                var title = void 0;
                switch (illegalInfo.status) {
                  case 1:
                    title = "该笔记已删除";
                    break;

                  case 2:
                    title = "该笔记已违规";
                    break;

                  default:
                    title = "该笔记已删除";
                    break;
                }
                _api2.default.showToast({
                    title: title,
                    icon: "none"
                });
                return true;
            }
            return false;
        },
        getCustomMessageReplyInfo: function getCustomMessageReplyInfo(type) {
            var _data2 = this.data, launchAppParameter = _data2.launchAppParameter, canLaunchApp = _data2.canLaunchApp;
            var typeStr = "";
            var title = "";
            switch (type) {
              case "like":
                typeStr = "为这篇笔记点赞吧！";
                title = "点我，评论这篇笔记！";
                break;

              case "collect":
                typeStr = "收藏这篇笔记吧！";
                title = "点我，收藏这篇笔记！";
                break;

              case "comment":
                typeStr = "评论这篇笔记吧！";
                title = "点我，评论这篇笔记！";
                break;
            }
            if (canLaunchApp) {
                title = "【点击下载小红书APP】";
            }
            return {
                modalDesc: "前往小红书App，" + typeStr,
                sessionFrom: JSON.stringify({
                    title: title,
                    url: (0, _customsMessage.getAbsoluteWebviewUrl)("https://www.xiaohongshu.com/discovery/item/" + this.data.noteId),
                    deeplink: launchAppParameter || ""
                })
            };
        },
        _handleTap: function _handleTap() {
            var _this2 = this;
            var tapType = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            return _asyncToGenerator(/* */ _regenerator2.default.mark(function _callee() {
                var _this2$setData;
                var _data3, noteId, hasCollected, collectNum, hasLiked, likeNum, hasHandled, num, method, _this2$setData2;
                return _regenerator2.default.wrap(function _callee$(_context) {
                    while (1) {
                        switch (_context.prev = _context.next) {
                          case 0:
                            _data3 = _this2.data, noteId = _data3.noteId, hasCollected = _data3.hasCollected, 
                            collectNum = _data3.collectNum, hasLiked = _data3.hasLiked, likeNum = _data3.likeNum;
                            hasHandled = tapType.type === "like" ? hasLiked : hasCollected;
                            num = tapType.type === "like" ? likeNum : collectNum;
                            method = hasHandled ? tapType.disTapNote : tapType.tapNote;
                            (0, _track.trackNormalData)({
                                action: tapType.type + "-tap",
                                label: "footer-action-bar"
                            });
                            // 检查是否为删除或违规笔记
                                                        if (!_this2._checkIsIllegal()) {
                                _context.next = 7;
                                break;
                            }
                            return _context.abrupt("return");

                          case 7:
                            if (_user2.default.getUserId()) {
                                _context.next = 10;
                                break;
                            }
                            _eventBus2.default.emit("goToLogin", {
                                source: "note-" + tapType.type
                            });
                            return _context.abrupt("return");

                          case 10:
                            _context.next = 12;
                            return _user2.default.ensureLogin();

                          case 12:
                            _this2.setData((_this2$setData = {}, _defineProperty(_this2$setData, tapType.hasHandled, !hasHandled), 
                            _defineProperty(_this2$setData, tapType.num, hasHandled ? num - 1 : num + 1), _this2$setData));
                            _context.prev = 13;
                            _context.next = 16;
                            return method({
                                noteId: noteId
                            });

                          case 16:
                            if (!hasHandled) {
                                _this2.triggerEvent("triggerTrackAction", tapType.type);
                            }
                            (0, _track.trackNormalData)({
                                action: hasHandled ? tapType.type + "-decrease" : tapType.type + "-increase",
                                label: "footer-action-bar"
                            });
                            _context.next = 23;
                            break;

                          case 20:
                            _context.prev = 20;
                            _context.t0 = _context["catch"](13);
                            _this2.setData((_this2$setData2 = {}, _defineProperty(_this2$setData2, tapType.hasHandled, hasHandled), 
                            _defineProperty(_this2$setData2, tapType.num, num), _this2$setData2));

                          case 23:
                          case "end":
                            return _context.stop();
                        }
                    }
                }, _callee, _this2, [ [ 13, 20 ] ]);
            }))();
        }
    }
});