var _extends = Object.assign || function(target) {
    for (var i = 1; i < arguments.length; i++) {
        var source = arguments[i];
        for (var key in source) {
            if (Object.prototype.hasOwnProperty.call(source, key)) {
                target[key] = source[key];
            }
        }
    }
    return target;
};

var _user = require("../../../../../utils/user");

var _user2 = _interopRequireDefault(_user);

var _vuefy = require("../../../../../libs/vuefy.js");

var _path = require("../../../../../utils/path");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

Component({
    behaviors: [],
    properties: {
        activityBannerInfo: Object
    },
    data: {},
    ready: function ready() {
        (0, _vuefy.computed)(this, {
            bannerInfo: function bannerInfo() {
                var activityBannerInfo = this.data.activityBannerInfo;
                var result = {};
                if (activityBannerInfo && activityBannerInfo.id) {
                    var _activityBannerInfo$s = activityBannerInfo.shareInfo, shareInfo = _activityBannerInfo$s === undefined ? {} : _activityBannerInfo$s, id = activityBannerInfo.id;
                    var _userUtil$getUserInfo = _user2.default.getUserInfo(), openid = _userUtil$getUserInfo.openid;
                    var params = "position=note-activity-banner&sourceId=miniprogram&activityId=" + id + "&openid=" + openid;
                    var webviewLink = activityBannerInfo.link;
                    webviewLink = webviewLink.indexOf("?") > -1 ? webviewLink + "&" + params : webviewLink + "?" + params;
                    var launchAppParameter = "xhsdiscover://webview/" + webviewLink.replace(/(https?:\/\/)/, "");
                    var customMessageReplyInfo = {
                        sessionFrom: JSON.stringify({
                            url: webviewLink,
                            form: "brand-lottery",
                            thumbUrl: shareInfo.imageUrl,
                            description: shareInfo.desc,
                            title: shareInfo.title,
                            deeplink: launchAppParameter
                        })
                    };
                    result = _extends({}, activityBannerInfo, {
                        launchAppParameter: launchAppParameter,
                        customMessageReplyInfo: customMessageReplyInfo
                    });
                }
                return result;
            }
        });
    },
    methods: {
        handleLaunchAppFail: function handleLaunchAppFail() {
            var activityBannerInfo = this.data.activityBannerInfo;
            (0, _path.navigateTo)("Webview", {
                link: encodeURIComponent(activityBannerInfo.link)
            });
        }
    }
});