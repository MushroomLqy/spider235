var _extends = Object.assign || function(target) {
    for (var i = 1; i < arguments.length; i++) {
        var source = arguments[i];
        for (var key in source) {
            if (Object.prototype.hasOwnProperty.call(source, key)) {
                target[key] = source[key];
            }
        }
    }
    return target;
};

var _vuefy = require("../../../../../libs/vuefy.js");

var _track = require("../../../../../utils/track");

var _path = require("../../../../../utils/path");

var _system = require("../../../../../utils/system");

var _system2 = _interopRequireDefault(_system);

var _note = require("../../../../../services/note");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

var _systemUtil$getSystem = _system2.default.getSystemInfo(), statusBarHeight = _systemUtil$getSystem.statusBarHeight;

var swiperAnimationtimeout = null;

var replayInterval = void 0;

// 5s倒数，播放下一视频
var noMoreTimeOut = void 0;

// 2s消失
// eslint-disable-next-line
Component({
    properties: {
        noteId: String,
        note: Object,
        videoNotes: Array,
        canLaunchApp: Boolean
    },
    data: {
        shareUserInfo: {},
        indicatorDots: false,
        autoplay: false,
        duration: 400,
        animation: "easeOutCubic",
        vertical: true,
        isSlideDown: true,
        // video
        showControls: true,
        isAutoplay: true,
        isLoop: false,
        isMuted: false,
        currentItemId: "",
        currentItemIndex: 0,
        current: 0,
        videoIsPlaying: false,
        isShowEndBox: false,
        countTime: 5,
        isNoMore: false,
        isError: false,
        errorMsg: "",
        showSlideGuide: false,
        showComments: false,
        commmentsData: {},
        shareIconType: "",
        isLaunchError: false,
        videoStyle: "margin-top: " + statusBarHeight + "px;",
        lastCurrent: 0,
        isFetchingMoreNotes: false,
        isFetchingMoreComments: false,
        isNoMoreComments: false,
        videoIsPause: false
    },
    pageLifetimes: {
        hide: function hide() {
            clearInterval(replayInterval);
            clearTimeout(noMoreTimeOut);
        }
    },
    created: function created() {
        (0, _vuefy.watch)(this, {
            videoNotes: function videoNotes(newVal) {
                var oldNewVals = this.data.videoNotes;
                if (newVal && newVal.length > 0) {
                    var notes = newVal;
                    this.setData({
                        isFetchingMoreNotes: false
                    });
                    if (oldNewVals.length === 0 && notes.length > 0) {
                        // 初始化
                        var firstVideoNote = notes[0];
                        var currentNoteItemId = notes && notes.length > 0 ? firstVideoNote.id : "";
                        this.setData({
                            showSlideGuide: true,
                            currentItemId: currentNoteItemId
                        });
                    }
                }
            },
            current: function current(newVal) {
                var _data = this.data, current = _data.current, shareUserInfo = _data.shareUserInfo;
                // 分享者信息，只有第一篇出现
                                if (newVal === 0) {
                    shareUserInfo.isShowShareInfo = true;
                } else {
                    shareUserInfo.isShowShareInfo = false;
                }
                this.setData({
                    shareUserInfo: shareUserInfo
                });
                // 上滑、下滑打点
                                if (newVal > current) {
                    this.setData({
                        isSlideDown: true
                    });
                    (0, _track.trackNormalData)({
                        action: "immersion-slide-down"
                    });
                } else {
                    this.setData({
                        isSlideDown: false
                    });
                    (0, _track.trackNormalData)({
                        action: "immersion-slide-up"
                    });
                }
            },
            isNoMore: function isNoMore(newVal) {
                var _this = this;
                if (newVal) {
                    noMoreTimeOut = setTimeout(function() {
                        _this.setData({
                            isNoMore: false
                        });
                    }, 2e3);
                } else {
                    clearTimeout(noMoreTimeOut);
                }
            }
        });
    },
    methods: {
        handlePause: function handlePause() {
            var currentItemId = this.data.currentItemId;
            var videoContext = wx.createVideoContext(currentItemId, this);
            if (videoContext) {
                videoContext.pause();
            }
        },
        handleLaunchError: function handleLaunchError() {
            this.setData({
                isLaunchError: true
            });
        },
        handleFetchMoreComment: function handleFetchMoreComment() {
            var _this2 = this;
            var _data2 = this.data, isNoMoreComments = _data2.isNoMoreComments, isFetchingMoreComments = _data2.isFetchingMoreComments, commmentsData = _data2.commmentsData, currentItemId = _data2.currentItemId;
            if (isNoMoreComments || isFetchingMoreComments || !commmentsData || commmentsData.comments.length === 0) {
                return;
            }
            var comments = commmentsData.comments;
            var endId = comments[comments.length - 1].id;
            this.setData({
                isFetchingMoreComments: true
            });
            return (0, _note.getNoteCommentDetail)({
                noteId: currentItemId,
                endId: endId
            }).then(function(data) {
                _this2.setData({
                    isFetchingMoreComments: false
                });
                var newData = comments.concat(data.comments);
                _this2.setData({
                    isNoMoreComments: data.comments.length === 0,
                    commmentsData: _extends({}, _this2.data.commmentsData, {
                        comments: newData
                    })
                });
            });
        },
        handleShowComment: function handleShowComment(e) {
            var _this3 = this;
            var noteId = e.detail;
            if (this.data.commmentsData && this.data.commmentsData.comments && this.data.commmentsData.targetNoteId === noteId) {
                this.setData({
                    showComments: true
                });
                return;
            }
            return (0, _note.getNoteCommentDetail)({
                noteId: noteId
            }).then(function(data) {
                _this3.setData({
                    showComments: true,
                    isNoMoreComments: false,
                    commmentsData: data
                });
            });
        },
        handleChange: function handleChange(event) {
            var current = event.detail.current;
            var _data3 = this.data, videoNotes = _data3.videoNotes, lastCurrent = _data3.lastCurrent, isFetchingMoreNotes = _data3.isFetchingMoreNotes;
            var lastNote = videoNotes[lastCurrent];
            if (lastNote) {
                var videoContext = wx.createVideoContext(lastNote.id, this);
                videoContext.pause();
            }
            var newSetData = {};
            if (current === videoNotes.length - 1) {
                if (isFetchingMoreNotes) {
                    return;
                }
                newSetData.isFetchingMoreNotes = true;
                this.triggerEvent("fetchMore");
            }
            newSetData.videoIsPause = false;
            this.setData(newSetData);
        },
        handleAnimationFnish: function handleAnimationFnish(event) {
            var _this4 = this;
            if (swiperAnimationtimeout) {
                clearTimeout(swiperAnimationtimeout);
            }
            swiperAnimationtimeout = setTimeout(function() {
                var videoNotes = _this4.data.videoNotes;
                var current = event.detail.current;
                _this4.setData({
                    lastCurrent: current
                });
                if (!videoNotes[current]) {
                    return;
                }
                var id = videoNotes[current].id;
                _this4.triggerEvent("changeNote", {
                    id: id
                });
                var videoContext = wx.createVideoContext(id, _this4);
                videoContext.play();
                _this4.setData({
                    currentItemId: id,
                    currentItemIndex: current
                });
            }, 200);
        },
        handleVideoPlay: function handleVideoPlay() {
            this.setData({
                videoIsPause: false
            });
        },
        handleVideo: function handleVideo() {
            var _data4 = this.data, videoNotes = _data4.videoNotes, currentItemId = _data4.currentItemId;
            var findIndex = videoNotes.findIndex(function(item) {
                return item.id === currentItemId;
            });
            if (videoNotes[findIndex]) {
                var videoContext = wx.createVideoContext(currentItemId, this);
                if (!this.data.videoIsPause) {
                    videoContext.pause();
                } else {
                    videoContext.play();
                }
                this.setData({
                    videoIsPause: !this.data.videoIsPause
                });
            }
        },
        handleVideoEnded: function handleVideoEnded(e) {
            var id = e.currentTarget.dataset.id;
            (0, _track.trackNormalData)({
                action: "immersion-video-ended",
                property: id
            });
        },
        handleReplay: function handleReplay(e) {
            if (replayInterval) {
                clearInterval(replayInterval);
            }
            var id = e.currentTarget.dataset.id;
            var videoNotes = this.data.videoNotes;
            var findIndex = videoNotes.findIndex(function(item) {
                return item.id === id;
            });
            if (videoNotes[findIndex]) {
                this.triggerEvent("handleSetVideoFeedListValue", {
                    index: findIndex,
                    key: "isEnd",
                    value: false
                });
                var videoContext = wx.createVideoContext(id, this);
                videoContext.play();
                this.setData({
                    isShowEndBox: false
                });
            }
            (0, _track.trackNormalData)({
                action: "immersion-video-replay",
                property: id
            });
        },
        handleErrorBtn: function handleErrorBtn() {
            (0, _track.trackNormalData)({
                action: "error_back_to_home_page"
            });
            (0, _path.switchTab)("HomePage");
        },
        closeSlideGuide: function closeSlideGuide() {
            this.setData({
                showSlideGuide: false
            });
        },
        handleComments: function handleComments() {
            this.setData({
                showComments: !this.data.showComments
            });
        },
        handleFocuse: function handleFocuse(note) {
            this.triggerEvent("focuseOn", note);
        },
        handleActionChange: function handleActionChange(e) {
            var action = e.detail;
            var _data5 = this.data, videoNotes = _data5.videoNotes, currentItemId = _data5.currentItemId;
            var value = {};
            var findIndex = videoNotes.findIndex(function(item) {
                return item.id === currentItemId;
            });
            var targetNote = videoNotes[findIndex];
            switch (action) {
              case "collect":
                value = _extends({}, targetNote, {
                    isCollected: !targetNote.isCollected,
                    collects: targetNote.isCollected ? targetNote.collects - 1 : targetNote.collects + 1
                });
                break;

              case "like":
                value = _extends({}, targetNote, {
                    isLiked: !targetNote.isLiked,
                    likes: targetNote.isLiked ? targetNote.likes - 1 : targetNote.likes + 1
                });
                break;
            }
            this.triggerEvent("handleSetVideoFeedListObjectValue", {
                index: findIndex,
                value: value
            });
        }
    }
});