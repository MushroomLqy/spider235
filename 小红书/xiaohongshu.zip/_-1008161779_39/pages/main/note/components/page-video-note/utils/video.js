Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function() {
    function defineProperties(target, props) {
        for (var i = 0; i < props.length; i++) {
            var descriptor = props[i];
            descriptor.enumerable = descriptor.enumerable || false;
            descriptor.configurable = true;
            if ("value" in descriptor) descriptor.writable = true;
            Object.defineProperty(target, descriptor.key, descriptor);
        }
    }
    return function(Constructor, protoProps, staticProps) {
        if (protoProps) defineProperties(Constructor.prototype, protoProps);
        if (staticProps) defineProperties(Constructor, staticProps);
        return Constructor;
    };
}();

function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}

var Video = function() {
    function Video() {
        _classCallCheck(this, Video);
        this.videoMap = {};
    }
    // 获取播放状态
        _createClass(Video, [ {
        key: "getIsPlaying",
        value: function getIsPlaying() {
            var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            var videoId = options.videoId;
            if (this.videoMap[videoId]) {
                return this.videoMap[videoId].isPlaying;
            }
            return false;
        }
        // 获取播放状态
        }, {
        key: "getIsStoped",
        value: function getIsStoped() {
            var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            var videoId = options.videoId;
            if (this.videoMap[videoId]) {
                return this.videoMap[videoId].isStoped;
            }
            return false;
        }
        // 创建视频实例
        }, {
        key: "getVideoContext",
        value: function getVideoContext() {
            var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            var videoId = options.videoId, self = options.self;
            var videoContext = wx.createVideoContext(videoId, self);
            return videoContext;
        }
        // 初始化所有视频
        }, {
        key: "init",
        value: function init() {
            var _this = this;
            var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            var videoIds = options.videoIds, self = options.self;
            videoIds.forEach(function(key, index) {
                if (!_this.videoMap[key]) {
                    _this.videoMap[key] = {
                        context: _this.getVideoContext({
                            videoId: key,
                            self: self
                        }),
                        isPlaying: false
                    };
                }
            });
        }
        // 销毁没有渲染的视频实例
        }, {
        key: "destroy",
        value: function destroy() {
            var _this2 = this;
            var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            var videoIds = options.videoIds, onDestroyCallBack = options.onDestroyCallBack;
            Object.keys(this.videoMap).forEach(function(key) {
                if (videoIds.indexOf(key) !== -1) {
                    delete _this2.videoMap[key];
                }
            });
            onDestroyCallBack && onDestroyCallBack();
        }
        // 销毁所有视频实例
        }, {
        key: "destroyAll",
        value: function destroyAll() {
            var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            var onDestroyAllCallBack = options.onDestroyAllCallBack;
            this.videoMap = {};
            onDestroyAllCallBack && onDestroyAllCallBack();
        }
        // 暂停所有视频实例
        }, {
        key: "pauseAll",
        value: function pauseAll() {
            var _this3 = this;
            var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            var onPauseAllCallBack = options.onPauseAllCallBack;
            Object.keys(this.videoMap).forEach(function(key) {
                if (_this3.videoMap[key].isPlaying) {
                    _this3.pause({
                        videoId: key
                    });
                }
            });
            onPauseAllCallBack && onPauseAllCallBack();
        }
    }, {
        key: "start",
        value: function start() {
            var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            var videoId = options.videoId, self = options.self;
            // 如果没有就增加一条
                        if (!this.videoMap[videoId]) {
                this.videoMap[videoId] = {
                    context: this.getVideoContext({
                        videoId: videoId,
                        self: self
                    }),
                    isPlaying: false,
                    isStoped: false
                };
            }
            var currentContext = this.videoMap[videoId];
            var _ref = currentContext || {}, context = _ref.context, isPlaying = _ref.isPlaying;
            if (isPlaying) {
                return;
            }
            this.play({
                videoId: videoId
            });
        }
        // 播放视频
        }, {
        key: "play",
        value: function play() {
            var _this4 = this;
            var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            var videoId = options.videoId;
            var currentContext = this.videoMap[videoId];
            var _ref2 = currentContext || {}, context = _ref2.context;
            // // 暂停掉其他所有视频
                        Object.keys(this.videoMap).forEach(function(key) {
                if (key !== videoId) {
                    _this4.pause({
                        videoId: key
                    });
                }
            });
            if (currentContext) {
                context.play();
                currentContext.isPlaying = true;
                currentContext.isStoped = false;
            }
        }
        // 重播视频
        }, {
        key: "replay",
        value: function replay() {
            var _this5 = this;
            var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            var videoId = options.videoId;
            var currentContext = this.videoMap[videoId];
            var _ref3 = currentContext || {}, context = _ref3.context;
            // stop掉其他所有视频
                        Object.keys(this.videoMap).forEach(function(key) {
                if (key !== videoId) {
                    _this5.stop({
                        videoId: key
                    });
                }
            });
            if (currentContext) {
                context.seek(0);
                context.play();
                currentContext.isPlaying = true;
                currentContext.isStoped = false;
            }
        }
        // 播放视频完毕
        }, {
        key: "ended",
        value: function ended() {
            var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            var videoId = options.videoId;
            var currentContext = this.videoMap[videoId];
            if (!currentContext) {
                return;
            }
            currentContext.isPlaying = false;
            currentContext.isStoped = true;
        }
        // 暂停视频
        }, {
        key: "pause",
        value: function pause() {
            var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            var videoId = options.videoId;
            var currentContext = this.videoMap[videoId];
            var _ref4 = currentContext || {}, context = _ref4.context;
            if (!currentContext) {
                return;
            }
            context.pause();
            currentContext.isPlaying = false;
        }
        // 暂停视频
        }, {
        key: "stop",
        value: function stop() {
            var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            var videoId = options.videoId;
            var currentContext = this.videoMap[videoId];
            var _ref5 = currentContext || {}, context = _ref5.context;
            if (!currentContext) {
                return;
            }
            context.pause();
            context.seek(0);
            currentContext.isPlaying = false;
            currentContext.isStoped = true;
        }
        // 进入全屏视频
        }, {
        key: "requestFullScreen",
        value: function requestFullScreen() {
            var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            var videoId = options.videoId;
            var currentContext = this.videoMap[videoId];
            var _ref6 = currentContext || {}, context = _ref6.context;
            if (!currentContext) {
                return;
            }
            context.requestFullScreen({
                direction: 0
            });
        }
        // 退出全屏视频
        }, {
        key: "exitFullScreen",
        value: function exitFullScreen() {
            var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            var videoId = options.videoId;
            var currentContext = this.videoMap[videoId];
            var _ref7 = currentContext || {}, context = _ref7.context;
            if (!currentContext) {
                return;
            }
            context.exitFullScreen();
        }
    } ]);
    return Video;
}();

exports.default = Video;