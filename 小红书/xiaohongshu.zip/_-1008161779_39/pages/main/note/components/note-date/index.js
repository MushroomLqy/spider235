var _vuefy = require("../../../../../libs/vuefy.js");

var _date = require("../../../../../utils/date");

Component({
    behaviors: [],
    properties: {
        time: String
    },
    data: {},
    // 生命周期函数，可以为函数，或一个在methods段中定义的方法名
    attached: function attached() {},
    moved: function moved() {},
    detached: function detached() {},
    ready: function ready() {
        (0, _vuefy.computed)(this, {
            showNoteTime: function showNoteTime() {
                var time = this.data.time;
                var noteTime = new Date((0, _date.dateStringToTimestamp)(time));
                var month = noteTime.getMonth() + 1 < 10 ? "0" + (noteTime.getMonth() + 1) : "" + (noteTime.getMonth() + 1);
                var day = noteTime.getDate() < 10 ? "0" + noteTime.getDate() : "" + noteTime.getDate();
                if (this.isToday(noteTime)) {
                    var hour = "" + noteTime.getHours();
                    var minute = "" + noteTime.getMinutes();
                    return "今天 " + (hour > 9 ? hour : "0" + hour) + ":" + (minute > 9 ? minute : "0" + minute);
                } else if (this.isCurrentYear(noteTime)) {
                    return month + "-" + day;
                } else {
                    var year = "" + noteTime.getFullYear();
                    return year + "-" + month + "-" + day;
                }
            }
        });
    },
    // 组件所在页面的生命周期函数
    show: function show() {},
    methods: {
        // 判断是否当天
        isToday: function isToday(noteTime) {
            return noteTime.toDateString() === new Date().toDateString();
        },
        // 判断是否当年
        isCurrentYear: function isCurrentYear(noteTime) {
            return noteTime.getFullYear() === new Date().getFullYear();
        }
    }
});