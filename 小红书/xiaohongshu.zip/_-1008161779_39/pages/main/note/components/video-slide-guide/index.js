var animationInterval = null;

var STORAGE_KEY = "video_note_show_slide_guide";

Component({
    behaviors: [],
    properties: {},
    data: {
        sliderData: {},
        show: false
    },
    attached: function attached() {
        if (!wx.getStorageSync(STORAGE_KEY)) {
            this.setData({
                show: true
            });
        }
        if (this.data.show) {
            this.sliderAnimation();
        }
    },
    methods: {
        sliderAnimation: function sliderAnimation() {
            var _this = this;
            wx.setStorage({
                key: STORAGE_KEY,
                data: 1
            });
            var slider = wx.createAnimation({
                duration: 1e3,
                timingFunction: "ease"
            });
            this.slider = slider;
            var count = 0;
            animationInterval = setInterval(function() {
                if (count === 2) {
                    clearInterval(animationInterval);
                    _this.closeSlideGuide();
                    return;
                }
                _this.slider.translateY(-100).step({
                    duration: 600
                });
                _this.slider.translateY(0).step({
                    duration: 300
                });
                _this.setData({
                    sliderData: _this.slider.export()
                });
                count += 1;
            }, 1e3);
        },
        closeSlideGuide: function closeSlideGuide() {
            this.triggerEvent("closeSlideGuide");
        }
    }
});