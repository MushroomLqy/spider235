var _vuefy = require("../../../../../libs/vuefy.js");

Component({
    properties: {
        current: Number,
        totalImgCount: Number
    },
    data: {
        maxShowNorDoTCount: 3,
        activePosition: Math.ceil(3 / 2)
    },
    // 生命周期函数，可以为函数，或一个在methods段中定义的方法名
    attached: function attached() {},
    moved: function moved() {},
    detached: function detached() {},
    ready: function ready() {
        (0, _vuefy.computed)(this, {
            showSmallDot: function showSmallDot() {
                var _data = this.data, totalImgCount = _data.totalImgCount, maxShowNorDoTCount = _data.maxShowNorDoTCount;
                var isShowSmallDot = totalImgCount - 2 > maxShowNorDoTCount;
                return isShowSmallDot;
            },
            // 左边不需要出现省略符号占位
            showLeftSmallDot: function showLeftSmallDot() {
                var _data2 = this.data, current = _data2.current, totalImgCount = _data2.totalImgCount, maxShowNorDoTCount = _data2.maxShowNorDoTCount, activePosition = _data2.activePosition;
                var rEllipseSign = totalImgCount - (maxShowNorDoTCount - activePosition) - 1;
                var isShowLeftSmallDot = current <= maxShowNorDoTCount && current < rEllipseSign;
                return isShowLeftSmallDot;
            },
            // 右边不需要出现省略符号占位
            showRightSmallDot: function showRightSmallDot() {
                var _data3 = this.data, current = _data3.current, totalImgCount = _data3.totalImgCount, maxShowNorDoTCount = _data3.maxShowNorDoTCount, activePosition = _data3.activePosition;
                var rEllipseSign = totalImgCount - (maxShowNorDoTCount - activePosition) - 1;
                var isShowRightSmallDot = current >= rEllipseSign;
                return isShowRightSmallDot;
            },
            // 两边都需要出现省略符号占位
            showBothSideSmallDot: function showBothSideSmallDot() {
                var _data4 = this.data, current = _data4.current, totalImgCount = _data4.totalImgCount, maxShowNorDoTCount = _data4.maxShowNorDoTCount, activePosition = _data4.activePosition;
                var rEllipseSign = totalImgCount - (maxShowNorDoTCount - activePosition) - 1;
                var isShowBothSideSmallDot = current > maxShowNorDoTCount && current < rEllipseSign;
                return isShowBothSideSmallDot;
            },
            showFirstActiveDot: function showFirstActiveDot() {
                var _data5 = this.data, current = _data5.current, totalImgCount = _data5.totalImgCount;
                var isShowFirstActiveDot = current === 1;
                return isShowFirstActiveDot;
            },
            showLastActiveDot: function showLastActiveDot() {
                var _data6 = this.data, current = _data6.current, totalImgCount = _data6.totalImgCount;
                var isShowLastActiveDot = current === totalImgCount;
                return isShowLastActiveDot;
            },
            showCenterActiveDot: function showCenterActiveDot() {
                var _data7 = this.data, current = _data7.current, totalImgCount = _data7.totalImgCount;
                var isShowCenterActiveDot = current === totalImgCount;
                return isShowCenterActiveDot;
            }
        });
    },
    pageLifetimes: {
        // 组件所在页面的生命周期函数
        show: function show() {}
    },
    methods: {}
});