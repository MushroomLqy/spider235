var _track = require("../../../../../utils/track");

var _user = require("../../../../../utils/user");

var _user2 = _interopRequireDefault(_user);

var _path = require("../../../../../utils/path");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

Component({
    behaviors: [],
    properties: {
        note: Object,
        unexpandHeight: Number
    },
    attached: function attached() {
        var _this = this;
        var nowDate = new Date();
        var noteDate = this.properties.note.time;
        var showDate = nowDate.getFullYear() === +noteDate.slice(0, 4) ? noteDate.slice(5, 10) : noteDate.slice(0, 10);
        this.setData({
            showDate: showDate
        });
        try {
            this.createSelectorQuery().select(".video-content-text").boundingClientRect(function(res) {
                _this.triggerEvent("getTextHeight", res);
            }).exec();
            this.createSelectorQuery().select(".video-content-box").boundingClientRect(function(res) {
                if (!res) {
                    return;
                }
                var boxBottom = _this.properties.unexpandHeight - res.height;
                _this.setData({
                    boxBottom: boxBottom,
                    background: true
                });
                _this.expandAnimation();
            }).exec();
        } catch (err) {}
        // eslint-disable-line
        },
    data: {
        boxBottom: -1e3,
        expandAnimationData: {},
        background: false,
        showDate: ""
    },
    methods: {
        expandAnimation: function expandAnimation() {
            var expand = wx.createAnimation({
                duration: 200,
                timingFunction: "ease"
            });
            expand.translateY(this.data.boxBottom).step();
            this.setData({
                expandAnimationData: expand.export()
            });
        },
        packUpAnimation: function packUpAnimation() {
            var packUp = wx.createAnimation({
                duration: 200,
                timingFunction: "ease"
            });
            packUp.translateY(0).step();
            this.setData({
                expandAnimationData: packUp.export()
            });
        },
        handleFocuseOn: function handleFocuseOn() {
            this.triggerEvent("focuse", this.properties.note);
        },
        handlePackUp: function handlePackUp() {
            var _this2 = this;
            this.packUpAnimation();
            this.setData({
                background: false
            });
            setTimeout(function() {
                _this2.triggerEvent("packUp");
            }, 200);
        },
        handleTapAvatar: function handleTapAvatar() {
            var id = this.properties.note.user.id;
            (0, _track.trackNormalData)({
                action: "avatar-tap",
                label: "author-avatar",
                property: id
            });
            _user2.default.ensureLogin().then(function() {
                (0, _path.navigateTo)("AuthorPage", {
                    author_id: id
                });
            });
        },
        touchmove: function touchmove() {
            return false;
        }
    }
});