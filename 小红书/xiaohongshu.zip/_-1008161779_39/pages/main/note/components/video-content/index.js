var _miniprogramComputed = require("./../../../../../karin_npm/miniprogram-computed/miniprogram_dist/index.js");

var _miniprogramComputed2 = _interopRequireDefault(_miniprogramComputed);

var _api = require("../../../../../utils/api");

var _api2 = _interopRequireDefault(_api);

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

Component({
    behaviors: [ _miniprogramComputed2.default ],
    properties: {
        note: Object
    },
    data: {
        isExpand: true,
        unexpandHeight: 0,
        showExpand: true,
        init: true
    },
    watch: {
        init: function init() {
            this.setData({
                isExpand: false
            });
        }
    },
    methods: {
        handleFocuseOn: function handleFocuseOn() {
            this.triggerEvent("focuse", this.properties.note);
        },
        handleExpand: function handleExpand() {
            this.setData({
                isExpand: true
            });
        },
        handlePackup: function handlePackup() {
            this.setData({
                isExpand: false
            });
        },
        setUnexpandHeight: function setUnexpandHeight(e) {
            this.setData({
                unexpandHeight: e.detail
            });
        },
        getTextHeight: function getTextHeight(e) {
            if (!e.detail) {
                return;
            }
            var CurrentSystemInfo = _api2.default.$instance.globalData.systemInfo;
            var px2rpx = function px2rpx(rpx) {
                return rpx * 750 / CurrentSystemInfo.windowWidth;
            };
            if (px2rpx(e.detail.height) <= 92) {
                this.setData({
                    showExpand: false
                });
            }
            this.setData({
                init: false
            });
        }
    }
});