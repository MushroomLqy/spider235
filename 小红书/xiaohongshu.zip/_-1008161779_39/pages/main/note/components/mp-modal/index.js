var _track = require("../../../../../utils/track");

var _eventBus = require("../../../../../libs/event-bus");

var _eventBus2 = _interopRequireDefault(_eventBus);

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

Component({
    options: {
        multipleSlots: true
    },
    behaviors: [],
    properties: {
        showModal: Boolean,
        modalWidth: Number,
        background: String,
        showWhere: String,
        customConfirmModalDesc: String,
        launchAppParameter: String,
        customMessageCardInfo: {
            type: Object,
            default: {}
        },
        customMessageReplyInfo: {
            type: Object,
            default: {}
        }
    },
    data: {},
    methods: {
        handleTabCloseModal: function handleTabCloseModal() {
            (0, _track.trackClick)({
                label: "cancel_to_contact",
                timeStamp: new Date().getTime()
            });
            if (this.data.showWhere === "videoFullRelatedCard") {
                // 安卓弹窗层级小于全屏视频，video标签内再次放入mp-modal，需要单独控制
                this.triggerEvent("closeFullMpModal");
            }
            _eventBus2.default.emit("closeMpModal");
        },
        handleToContact: function handleToContact() {
            (0, _track.trackClick)({
                label: "to_contact",
                timeStamp: new Date().getTime()
            });
        },
        handleTapModalMask: function handleTapModalMask() {
            return;
        }
    }
});