var _regenerator = require("./../../../../../karin_npm/babel-runtime/regenerator/index.js");

var _regenerator2 = _interopRequireDefault(_regenerator);

var _appuser = require("../../../../../services/appuser");

var _note2 = require("../../../../../services/note");

var _system = require("../../../../../services/system");

var _homepage = require("../../../../../services/homepage");

var _index = require("../../../../../libs/wxml2canvas/index.js");

var _index2 = _interopRequireDefault(_index);

var _mp = require("../../../../../libs/@xhs/protobuf-mp-chakra-tracker/mp.js");

var _system2 = require("../../../../../utils/system");

var _system3 = _interopRequireDefault(_system2);

var _path = require("../../../../../utils/path");

var _track = require("../../../../../utils/track");

var _user = require("../../../../../utils/user");

var _user2 = _interopRequireDefault(_user);

var _api = require("../../../../../utils/api");

var _api2 = _interopRequireDefault(_api);

var _vuefy = require("../../../../../libs/vuefy.js");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

function _toConsumableArray(arr) {
    if (Array.isArray(arr)) {
        for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) {
            arr2[i] = arr[i];
        }
        return arr2;
    } else {
        return Array.from(arr);
    }
}

function _asyncToGenerator(fn) {
    return function() {
        var gen = fn.apply(this, arguments);
        return new Promise(function(resolve, reject) {
            function step(key, arg) {
                try {
                    var info = gen[key](arg);
                    var value = info.value;
                } catch (error) {
                    reject(error);
                    return;
                }
                if (info.done) {
                    resolve(value);
                } else {
                    return Promise.resolve(value).then(function(value) {
                        step("next", value);
                    }, function(err) {
                        step("throw", err);
                    });
                }
            }
            return step("next");
        });
    };
}

var isDrawingImage = false;

var saveShareImageTimeout = false;

Component({
    behaviors: [],
    properties: {
        renderNoteListData: Array,
        user: Object,
        poi: Object,
        note: Object,
        commentList: Array,
        imageTags: Array,
        swiperHeight: Number,
        isExpand: Boolean,
        isFirst: Boolean,
        isShowPinchTip: Boolean,
        isShowBanner: Boolean,
        index: String,
        coverImgUrl: String,
        startLoadTime: Number,
        canLaunchApp: Boolean,
        shareMomentType: Number,
        noteItemHeight: {
            type: Number,
            observer: function observer(newVal, oldVal) {
                if (oldVal > 0 && newVal !== oldVal) {
                    this.setData({
                        isSettingHeight: false
                    });
                }
            }
        },
        expandButtonStyle: {
            type: Number,
            value: 0
        },
        shareButtonStyle: {
            type: Number,
            value: 0
        },
        launchAppParameter: String,
        customMessageCardInfo: {
            type: Object,
            default: {}
        },
        customMessageReplyInfo: {
            type: Object,
            default: {}
        },
        relatedNotes: {
            type: Array,
            value: []
        },
        isShowNewCallbackStyle: {
            type: Boolean,
            value: false
        },
        refluxType: {
            type: Number,
            value: 0
        },
        expandType: {
            type: Number,
            value: 0
        },
        brandLotteryInfoData: {
            type: Object
        },
        supportComment: {
            type: Boolean
        },
        noteTags: {
            type: Array,
            value: []
        }
    },
    data: {
        isFollowed: null,
        isSettingHeight: false,
        subComment: [],
        commentsTotal: 0,
        isAddComment: false,
        videoList: [],
        current: 1,
        showFollowModal: false,
        opacity: 1,
        isNewStyle: true,
        activity: {},
        isIphoneX: false,
        isIOS: false,
        showSaveShareMoment: false,
        saveImageOpenType: "normal",
        showSaveShareMomentToast: false,
        saveShareNoteImageSize: {},
        showCommentInput: false,
        commentInputFocus: true
    },
    // 生命周期函数，可以为函数，或一个在methods段中定义的方法名
    attached: function attached() {// console.log('------------note-item-attached', Date.now())
    },
    moved: function moved() {// console.log('------------note-item-moved', Date.now())
    },
    detached: function detached() {// console.log('------------note-item-detached', Date.now())
    },
    ready: function() {
        var _ref = _asyncToGenerator(/* */ _regenerator2.default.mark(function _callee() {
            var _data3, user, note, commentList, renderNoteListData, videoList, _data4, startLoadTime, index, activity, current, _ref2, _ref2$note, _note, from, to, link, image, show, itemReadyTime, videoFMP;
            return _regenerator2.default.wrap(function _callee$(_context) {
                while (1) {
                    switch (_context.prev = _context.next) {
                      case 0:
                        this.setData({
                            isIphoneX: _api2.default.$instance.globalData.isIPhoneX,
                            isIOS: _api2.default.$instance.globalData.isIOS
                        });
                        (0, _vuefy.computed)(this, {
                            isShowLocation: function isShowLocation() {
                                return Object.keys(this.data.poi).length !== 0;
                            },
                            totalImgCount: function totalImgCount() {
                                var note = this.data.note;
                                return Number(note.imageList.length);
                            },
                            showFirstImage: function showFirstImage() {
                                var _data = this.data, index = _data.index, note = _data.note;
                                if (note.type && note.type === "normal") {
                                    return index === "0";
                                } else {
                                    return false;
                                }
                            },
                            isIllegal: function isIllegal() {
                                var note = this.data.note;
                                return note.illegalInfo || false;
                            },
                            shareMomentCustomMessageInfo: function shareMomentCustomMessageInfo() {
                                var _data2 = this.data, note = _data2.note, current = _data2.current;
                                var title = note.title, imageList = note.imageList, id = note.id, desc = note.desc, user = note.user, _note$type = note.type, type = _note$type === undefined ? {} : _note$type;
                                var firstImage = {
                                    original: ""
                                };
                                var imageSizeMode = "";
                                var showNoteImage = "";
                                var previewBackgroundUrl = "";
                                if (imageList && imageList.length > 0) {
                                    firstImage = imageList[current - 1];
                                    showNoteImage = firstImage.url || "";
                                    previewBackgroundUrl = showNoteImage + "?imageView2/2/w/1080/format/jpg";
                                    showNoteImage = showNoteImage.replace("http://", "https://");
                                }
                                var imageWidth = firstImage.width;
                                var imageHeight = firstImage.height;
                                if (imageWidth && imageHeight && imageWidth >= imageHeight) {
                                    imageSizeMode = "wide-width";
                                }
                                var showDesc = (title || "") + (desc || "");
                                var defaultShareDesc = type === "video" ? "发布了一篇视频笔记" : "发布了一篇图片笔记";
                                var showUserAvatar = user.image;
                                if (showUserAvatar) {
                                    showUserAvatar = showUserAvatar.replace("http://", "https://");
                                }
                                showDesc = showDesc.trim();
                                showDesc = showDesc || defaultShareDesc;
                                showDesc = showDesc.substr(0, 60);
                                return {
                                    type: type,
                                    title: title,
                                    image: showNoteImage,
                                    imageSizeMode: imageSizeMode,
                                    imageWidth: imageWidth,
                                    imageHeight: imageHeight,
                                    userNickname: user.nickname,
                                    previewBackgroundUrl: previewBackgroundUrl,
                                    userAvatar: showUserAvatar,
                                    description: showDesc,
                                    sessionFrom: JSON.stringify({
                                        from: "share_moment",
                                        url: "https://www.xiaohongshu.com/discovery/item/" + id + "?displayCustomMessageBar=true&xhsshare=mp_note",
                                        thumbUrl: showNoteImage + "?imageView2/2/w/500/format/jpg",
                                        title: "点我，分享到朋友圈",
                                        description: showDesc
                                    })
                                };
                            }
                        });
                        _data3 = this.data, user = _data3.user, note = _data3.note, commentList = _data3.commentList, 
                        renderNoteListData = _data3.renderNoteListData;
                        videoList = [];
                        _data4 = this.data, startLoadTime = _data4.startLoadTime, index = _data4.index;
                        activity = {};
                        // 拉取活动信息
                                                _context.prev = 6;
                        current = new Date();
                        _context.next = 10;
                        return (0, _homepage.getActivityBannerInfo)().catch(function() {
                            return {
                                homefeed: {}
                            };
                        });

                      case 10:
                        _ref2 = _context.sent;
                        _ref2$note = _ref2.note;
                        _note = _ref2$note === undefined ? {} : _ref2$note;
                        from = _note.from, to = _note.to, link = _note.link, image = _note.image, show = _note.show;
                        if (link && from && to && image && show) {
                            if (current > new Date(from) && current < new Date(to)) {
                                (0, _track.trackNormalData)({
                                    action: "impression_activity_banner"
                                });
                                activity = {
                                    show: true,
                                    image: image,
                                    link: link
                                };
                            }
                        }
                        _context.next = 20;
                        break;

                      case 17:
                        _context.prev = 17;
                        _context.t0 = _context["catch"](6);
                        console.error(_context.t0);

                        // eslint-disable-line
                                              case 20:
                        if (index === "0" && note.type === "video") {
                            itemReadyTime = Date.now();
                            videoFMP = itemReadyTime - startLoadTime;
                            (0, _track.trackNormalData)({
                                action: "videoFMP",
                                property: videoFMP
                            });
                        }
                        renderNoteListData.forEach(function(element) {
                            if (element.noteList && element.noteList.length && element.noteList[0].type === "video") {
                                videoList.push(element.noteList[0].video.id);
                            }
                        });
                        this.triggerEvent("ready");
                        this.setData({
                            subComment: commentList,
                            commentsTotal: note.comments,
                            videoList: videoList,
                            activity: activity
                        });
                        if (user && user.hasOwnProperty("isFollowed")) {
                            this.setData({
                                isFollowed: user.isFollowed
                            });
                        }

                      case 25:
                      case "end":
                        return _context.stop();
                    }
                }
            }, _callee, this, [ [ 6, 17 ] ]);
        }));
        function ready() {
            return _ref.apply(this, arguments);
        }
        return ready;
    }(),
    // 组件所在页面的生命周期函数
    show: function show() {// onshow
    },
    methods: {
        handleTrackAction: function handleTrackAction(e) {
            var type = e.detail;
            var note = this.data.note;
            var noteType = note.type === "video" ? "video_note" : "short_note";
            if (type === "like") {
                wx.$eaglet.push(_mp.tracker[2656]({
                    objectPosition: 1,
                    noteId: note.id,
                    noteType: noteType,
                    authorId: note.user.id
                }));
            } else if (type === "collect") {
                wx.$eaglet.push(_mp.tracker[2659]({
                    objectPosition: 1,
                    noteId: note.id,
                    noteType: noteType,
                    authorId: note.user.id
                }));
            }
        },
        handleShowHdButton: function handleShowHdButton() {
            this.triggerEvent("triggerShowHdButton");
        },
        handleHideSaveShareMomentToast: function handleHideSaveShareMomentToast() {
            this.setData({
                showSaveShareMomentToast: false
            });
        },
        handleOpenWritePhotoAlbumSetting: function handleOpenWritePhotoAlbumSetting() {
            var self = this;
            wx.getSetting({
                success: function success(res) {
                    if (res.authSetting["scope.writePhotosAlbum"]) {
                        (0, _track.trackNormalData)({
                            action: "reauth_write_photos"
                        });
                        self.setData({
                            saveImageOpenType: "normal"
                        });
                    }
                }
            });
        },
        handleSaveShareMoment: function handleSaveShareMoment() {
            var _this = this;
            return _asyncToGenerator(/* */ _regenerator2.default.mark(function _callee2() {
                var self, systemInfo, id, qrcodeurl, path, qrcodeurlResult, drawImage, draw;
                return _regenerator2.default.wrap(function _callee2$(_context2) {
                    while (1) {
                        switch (_context2.prev = _context2.next) {
                          case 0:
                            self = _this;
                            systemInfo = _system3.default.getSystemInfo();
                            id = self.data.note.id;
                            qrcodeurl = void 0;
                            if (!isDrawingImage) {
                                _context2.next = 7;
                                break;
                            }
                            wx.showToast({
                                title: "保存失效",
                                icon: "none"
                            });
                            return _context2.abrupt("return");

                          case 7:
                            _context2.prev = 7;
                            path = (0, _path.makePathByRouteKey)("NoteDetail", {
                                id: id,
                                source: "mpSaveShareImage"
                            });
                            _context2.next = 11;
                            return (0, _system.getQrCode)({
                                path: encodeURIComponent(path)
                            });

                          case 11:
                            qrcodeurlResult = _context2.sent;
                            qrcodeurl = qrcodeurlResult.wxmpQrcodeUrl;
                            qrcodeurl = qrcodeurl.replace("http://", "https://");
                            _context2.next = 19;
                            break;

                          case 16:
                            _context2.prev = 16;
                            _context2.t0 = _context2["catch"](7);
                            console.log(_context2.t0);

                            // eslint-disable-line
                                                      case 19:
                            if (qrcodeurl) {
                                _context2.next = 21;
                                break;
                            }
                            return _context2.abrupt("return");

                          case 21:
                            // 初始化 drawImage
                            drawImage = new _index2.default({
                                element: "share-moment-image",
                                // canvas节点的id,
                                width: 375,
                                height: 667,
                                destZoom: systemInfo.pixelRatio,
                                zoom: 1,
                                background: "#000000",
                                gradientBackground: {},
                                progress: function progress() {},
                                // eslint-disable-line
                                finish: function finish(url) {
                                    isDrawingImage = false;
                                    wx.saveImageToPhotosAlbum({
                                        filePath: url,
                                        success: function success(res) {
                                            // eslint-disable-line
                                            (0, _track.trackNormalData)({
                                                action: "save_share_image_success"
                                            });
                                            self.setData({
                                                showSaveShareMoment: false,
                                                showSaveShareMomentToast: true
                                            });
                                            if (saveShareImageTimeout) {
                                                clearTimeout(saveShareImageTimeout);
                                            }
                                            saveShareImageTimeout = setTimeout(function() {
                                                self.setData({
                                                    showSaveShareMomentToast: false
                                                });
                                            }, 3e3);
                                        },
                                        fail: function fail(e) {
                                            // eslint-disable-line
                                            isDrawingImage = false;
                                            (0, _track.trackNormalData)({
                                                action: "save_share_image_fail"
                                            });
                                            wx.hideLoading();
                                        },
                                        complete: function complete() {
                                            isDrawingImage = false;
                                            wx.hideLoading();
                                        }
                                        // eslint-disable-line
                                                                        });
                                },
                                error: function error(err) {
                                    (0, _track.trackNormalData)({
                                        action: "save_share_image_fail"
                                    });
                                    console.log(err);
                                    // eslint-disable-line
                                                                }
                            });
                            // 绘制图片
                                                        draw = function draw() {
                                var _self$data = self.data, shareMomentCustomMessageInfo = _self$data.shareMomentCustomMessageInfo, saveShareNoteImageSize = _self$data.saveShareNoteImageSize;
                                var noteImageWidth = saveShareNoteImageSize.noteImageWidth, noteImageHeight = saveShareNoteImageSize.noteImageHeight, rectX = saveShareNoteImageSize.rectX, rectY = saveShareNoteImageSize.rectY;
                                var description = shareMomentCustomMessageInfo.description || "";
                                var showDesc = description.replace(/[\r\n]/g, "");
                                var descHeight = showDesc.length < 25 ? 62 : 82;
                                var data = {
                                    list: [ {
                                        type: "image",
                                        url: shareMomentCustomMessageInfo.image + "?imageMogr2/crop/750x1334/blur/50x50",
                                        class: "background_image",
                                        x: 0,
                                        y: 0,
                                        style: {
                                            width: 375,
                                            height: 667
                                        }
                                    }, {
                                        type: "circle",
                                        x: rectX,
                                        y: rectY,
                                        style: {
                                            fill: "#ffffff",
                                            width: noteImageWidth + 30,
                                            height: noteImageHeight + descHeight + 15,
                                            radius: [ 16, 16, 16, 16 ]
                                        }
                                    }, {
                                        type: "radius-image",
                                        url: shareMomentCustomMessageInfo.image + "?imageView2/2/w/" + noteImageWidth * 2 + "/h/" + noteImageHeight * 2 + "/format/jpg",
                                        x: rectX + 15,
                                        y: rectY + 15,
                                        style: {
                                            width: noteImageWidth,
                                            // eslint-disable-line
                                            height: noteImageHeight,
                                            radius: [ 16, 1, 1, 16 ]
                                        }
                                    }, {
                                        type: "radius-image",
                                        url: shareMomentCustomMessageInfo.userAvatar,
                                        x: rectX + 15,
                                        y: rectY + 15 + noteImageHeight - 20,
                                        style: {
                                            r: 20,
                                            border: "2px solid #ffffff"
                                        }
                                    }, {
                                        type: "text",
                                        text: shareMomentCustomMessageInfo.userNickname,
                                        x: rectX + 60,
                                        y: rectY + 16 + noteImageHeight,
                                        style: {
                                            width: 285,
                                            fontSize: 13,
                                            textAlign: "left",
                                            color: "#333333",
                                            lineHeight: 18,
                                            height: 18,
                                            lineClamp: 1,
                                            fontWeight: "bold"
                                        }
                                    }, {
                                        type: "text",
                                        text: showDesc,
                                        x: rectX + 15,
                                        y: rectY + 15 + noteImageHeight + 26,
                                        style: {
                                            width: noteImageWidth,
                                            fontSize: 12,
                                            textAlign: "left",
                                            color: "#333333",
                                            lineHeight: 20,
                                            height: 40,
                                            lineClamp: 2,
                                            fontWeight: "bold"
                                        }
                                    }, {
                                        type: "radius-image",
                                        url: qrcodeurl,
                                        x: 158,
                                        y: 542,
                                        style: {
                                            width: 60,
                                            // eslint-disable-line
                                            height: 60,
                                            radius: [ 8, 8, 8, 8 ]
                                        }
                                    }, {
                                        type: "text",
                                        text: "👆 扫一扫, 找到你想要的生活~",
                                        x: 50,
                                        y: 617,
                                        style: {
                                            width: 275,
                                            fontSize: 13,
                                            textAlign: "center",
                                            color: "#ffffff",
                                            lineClamp: 1,
                                            lineHeight: 15
                                        }
                                    } ]
                                };
                                if (shareMomentCustomMessageInfo.type === "video") {
                                    data.list.push({
                                        type: "image",
                                        url: "https://ci.xiaohongshu.com/4b606a93-76e7-4820-92a2-23c5cc5265b3",
                                        class: "",
                                        x: rectX + 15 + noteImageWidth / 2 - 14,
                                        y: rectY + 15 + noteImageHeight - noteImageHeight / 2 - 14,
                                        style: {
                                            width: 28,
                                            height: 28
                                        }
                                    });
                                }
                                drawImage.draw(data);
                                wx.showLoading({
                                    title: "正在生成中..."
                                });
                            };
                            // 判断权限
                                                        wx.getSetting({
                                success: function success(res) {
                                    if (!res.authSetting["scope.writePhotosAlbum"]) {
                                        wx.authorize({
                                            scope: "scope.writePhotosAlbum",
                                            success: function success() {
                                                (0, _track.trackNormalData)({
                                                    action: "draw_share_image",
                                                    property: "reauth_success"
                                                });
                                                draw();
                                            },
                                            fail: function fail() {
                                                (0, _track.trackNormalData)({
                                                    action: "draw_share_image",
                                                    property: "auth_fail"
                                                });
                                                self.setData({
                                                    saveImageOpenType: "openSetting"
                                                });
                                            }
                                        });
                                    } else {
                                        (0, _track.trackNormalData)({
                                            action: "draw_share_image",
                                            property: "auth_success"
                                        });
                                        draw();
                                    }
                                }
                            });

                          case 24:
                          case "end":
                            return _context2.stop();
                        }
                    }
                }, _callee2, _this, [ [ 7, 16 ] ]);
            }))();
        },
        handleHideSaveShareMoment: function handleHideSaveShareMoment() {
            (0, _track.trackNormalData)({
                action: "hide_save_share_image_modal"
            });
            this.setData({
                showSaveShareMoment: false
            });
        },
        handleShowSaveShareMoment: function handleShowSaveShareMoment() {
            var shareMomentCustomMessageInfo = this.data.shareMomentCustomMessageInfo;
            var noteImageWidth = 285;
            var noteImageHeight = parseInt(noteImageWidth * shareMomentCustomMessageInfo.imageHeight / shareMomentCustomMessageInfo.imageWidth, 10);
            noteImageHeight = Math.min(380, noteImageHeight);
            var rectY = (667 - 135 - noteImageHeight - 15 - 82) / 2;
            var rectX = (375 - (noteImageWidth + 30)) / 2;
            var previewNoteImageStyle = [ "width:" + noteImageWidth * 2 + "rpx", "height:" + noteImageHeight * 2 + "rpx", "background-image: url('" + shareMomentCustomMessageInfo.image + "?imageView2/2/w/540/format/jpg')" ];
            (0, _track.trackNormalData)({
                action: "show_save_share_image_modal"
            });
            this.setData({
                saveShareNoteImageSize: {
                    noteImageHeight: noteImageHeight,
                    noteImageWidth: noteImageWidth,
                    previewNoteImageStyle: previewNoteImageStyle.join(";"),
                    rectY: rectY,
                    rectX: rectX
                },
                showSaveShareMoment: true
            });
        },
        handleTapActivity: function handleTapActivity() {
            var activity = this.data.activity;
            (0, _track.trackNormalData)({
                action: "click_activity_banner"
            });
            wx.navigateTo({
                url: activity.link
            });
        },
        handleTriggerExpand: function handleTriggerExpand(e) {
            var canExpand = e.detail.canExpand;
            this.setData({
                isSettingHeight: true
            });
            this.triggerEvent("triggerexpand", {
                canExpand: canExpand
            });
        },
        handleTriggleFollow: function handleTriggleFollow() {
            var _this2 = this;
            return _asyncToGenerator(/* */ _regenerator2.default.mark(function _callee3() {
                var _data5, isFollowed, user;
                return _regenerator2.default.wrap(function _callee3$(_context3) {
                    while (1) {
                        switch (_context3.prev = _context3.next) {
                          case 0:
                            _context3.next = 2;
                            return _user2.default.ensureLogin();

                          case 2:
                            _data5 = _this2.data, isFollowed = _data5.isFollowed, user = _data5.user;
                            if (!isFollowed) {
                                _this2._followAppUser(user);
                                // eslint-disable-line no-underscore-dangle
                                                        } else {
                                _this2.setData({
                                    showFollowModal: true
                                });
                            }

                          case 4:
                          case "end":
                            return _context3.stop();
                        }
                    }
                }, _callee3, _this2);
            }))();
        },
        handleTapAvatar: function handleTapAvatar(e) {
            var id = e.currentTarget.dataset.id;
            (0, _track.trackNormalData)({
                action: "avatar-tap",
                label: "author-avatar",
                property: id
            });
            _user2.default.ensureLogin().then(function() {
                (0, _path.navigateTo)("AuthorPage", {
                    author_id: id
                });
            });
        },
        handleShowCommentInput: function handleShowCommentInput() {
            var _ref3 = this.data.note || {}, id = _ref3.id, type = _ref3.type, _ref3$user = _ref3.user, user = _ref3$user === undefined ? {} : _ref3$user;
            var noteType = type === "video" ? "video_note" : "short_note";
            wx.$eaglet.push(_mp.tracker[2759]({
                objectPosition: 1,
                noteId: id,
                noteType: noteType,
                authorId: user.id
            }));
            this.setData({
                showCommentInput: true
            });
        },
        handleHideCommentInput: function handleHideCommentInput() {
            this.setData({
                showCommentInput: false
            });
        },
        handleCreateComment: function handleCreateComment() {
            var _ref4 = this.data.note || {}, id = _ref4.id;
            if (id) {
                this._fetchNoteSummaryComment({
                    // eslint-disable-line no-underscore-dangle
                    id: id
                });
                this.setData({
                    showCommentInput: false
                });
            }
        },
        handleShareIcon: function handleShareIcon(index) {
            this.selectComponent("#note-action-bar-" + index).handleTapShare();
        },
        handleTapPoi: function handleTapPoi() {
            var poi = this.data.poi;
            if (poi.link) {
                (0, _path.navigateTo)("Webview", {
                    link: poi.link
                });
            }
        },
        handleNoteImageSwitched: function handleNoteImageSwitched(e) {
            var current = e.detail.current;
            this.setData({
                current: current
            });
        },
        handleBackhome: function handleBackhome() {
            var note = this.data.note;
            if (note.type === "video" && this && this.selectComponent && this.selectComponent("#note")) {
                this.selectComponent("#note").handleBackhome();
            }
        },
        handleHasReaded: function handleHasReaded() {
            if (this.selectComponent("#pinch-tip")) {
                this.selectComponent("#pinch-tip").handleHasReaded();
            }
        },
        handleFirstImageSwitched: function handleFirstImageSwitched() {
            this.triggerEvent("firstImageLoaded");
            this.setData({
                opacity: 0
            });
        },
        handleBannerTap: function handleBannerTap() {
            (0, _track.trackNormalData)({
                action: "click_welfare_activity_from_new_notedetail"
            });
            (0, _path.navigateTo)("Webview", {
                link: encodeURIComponent("https://pages.xiaohongshu.com/event/page/sale/5cb4293493bdfc70d2a208c9")
            });
        },
        // 内部函数
        _followAppUser: function _followAppUser(user) {
            var _this3 = this;
            var note = this.data.note;
            (0, _appuser.followUser)({
                userId: user.id
            }).then(function() {
                (0, _track.trackNormalData)({
                    action: "follow-tap",
                    label: "follow-button",
                    property: user.id
                });
                _this3.setData({
                    isFollowed: true
                });
                wx.$eaglet.push(_mp.tracker[2661]({
                    objectPosition: 1,
                    noteId: note.id,
                    trackId: "Null",
                    noteType: note.type === "video" ? "video_note" : "short_note",
                    authorId: user.id
                }));
            });
        },
        _unfollowAppUser: function _unfollowAppUser(e) {
            var _this4 = this;
            var user = e.detail.user;
            (0, _appuser.unfollowUser)({
                userId: user.id
            }).then(function() {
                (0, _track.trackNormalData)({
                    action: "unfollow-tap",
                    label: "unfollow-button",
                    property: user.id
                });
                _this4.setData({
                    isFollowed: false
                });
            });
        },
        _fetchNoteSummaryComment: function _fetchNoteSummaryComment(_ref5) {
            var _this5 = this;
            var id = _ref5.id;
            var subComment = this.data.subComment;
            (0, _note2.getNoteCommentDetail)({
                noteId: id,
                pageSize: 1
            }).then(function(res) {
                var comments = res.comments.map(function(comment) {
                    comment.user.name = comment.user.nickname;
                    return comment;
                });
                var newSubComment = [].concat(_toConsumableArray(subComment));
                newSubComment.splice(0, 1, comments[0]);
                _this5.setData({
                    subComment: newSubComment,
                    commentsTotal: res.commentsTotal,
                    isAddComment: true
                });
            });
        }
    }
});