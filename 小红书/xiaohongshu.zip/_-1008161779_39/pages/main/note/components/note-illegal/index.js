Component({
    properties: {
        illegalInfo: Object
    }
});