Component({
    behaviors: [],
    properties: {
        commentsData: Object,
        isNoMoreComments: Boolean
    },
    data: {
        commentAnimationData: {}
    },
    attached: function attached() {
        this.popupAnimation();
    },
    methods: {
        popupAnimation: function popupAnimation() {
            var popup = wx.createAnimation({
                duration: 400,
                timingFunction: "ease"
            });
            popup.translateY(0).step();
            this.setData({
                commentAnimationData: popup.export()
            });
        },
        backAnimation: function backAnimation() {
            var back = wx.createAnimation({
                duration: 400,
                timingFunction: "ease"
            });
            back.translateY(1e3).step();
            this.setData({
                commentAnimationData: back.export()
            });
        },
        closeComments: function closeComments() {
            var _this = this;
            this.backAnimation();
            setTimeout(function() {
                _this.triggerEvent("closeComments");
            }, 400);
        },
        handleFetchMore: function handleFetchMore() {
            this.triggerEvent("fetchMoreComment");
        }
    }
});