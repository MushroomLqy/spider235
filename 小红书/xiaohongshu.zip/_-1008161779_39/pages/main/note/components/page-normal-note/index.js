Component({
    properties: {
        noteId: String,
        noteType: String,
        launchAppParameter: String,
        noteList: Array,
        navigationBarTrueHeight: String,
        note: Object,
        fetchedRelatedNotes: Boolean,
        canLaunchApp: Boolean,
        isShowSkeleton: Boolean,
        screenTopNotePlaceholderHeight: Number,
        opacity: Number,
        showLaunchAppModal: Boolean,
        launchAppModalDesc: String,
        launchAppModalSource: String,
        isIphoneX: Boolean,
        illegalInfo: String || Object,
        firstRender: Object,
        shareUserId: String,
        isShowShareInfoBar: Boolean,
        activityBannerInfo: Object,
        refluxType: String,
        noteFeedCanLaunchApp: Boolean
    },
    data: {
        navigationBarConfig: {
            titleText: "笔记详情",
            backgroundColor: "#FFFFFF",
            textStyle: "black"
        },
        defaultLaunchAppText: ""
    },
    methods: {
        handleShowHdButton: function handleShowHdButton() {
            this.setData({
                defaultLaunchAppText: "App 内观看高清视频"
            });
        },
        handleImageLoad: function handleImageLoad() {}
    }
});