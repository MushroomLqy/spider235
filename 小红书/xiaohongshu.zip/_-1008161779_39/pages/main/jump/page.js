var _extends = Object.assign || function(target) {
    for (var i = 1; i < arguments.length; i++) {
        var source = arguments[i];
        for (var key in source) {
            if (Object.prototype.hasOwnProperty.call(source, key)) {
                target[key] = source[key];
            }
        }
    }
    return target;
};

var _tracker = require("../../../mixins/tracker");

var _tracker2 = _interopRequireDefault(_tracker);

var _routes = require("../../../routes");

var _track = require("../../../utils/track");

var _path = require("../../../utils/path");

var _string = require("../../../utils/string");

var _api = require("../../../utils/api");

var _api2 = _interopRequireDefault(_api);

var _jumppage = require("../../../services/jumppage");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

function _objectWithoutProperties(obj, keys) {
    var target = {};
    for (var i in obj) {
        if (keys.indexOf(i) >= 0) continue;
        if (!Object.prototype.hasOwnProperty.call(obj, i)) continue;
        target[i] = obj[i];
    }
    return target;
}

Page({
    data: {},
    mixins: [ _tracker2.default ],
    onLoad: function onLoad() {
        var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
        var pathId = void 0;
        var ads = options.ads, pageKey = options.pageKey, otherOptions = _objectWithoutProperties(options, [ "ads", "pageKey" ]);
        // 判断广告
                if (ads) {
            (0, _jumppage.getAdsQrCodeUrl)().then(function() {
                var data = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
                var adsArray = data.ads;
                adsArray.forEach(function(ad) {
                    if (ad.name === ads) {
                        var category = ad.category, params = ad.params;
                        params = params || {};
                        console.log(">>>>>>>>要跳转的category", category);
                        // eslint-disable-line
                        // 打点
                                                (0, _track.trackApm)({
                            action: "advertisement_pageview",
                            property: ad.name,
                            label: ad
                        });
                        if (!(0, _routes.isSwitchTab)(category)) {
                            (0, _path.redirectTo)(category, params);
                        } else {
                            (0, _path.switchTab)(category);
                        }
                    }
                });
            });
            return;
        }
        if (options.scene) {
            var matchScene = decodeURIComponent(options.scene).match(/[0-9A-Fa-f]{24}/);
            if (Object.prototype.toString.call(matchScene) === "[object Array]" && matchScene.length > 0) {
                pathId = matchScene[0];
            }
        }
        if (pathId) {
            (0, _jumppage.getJumpPageUrl)({
                pathId: pathId
            }).then(function(data) {
                var link = decodeURIComponent(data.wxmpQrcodeUrl);
                var isWebLink = (0, _string.isWebViewLink)(link);
                if (isWebLink) {
                    (0, _path.redirectTo)("Webview", {
                        link: link
                    });
                } else {
                    (0, _track.trackApm)({
                        action: "redirect_success",
                        property: pathId
                    });
                    var targetCategory = (0, _routes.getCategoryByPath)(link);
                    if ((0, _routes.isSwitchTab)(targetCategory)) {
                        (0, _path.switchTab)(targetCategory);
                    } else {
                        _api2.default.redirectTo({
                            url: "/" + link
                        });
                    }
                }
            }).catch(function(err) {
                (0, _track.trackApm)({
                    action: "redirect_failure",
                    property: pathId
                });
                console.log(err);
                // eslint-disable-line
                        });
        } else {
            var method = _path.redirectTo;
            var defaultKey = "HomePage";
            var query = _extends({}, otherOptions);
            // 判断key是否存在
                        if (!_routes.RouteMap[pageKey]) {
                pageKey = defaultKey;
            }
            if ((0, _routes.isSwitchTab)(pageKey)) {
                method = _path.switchTab;
                query = undefined;
            }
            (0, _track.trackApm)({
                action: "redirect_by_category",
                property: pageKey
            });
            method(pageKey, query);
        }
    }
});