var _regenerator = require("./../../../karin_npm/babel-runtime/regenerator/index.js");

var _regenerator2 = _interopRequireDefault(_regenerator);

var _extends = Object.assign || function(target) {
    for (var i = 1; i < arguments.length; i++) {
        var source = arguments[i];
        for (var key in source) {
            if (Object.prototype.hasOwnProperty.call(source, key)) {
                target[key] = source[key];
            }
        }
    }
    return target;
};

var _tracker = require("../../../mixins/tracker");

var _tracker2 = _interopRequireDefault(_tracker);

var _author = require("../../../services/author");

var _collect = require("../../../services/collect");

var _track = require("../../../utils/track");

var _user = require("../../../utils/user");

var _user2 = _interopRequireDefault(_user);

var _note = require("../../../services/note");

var _tracker3 = require("../../../services/tracker");

var _eventBus = require("../../../libs/event-bus");

var _eventBus2 = _interopRequireDefault(_eventBus);

var _mp = require("../../../libs/@xhs/protobuf-mp-chakra-tracker/mp.js");

var _path = require("../../../utils/path");

var _scrollFeeds = require("../../../components/note-list/scroll-feeds");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

function _asyncToGenerator(fn) {
    return function() {
        var gen = fn.apply(this, arguments);
        return new Promise(function(resolve, reject) {
            function step(key, arg) {
                try {
                    var info = gen[key](arg);
                    var value = info.value;
                } catch (error) {
                    reject(error);
                    return;
                }
                if (info.done) {
                    resolve(value);
                } else {
                    return Promise.resolve(value).then(function(value) {
                        step("next", value);
                    }, function(err) {
                        step("throw", err);
                    });
                }
            }
            return step("next");
        });
    };
}

function replaceWebp2jpg(notes) {
    return notes.map(function(item) {
        var fileName = item.image.url;
        var ext = fileName.substring(fileName.lastIndexOf("."), fileName.length);
        if (ext === ".webp") {
            fileName = fileName.slice(0, fileName.lastIndexOf(".")) + ".jpg";
        }
        item.image.url = fileName;
        return item;
    });
}

var isFetching = false;

Page({
    $eagletPageMeta: {
        // 业务埋点页面
        pageInstance: "profile_page",
        // 比如 note_id, user_id
        instanceId: function instanceId() {
            return "";
        },
        // 是否需要开启监听曝光打点
        needImpression: false,
        pageview: false
    },
    data: {
        isMinePage: true,
        isLogin: false,
        noteList: [],
        navigationBarConfig: {
            titleText: "",
            backgroundColor: "none",
            noBackgroundColor: true,
            textStyle: "white"
        },
        type: "white",
        pageConfig: {
            fullScreen: true,
            pageContentPadding: false
        },
        canLike: false,
        page: 1,
        userInfo: {},
        isMembership: false,
        bottomStart: "",
        // 笔记 收藏
        switchTab: "notes",
        isFetchEnd: false,
        showNavigationBar: false
    },
    mixins: [ _tracker2.default ],
    init: function init(id) {
        this.refreshUserInfo(id);
        this.refreshNotes(id);
        this.getMemberInfo(id);
        this.initEventBus();
    },
    refreshNotes: function refreshNotes(id) {
        var userId = id;
        if (this.data.switchTab === "collect") {
            this.setData({
                bottomStart: ""
            });
            this.fetchCollectFeed();
            return;
        }
        if (this.data.switchTab === "notes") {
            this.fetchAuthorNotes({
                userId: userId
            });
            return;
        }
    },
    onLoad: function onLoad() {
        var _this = this;
        var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
        var userInfo = _user2.default.getUserInfo();
        var appUserId = userInfo.appUserId;
        _user2.default.ensureLogin().then(function() {
            _this.init(appUserId);
        });
        // 新打点
                wx.$eaglet.page.setConfig({
            $eagletPageMeta: this.$eagletPageMeta
        });
        wx.$eaglet.page.initPage(options);
        wx.$eaglet.page.trackPageView(_mp.tracker[1185]());
        this.setData({
            userId: appUserId,
            isLogin: _user2.default.checkLogin()
        });
    },
    onUnload: function onUnload() {
        _eventBus2.default.off("likeTaped");
    },
    onHide: function onHide() {
        _eventBus2.default.off("likeTaped");
    },
    fetchCollectFeed: function fetchCollectFeed() {
        var _this2 = this;
        var _User$getUserInfo = _user2.default.getUserInfo(), appUserId = _User$getUserInfo.appUserId;
        var start = this.data.bottomStart || "";
        if (isFetching) {
            return new Promise(function(resolve) {
                return resolve();
            });
        }
        isFetching = true;
        return (0, _collect.getAuthorFaved)({
            start: start,
            userId: appUserId
        }).then(function(notes) {
            if (notes && notes.length === 0) {
                _this2.setData({
                    isFetchEnd: true
                });
            } else {
                notes = _this2.formatNoteList(notes);
                _this2.setData({
                    noteList: _this2.data.noteList.concat(notes)
                });
                _this2.setData({
                    bottomStart: notes[notes.length - 1].id
                });
            }
            isFetching = false;
        }, function() {
            isFetching = false;
        });
    },
    fetchAuthorNotes: function fetchAuthorNotes(_ref) {
        var _this3 = this;
        var userId = _ref.userId, _ref$page = _ref.page, page = _ref$page === undefined ? 1 : _ref$page, _ref$pageSize = _ref.pageSize, pageSize = _ref$pageSize === undefined ? 15 : _ref$pageSize;
        if (isFetching) {
            return new Promise(function(resolve) {
                return resolve();
            });
        }
        isFetching = true;
        return (0, _author.getNoteUser)({
            userId: userId,
            page: page,
            pageSize: pageSize
        }).then(function(notes) {
            if (notes && notes.length === 0) {
                _this3.setData({
                    isFetchEnd: true
                });
            } else {
                var newNoteList = _this3.formatNoteList(notes);
                _this3.setData({
                    noteList: _this3.data.noteList.concat(newNoteList)
                });
            }
            isFetching = false;
            _this3.setData({
                page: _this3.data.page + 1
            });
        }, function(err) {
            isFetching = false;
            console.log("err", err);
        });
    },
    pushMoreFeeds: function pushMoreFeeds() {
        if (this.data.noteList.length === 0) {
            return;
        }
        if (this.data.switchTab === "collect") {
            this.fetchCollectFeed();
        }
        if (this.data.switchTab === "notes") {
            this.fetchAuthorNotes({
                userId: this.data.userId,
                page: this.data.page,
                pageSize: this.data.pageSize
            });
        }
    },
    getMemberInfo: function getMemberInfo(id) {
        var _this4 = this;
        return _asyncToGenerator(/* */ _regenerator2.default.mark(function _callee() {
            var memberInfo;
            return _regenerator2.default.wrap(function _callee$(_context) {
                while (1) {
                    switch (_context.prev = _context.next) {
                      case 0:
                        _context.next = 2;
                        return (0, _author.fetchMemberInfo)(id);

                      case 2:
                        memberInfo = _context.sent;
                        _this4.setData({
                            isMembership: memberInfo && memberInfo.isMembership
                        });

                      case 4:
                      case "end":
                        return _context.stop();
                    }
                }
            }, _callee, _this4);
        }))();
    },
    formatNoteList: function formatNoteList() {
        var notes = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
        var noteList = notes.map(function(item) {
            return Object.assign({}, item, {
                image: item.cover,
                user: {
                    id: item.user.id,
                    image: item.user.image,
                    nickname: item.user.nickname,
                    userid: item.user.id || item.user.userId,
                    redOfficialVerifyShowIcon: item.user.redOfficialVerifyShowIcon
                }
            });
        });
        return replaceWebp2jpg(noteList);
    },
    refreshUserInfo: function refreshUserInfo(userId) {
        var _this5 = this;
        (0, _author.getUserInfo)({
            userId: userId
        }).then(function() {
            var userInfo = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            _this5.setData({
                userInfo: userInfo
            });
        });
    },
    handleGoLoginPage: function handleGoLoginPage() {
        (0, _path.navigateTo)("LoginIndex");
    },
    initEventBus: function initEventBus() {
        var _this6 = this;
        _eventBus2.default.on("likeTaped", function(id) {
            _this6.data.noteList.some(function(item, index) {
                if (id === item.id) {
                    var isLiked = item.isLiked;
                    var method = _note.likeNote;
                    var action = "like-increase";
                    if (isLiked) {
                        method = _note.dislikeNote;
                        action = "like-decrease";
                    }
                    method({
                        noteId: id
                    }).then(function(res) {
                        _tracker3.wxTrack.call(_this6, {
                            action: action,
                            property: id
                        });
                        item.likes = isLiked ? --item.likes : ++item.likes;
                        item.isLiked = !isLiked;
                        var newNoteList = _this6.data.noteList;
                        newNoteList[index] = item;
                        _this6.setData({
                            noteList: newNoteList
                        });
                    });
                    return true;
                }
            });
        });
    },
    handleEditInfo: function handleEditInfo() {
        if (!this.isLogin) {
            (0, _path.navigateTo)("LoginIndex");
            return;
        }
        (0, _track.trackClick)({
            label: "edit_info",
            context: {},
            timeStamp: new Date().getTime()
        });
        (0, _path.navigateTo)("InfoPage");
    },
    handleScroll: function handleScroll(e) {
        if (this.data.noteList.length > _scrollFeeds.REFRESH_FEEDS_NOTES_LENGTH) {
            wx.showToast({
                icon: "none",
                title: "正在加载更多内容"
            });
            this.setData({
                noteList: this.data.noteList.slice(_scrollFeeds.REFRESH_FEEDS_NOTES_LENGTH - 10)
            });
        }
        var scrollTop = e.detail.scrollTop;
        var scrollHeight = e.detail.scrollHeight;
        var showNavigationBarHeight = 200;
        if (scrollTop > showNavigationBarHeight && !this.data.showNavigationBar) {
            this.setData({
                showNavigationBar: true,
                navigationBarConfig: _extends({}, this.data.navigationBarConfig, {
                    titleText: "我的",
                    backgroundColor: "#7A6E69"
                })
            });
        }
        if (scrollTop <= showNavigationBarHeight && this.data.showNavigationBar) {
            this.setData({
                showNavigationBar: false,
                navigationBarConfig: _extends({}, this.data.navigationBarConfig, {
                    titleText: "",
                    backgroundColor: "none"
                })
            });
        }
        if (scrollHeight - scrollTop < _scrollFeeds.PUSH_MORE_SCOLL_TOP) {
            if (!this.data.isLoadingFeeds) {
                this.setData({
                    isLoadingFeeds: true
                });
                this.pushMoreFeeds();
            }
        } else {
            this.setData({
                isLoadingFeeds: false
            });
        }
    },
    handleScrollToLower: function handleScrollToLower() {
        this.pushMoreFeeds();
    },
    handleTapSwitchTabType: function handleTapSwitchTabType(e) {
        var switchTab = e.detail;
        this.setData({
            switchTab: switchTab,
            noteList: []
        });
        this.refreshNotes(this.data.userInfo.id);
    },
    handleTapSettings: function handleTapSettings() {
        if (!this.data.isLogin) {
            return;
        }
        (0, _track.trackClick)({
            label: "settings",
            context: {},
            timeStamp: new Date().getTime()
        });
        (0, _path.navigateTo)("SettingsPage");
    }
});