var _track = require("../../../utils/track");

var _path = require("../../../utils/path");

var _api = require("../../../utils/api");

var _api2 = _interopRequireDefault(_api);

var _enum = require("../../../utils/enum");

var _parseUrl = require("../../../utils/parse-url");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

Page({
    mixins: [],
    data: {
        link: "",
        shareInfo: {}
    },
    bindmessage: function bindmessage(e) {
        var _this = this;
        var detail = e.detail;
        detail = detail || {};
        var sourceDatas = detail.data || [];
        sourceDatas.forEach(function(item) {
            var methodName = item.methodName, data = item.data;
            if (methodName === "setShareInfo") {
                data = data || {};
                var _data = data, title = _data.title, linkurl = _data.linkurl, image = _data.image, imageurl = _data.imageurl;
                var shareInfo = _this.data.shareInfo;
                if (title) {
                    shareInfo.title = title;
                }
                if (image && image.indexOf("logo-normal") === -1) {
                    shareInfo.imageUrl = image;
                }
                if (imageurl && imageurl.indexOf("logo-normal") === -1) {
                    shareInfo.imageUrl = imageurl;
                }
                if (linkurl) {
                    shareInfo.link = encodeURIComponent(decodeURIComponent(linkurl));
                }
                _this.setData({
                    shareInfo: shareInfo
                });
            }
        });
    },
    onShareAppMessage: function onShareAppMessage() {
        var path = (0, _path.makeSharePath)("HomePage");
        try {
            var route = this.route, options = this.options;
            var queryArr = [];
            var dangerKeys = [ "sid", "scene" ];
            for (var key in options) {
                if ({}.hasOwnProperty.call(options, key)) {
                    var item = options[key];
                    if (key === "link" && item) {
                        // 如果有webview告知的path 就替换
                        if (this.data.shareInfo.link) {
                            item = this.data.shareInfo.link;
                        }
                        item = decodeURIComponent(item);
                        item = (0, _parseUrl.cleanSpecialKeys)(item);
                        item = encodeURIComponent(item);
                    }
                    if (dangerKeys.indexOf(key) === -1) {
                        queryArr.push(key + "=" + item);
                    }
                }
            }
            path = route + "?" + queryArr.join("&");
        } catch (e) {
            console.log(e);
            // eslint-disable-line no-console
                }
        (0, _track.trackNormalData)({
            action: "share",
            property: path
        });
        var result = {
            path: path
        };
        if (this.data.shareInfo.title) {
            result.title = this.data.shareInfo.title;
        }
        if (this.data.shareInfo.imageUrl) {
            result.imageUrl = this.data.shareInfo.imageUrl;
        }
        return result;
    },
    onLoad: function onLoad() {
        var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
        console.log("!!!!!!!!!!!!!!!webview", options);
        // eslint-disable-line no-console
                var LAUNCH_APP_KEY = "canLaunchAppFromMp";
        var targetLink = options.link || "";
        var canShare = options.canShare;
        var parsedLink = (0, _parseUrl.getAbsoluteLink)({
            link: decodeURIComponent(targetLink)
        });
        var needSharePathRegex = [ /\/vendor\/[\S]{24}\/events\/[\S]{24}/, /\/vendor\/[\S]{24}/, /\/goods\/[\S]{24}/, /\/event\/page\/sale_event\/[\S]{24}/, /\/store\/cs\/index/, /\/page\//, /\/activity\//, /\/tag\/custom/, /picasso_pages/ ];
        var userInfo = wx.getStorageSync(_enum.STORAGE_KEY.USER_INFO) || {};
        var _wx$getStorageSync = wx.getStorageSync(_enum.STORAGE_KEY.USER_INFO), sid = _wx$getStorageSync.sid;
        parsedLink = (0, _parseUrl.cleanSpecialKeys)(parsedLink);
        parsedLink = (0, _parseUrl.changeQuery)({
            link: parsedLink,
            type: "set",
            key: "_mpversion",
            value: new Date().getTime()
        });
        if (userInfo.authorization) {
            parsedLink = (0, _parseUrl.changeQuery)({
                link: parsedLink,
                type: "set",
                key: "authorization",
                value: userInfo.authorization
            });
        }
        parsedLink = (0, _parseUrl.changeQuery)({
            link: parsedLink,
            type: "set",
            key: "sid",
            value: sid
        });
        // 是否需要分享
                var needShare = false;
        if (parsedLink.indexOf("noShare=yes") > -1) {
            needShare = false;
        }
        if (canShare || parsedLink.indexOf("canShare") > -1) {
            needShare = true;
        }
        needSharePathRegex.some(function(check) {
            if (check.test(parsedLink)) {
                needShare = true;
                return true;
            }
        });
        if (!needShare && wx.canIUse("hideShareMenu")) {
            wx.hideShareMenu();
        }
        (0, _track.trackPageview)();
        (0, _track.trackNormalData)({
            action: "webview_pv",
            label: parsedLink
        });
        var openid = userInfo.openid;
        var canLaunchApp = _api2.default.$instance.globalData.canLaunchApp;
        // 是否能唤起app
                if (canLaunchApp) {
            parsedLink = (0, _parseUrl.changeQuery)({
                link: parsedLink,
                type: "set",
                key: LAUNCH_APP_KEY,
                value: true
            });
        }
        if (openid) {
            parsedLink = (0, _parseUrl.changeQuery)({
                link: parsedLink,
                type: "set",
                key: "openid",
                value: openid
            });
        }
        parsedLink = (0, _parseUrl.changeQuery)({
            link: parsedLink,
            type: "set",
            key: "isMiniProgram",
            value: "true"
        });
        this.setData({
            link: parsedLink
        });
    },
    // 左上角返回
    onUnload: function onUnload() {
        (0, _track.trackNormalData)({
            action: "page_unload"
        });
    }
});