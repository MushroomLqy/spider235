// pages/secondary/search/index.js
Page({data: {}})