// pages/secondary/verify/index.js
Page({data: {}})