// pages/secondary/mine/setting.js
Page({data: {}})