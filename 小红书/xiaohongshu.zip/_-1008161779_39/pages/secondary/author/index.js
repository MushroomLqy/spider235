// pages/secondary/author/index.js
Page({data: {}})