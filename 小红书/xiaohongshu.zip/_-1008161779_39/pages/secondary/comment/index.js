// pages/secondary/comment/index.js
Page({data: {}})