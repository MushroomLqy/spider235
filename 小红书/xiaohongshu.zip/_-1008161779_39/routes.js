var Entry = "pages/";

var MainRoot = Entry + "main/";

var OldMainRoot = "main/";

var CommonRoot = Entry + "common/";

var SecondaryRoot = Entry + "secondary/";

var OldCommunityRoot = "community/";

var OldSearchRoot = "search/";

var RouteMap = {
    HomePage: MainRoot + "home/index",
    StoreHomePage: MainRoot + "store/index",
    UserCenterPage: MainRoot + "mine/index",
    Webview: MainRoot + "webview/index",
    JumpPage: MainRoot + "jump/page",
    OldWebview: OldMainRoot + "webview/index",
    OldJumpPage: OldMainRoot + "jump/page",
    OldLoginIndex: OldMainRoot + "login-page/index",
    OldMemberIndex: OldMainRoot + "member/index",
    OldShareGoods: OldMainRoot + "share-goods/index",
    NoteDetail: MainRoot + "note/index",
    VideoNoteDetail: MainRoot + "video-note/index",
    ShareGoods: MainRoot + "share-goods/index",
    OldSearchResult: OldSearchRoot + "result/index",
    JumpToApp: CommonRoot + "jump-to-app/index",
    NotFound: CommonRoot + "not-found/index",
    ErrorPage: CommonRoot + "error/index",
    LoginIndex: CommonRoot + "login/index",
    MobileLogin: CommonRoot + "login/mobile-login",
    LoginTerms: CommonRoot + "login/terms",
    LoginPrivacy: CommonRoot + "login/privacy",
    ContactPage: CommonRoot + "contact/index",
    Feedback: CommonRoot + "feedback/index",
    PrivacyPolicy: CommonRoot + "privacy-policy/index",
    SearchIndex: SecondaryRoot + "search/index",
    AuthorPage: SecondaryRoot + "author/index",
    NoteCommentDetail: SecondaryRoot + "comment/index",
    VerPage: SecondaryRoot + "verify/index",
    SettingsPage: SecondaryRoot + "mine/setting",
    OldNote: OldCommunityRoot + "discovery/note",
    OldVideoNote: OldCommunityRoot + "discovery/video-note",
    OldFeedNote: OldCommunityRoot + "note/index",
    OldAuthorPage: OldCommunityRoot + "author/index"
};

var NoNavigationBarRoutes = [];

var getRoute = function getRoute(key) {
    return RouteMap[key];
};

var getCategory = function getCategory() {
    var path = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
    var category = "";
    for (var key in RouteMap) {
        if (Object.prototype.hasOwnProperty.call(RouteMap, key)) {
            var checkPath = RouteMap[key];
            if (path === checkPath) {
                category = key;
                break;
            }
        }
    }
    return category;
};

var getCategoryByPath = function getCategoryByPath() {
    var path = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
    var category = "";
    for (var key in RouteMap) {
        if (Object.prototype.hasOwnProperty.call(RouteMap, key)) {
            var checkPath = RouteMap[key];
            if (path.indexOf(checkPath) > -1) {
                category = key;
                break;
            }
        }
    }
    return category;
};

var isSwitchTab = function isSwitchTab(category) {
    return [ "HomePage", "StoreHomePage", "UserCenterPage" ].indexOf(category) > -1;
};

var getCategoryByoldRoute = function getCategoryByoldRoute() {
    var oldRoute = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
    var map = {
        HomePage: {
            oldRoute: [ "main/home/page" ]
        },
        AuthorPage: {
            oldRoute: [ "community/author/index" ]
        },
        Webview: {
            oldRoute: [ "main/webview/index" ]
        },
        LoginIndex: {
            oldRoute: [ "main/login-page/index" ]
        },
        JumpToApp: {
            oldRoute: [ "main/jump-to-app/index" ]
        },
        NoteDetail: {
            oldRoute: [ "community/discovery/note", "community/discovery/video-note", "community/note/index" ]
        },
        FOLLOWINGS: {
            oldRoute: [ "community/author/followings" ]
        },
        FOLLOWERS: {
            oldRoute: [ "community/author/followers" ]
        }
    };
    var result = {};
    // 先很粗糙的查询是否只是在老路径前加上了pages
        var tryRoute = "pages/" + oldRoute;
    var tryCategory = getCategory(tryRoute);
    if (tryCategory) {
        result.category = tryCategory;
        result.isSwitchTab = isSwitchTab(tryCategory);
        return result;
    }
    Object.keys(map).some(function(key) {
        var checkItem = map[key];
        if (checkItem.oldRoute.indexOf(oldRoute) > -1) {
            result = {
                category: key,
                isSwitchTab: isSwitchTab(key)
            };
            return true;
        }
    });
    return result;
};

var GetPages = function GetPages(root) {
    var isSubpackage = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
    var pages = [];
    for (var key in RouteMap) {
        if (Object.prototype.hasOwnProperty.call(RouteMap, key)) {
            var path = RouteMap[key];
            if (path && path.indexOf(root) === 0) {
                var formatPath = isSubpackage ? path.replace(root, "") : path;
                pages.push(formatPath);
            }
        }
    }
    return pages;
};

module.exports = {
    getRoute: getRoute,
    isSwitchTab: isSwitchTab,
    MainRoot: MainRoot,
    OldMainRoot: OldMainRoot,
    CommonRoot: CommonRoot,
    SecondaryRoot: SecondaryRoot,
    OldCommunityRoot: OldCommunityRoot,
    RouteMap: RouteMap,
    getCategory: getCategory,
    getCategoryByPath: getCategoryByPath,
    GetPages: GetPages,
    NoNavigationBarRoutes: NoNavigationBarRoutes,
    getCategoryByoldRoute: getCategoryByoldRoute,
    OldSearchRoot: OldSearchRoot
};