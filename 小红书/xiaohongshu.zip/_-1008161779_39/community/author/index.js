// community/author/index.js
Page({data: {}})