// community/discovery/note.js
Page({data: {}})