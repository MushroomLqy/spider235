// community/note/index.js
Page({data: {}})