var _regenerator = require("./karin_npm/babel-runtime/regenerator/index.js");

var _regenerator2 = _interopRequireDefault(_regenerator);

require("./libs/@xhs/eaglet-mp/index");

require("./libs/mixin");

var _http = require("./http.config");

var _routes = require("./routes");

var _http2 = require("./utils/http");

var _user = require("./utils/user");

var _user2 = _interopRequireDefault(_user);

var _track = require("./utils/track");

var _path = require("./utils/path");

var _api = require("./utils/api");

var _api2 = _interopRequireDefault(_api);

var _abTest = require("./utils/ab-test");

var _abTest2 = _interopRequireDefault(_abTest);

var _enum = require("./utils/enum");

var _page = require("./utils/page");

var _string = require("./utils/string");

var _verify = require("./utils/verify");

var _verify2 = _interopRequireDefault(_verify);

var _usageTime = require("./utils/usageTime");

var _usageTime2 = _interopRequireDefault(_usageTime);

var _user3 = require("./services/user");

var _mp = require("./libs/@xhs/protobuf-mp-chakra-tracker/mp.js");

var mpTracker = _interopRequireWildcard(_mp);

var _verify3 = require("./services/verify");

function _interopRequireWildcard(obj) {
    if (obj && obj.__esModule) {
        return obj;
    } else {
        var newObj = {};
        if (obj != null) {
            for (var key in obj) {
                if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key];
            }
        }
        newObj.default = obj;
        return newObj;
    }
}

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

function _asyncToGenerator(fn) {
    return function() {
        var gen = fn.apply(this, arguments);
        return new Promise(function(resolve, reject) {
            function step(key, arg) {
                try {
                    var info = gen[key](arg);
                    var value = info.value;
                } catch (error) {
                    reject(error);
                    return;
                }
                if (info.done) {
                    resolve(value);
                } else {
                    return Promise.resolve(value).then(function(value) {
                        step("next", value);
                    }, function(err) {
                        step("throw", err);
                    });
                }
            }
            return step("next");
        });
    };
}

wx.$eaglet.init({
    tracker: mpTracker
});

var SMSdk = require("./libs/fp");

var debug = false;

var LAUNCH_TRACK_APM_ACTION = "app_launch_data";

(0, _http2.configure)({
    baseURL: debug ? _http.config.BASE_URL.development : _http.config.BASE_URL.production,
    apiList: _http.config.API_LIST
});

SMSdk.initConf({
    organization: "eR46sBuqF0fdw7KWFLYa",
    // 传入 organization，不要传入 accessKey
    channel: "miniProgram"
});

function canLaunchApp(scene) {
    var isNowCanLaunch = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
    // 当小程序从 App 分享消息卡片（场景值1036）打开时，该状态置为 true。
    // 当小程序从以下场景打开时，保持上一次打开小程序时打开 App 能力的状态：
    //    从其他小程序返回小程序（场景值1038）时（基础库 2.2.4 及以上版本支持）
    //    小程序从聊天顶部场景（场景值1089）中的「最近使用」内打开时
    //    长按小程序右上角菜单唤出最近使用历史（场景值1090）打开时
        if (isNowCanLaunch && [ _enum.HISTORY_SCENE, _enum.OTHER_MP_BACK_SCENE, _enum.MAIN_CHAT_SCENE ].includes(scene)) {
        return true;
    }
    if (scene !== _enum.SHARE_MEESAGE_SCENE && scene !== _enum.MAIN_CHAT_SCENE && scene !== _enum.HISTORY_SCENE) {
        return false;
    } else {
        if (scene === _enum.SHARE_MEESAGE_SCENE) {
            return true;
        }
    }
    return false;
}

// 检测小程序版本,并触发更新提示
function updateProgram() {
    _api2.default.getSystemInfo({
        success: function success(res) {
            // eslint-disable-line
            var canUseSDKVersion = "1.9.91";
            var currentSDKVersion = res.SDKVersion;
            if ((0, _string.compareVersion)(currentSDKVersion, canUseSDKVersion) >= 0) {
                var updateManager = wx.getUpdateManager();
                updateManager.onCheckForUpdate(function(res) {
                    // eslint-disable-line
                    // 请求完新版本信息的回调
                    if (res.hasUpdate) {
                        updateManager.onUpdateReady(function() {
                            // eslint-disable-line
                            wx.showModal({
                                title: "更新提示",
                                content: "新版本已经准备好，是否重启应用？",
                                success: function success(res) {
                                    if (res.confirm) {
                                        // 新的版本已经下载好，调用 applyUpdate 应用新版本并重启
                                        updateManager.applyUpdate();
                                    }
                                }
                            });
                        });
                        updateManager.onUpdateFailed(function() {
                            // eslint-disable-line
                            // 新版本下载失败
                            wx.showToast({
                                title: "新版本下载失败",
                                icon: "none",
                                duration: 2e3
                            });
                        });
                    }
                });
            }
        }
    });
}

// eslint-disable-next-line
App({
    globalData: {
        promise: new Promise(function(resolve) {
            if (!_abTest2.default.checkReady()) {
                _abTest2.default.AddQueue(resolve);
            } else {
                resolve();
            }
        }),
        canLaunchApp: false,
        launchOps: null,
        scene: null,
        navigateToLoginPageCount: 0,
        navigateToLoginPageTime: null,
        isIPhoneX: false,
        isLongScreen: false,
        isIOS: true,
        systemInfo: {},
        SMSdk: SMSdk,
        referrerInfo: {},
        noteFeedLaunched: false,
        noteCommentLaunched: false
    },
    $eagletAppMeta: {
        artifactName: "mewtwo",
        artifactVersion: function artifactVersion() {
            return "1.0.1";
        }
    },
    $eagletGetUserInfo: function $eagletGetUserInfo() {
        return new Promise(function(resolve) {
            var result = _user2.default.getEagletUserInfo();
            resolve(result);
        });
    },
    onPageNotFound: function onPageNotFound() {
        var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
        var path = options.path, query = options.query;
        var goToPageFunc = function goToPageFunc() {
            (0, _path.redirectTo)("NotFound");
        };
        (0, _track.trackApm)({
            action: "page_not_found",
            property: path
        });
        var copyQuery = JSON.parse(JSON.stringify(query));
        var tryCategory = (0, _routes.getCategoryByoldRoute)(path);
        if (tryCategory.category) {
            var method = tryCategory.isSwitchTab ? _path.switchTab : _path.redirectTo;
            var targetQuery = tryCategory.isSwitchTab ? undefined : copyQuery;
            goToPageFunc = function goToPageFunc() {
                method(tryCategory.category, targetQuery);
            };
        } else {
            (0, _track.trackApm)({
                action: "page_not_found_failure",
                property: path
            });
        }
        setTimeout(function() {
            goToPageFunc();
        }, 400);
    },
    initRequest: function initRequest() {
        _http2.interceptors.response.use(function() {
            var data = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            return data;
        });
        _http2.interceptors.request.use(function(config) {
            var sid = _user2.default.getSid();
            var deviceId = "";
            try {
                deviceId = SMSdk.getDeviceId();
                config.header = config.header || {};
                config.header["Device-Fingerprint"] = deviceId;
            } catch (err) {
                console.error(err);
                // eslint-disable-line
                        }
            // if (sid && (config.params || config.method === 'GET')) {
            //   config.params = config.params || {}
            //   config.params.sid = sid
            // }
                        var isNoSid = false;
            _http.NO_SID_API_LIST.some(function(api) {
                if (config.url.indexOf(api) > -1) {
                    isNoSid = true;
                    return true;
                }
            });
            if (isNoSid) {
                return config;
            }
            if (sid && !config.url.includes("/fe_api/burdock") && sid !== "undefined") {
                if (config.params) {
                    config.params.sid = sid;
                } else {
                    config.params = {};
                    config.params.sid = sid;
                }
            }
            return config;
        });
    },
    initNewbie: function initNewbie() {
        var _this = this;
        return _asyncToGenerator(/* */ _regenerator2.default.mark(function _callee() {
            var newbieFlag;
            return _regenerator2.default.wrap(function _callee$(_context) {
                while (1) {
                    switch (_context.prev = _context.next) {
                      case 0:
                        // 从storage中拿新人引导的数据,没有则新增一个
                        newbieFlag = _api2.default.getStorageSync(_enum.STORAGE_KEY.NEWBIE_FLAG);
                        if (newbieFlag) {
                            _context.next = 4;
                            break;
                        }
                        _context.next = 4;
                        return _api2.default.setStorage({
                            key: _enum.STORAGE_KEY.NEWBIE_FLAG,
                            data: {
                                hintTapAvatarMine: true,
                                hintTapAvatarNote: true
                            }
                        });

                      case 4:
                      case "end":
                        return _context.stop();
                    }
                }
            }, _callee, _this);
        }))();
    },
    initGlobalData: function initGlobalData() {
        var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
        var _ref = options || {}, scene = _ref.scene, path = _ref.path;
        this.globalData.launchOps = options;
        this.globalData.scene = scene;
        // 是否可以launchApp
                this.globalData.canLaunchApp = canLaunchApp(scene, this.globalData.canLaunchApp);
        // 检测iphoneX
                var that = this;
        _api2.default.getSystemInfo({
            success: function success(res) {
                // eslint-disable-line
                that.globalData.isLongScreen = (0, _page.getScreenRatio)();
                that.globalData.isIPhoneX = res.model.search("iPhone X") >= 0;
                that.globalData.isIOS = res.system.search("iOS") >= 0;
                that.globalData.systemInfo = res;
                (0, _track.trackApm)({
                    action: "init_globaldata_end",
                    sourceRoute: path,
                    sourceScene: scene
                });
            }
        });
    },
    // 用于是否显示添加到小程序提醒的判断
    initAddMpCache: function initAddMpCache() {
        var canShowFullAddMp = _api2.default.getStorageSync(_enum.STORAGE_KEY.CAN_SHOW_FULL_ADD_MP);
        // eslint-disable-line
                if (typeof canShowFullAddMp !== "boolean") {
            _api2.default.setStorage({
                key: _enum.STORAGE_KEY.CAN_SHOW_FULL_ADD_MP,
                data: true
            });
        }
    },
    checkWeixinCaptcha: function checkWeixinCaptcha() {
        var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
        // 解决各类回调的兼容问题
                if (!this.captchaTicketExpire) {
            this.captchaTicketExpire = {};
        }
        if (options.scene === 1038 && options.referrerInfo.appId === "wx5a3a7366fd07e119") {
            var result = options.referrerInfo.extraData || {};
            if (result.ret === 0) {
                (0, _track.trackNormalData)({
                    action: "verify_success",
                    label: "tencent"
                });
                var params = {
                    status: 1,
                    ticket: result.ticket,
                    randStr: result.randstr,
                    callFrom: "wxMiniProgram"
                };
                (0, _verify3.sendVertifyCode)(params).then(function(data) {
                    (0, _track.trackNormalData)({
                        action: "verify_api_success",
                        label: "tencent"
                    });
                    if (data && data.passed) {
                        (0, _track.trackNormalData)({
                            action: "verify_api_passed",
                            label: "tencent"
                        });
                        _verify2.default.relaunchBeforeVerifyPage();
                    } else {
                        (0, _track.trackNormalData)({
                            action: "verify_api_fail",
                            label: "tencent"
                        });
                    }
                }).catch(function() {
                    (0, _track.trackNormalData)({
                        action: "send_verify_error",
                        label: "tencent"
                    });
                    (0, _path.redirectTo)("ErrorPage");
                });
            } else {
                (0, _track.trackNormalData)({
                    action: "verify_fail",
                    label: "tencent",
                    property: result.ret
                });
            }
        }
    },
    onLaunch: function onLaunch() {
        var _this2 = this;
        var ops = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
        return _asyncToGenerator(/* */ _regenerator2.default.mark(function _callee2() {
            var _ref2, path, scene, userInfo, openid, isNewWxmpUser, trueOpenid, result, _result;
            return _regenerator2.default.wrap(function _callee2$(_context2) {
                while (1) {
                    switch (_context2.prev = _context2.next) {
                      case 0:
                        _ref2 = ops || {}, path = _ref2.path, scene = _ref2.scene;
                        (0, _track.trackApm)({
                            action: "miniprogram_launch",
                            sourceRoute: path,
                            sourceScene: scene
                        });
                        userInfo = _user2.default.getUserInfo();
                        openid = userInfo.openid, isNewWxmpUser = userInfo.isNewWxmpUser;
                        trueOpenid = openid;
                        _verify2.default.setAvailableVerifyPage();
                        // 新用户如果获取不到ab信息 降级处理
                                                setTimeout(function() {
                            try {
                                if (!_abTest2.default.checkReady()) {
                                    _abTest2.default.init({
                                        openid: trueOpenid
                                    });
                                    (0, _track.trackApm)({
                                        action: LAUNCH_TRACK_APM_ACTION,
                                        property: "get_abtest_timeout"
                                    });
                                }
                            } catch (error) {
                                console.log(error);
                                // eslint-disable-line
                                                        }
                        }, 5e3);
                        try {
                            // 手动设置 app meta 信息
                            wx.$eaglet.app.setConfig({
                                $eagletAppMeta: _this2.$eagletAppMeta,
                                $eagletGetUserInfo: _this2.$eagletGetUserInfo
                            });
                            // 初始化 mobile app user 等基础信息
                                                        wx.$eaglet.app.initApp(ops);
                        } catch (error) {
                            (0, _track.trackApm)({
                                action: "init_new_track_error",
                                sourceRoute: path,
                                sourceScene: scene
                            });
                        }
                        result = _user2.default.getEagletUserInfo();
                        wx.$eaglet.resetABInfo(result);
                        // 执行一些初始化方法
                                                _this2.initGlobalData(ops);
                        _this2.initRequest();
                        (0, _track.trackApm)({
                            action: "init_request_end",
                            sourceRoute: path,
                            sourceScene: scene
                        });
                        _this2.initNewbie();
                        (0, _track.trackApm)({
                            action: "init_new_bie_end",
                            sourceRoute: path,
                            sourceScene: scene
                        });
                        _this2.initAddMpCache();
                        _context2.prev = 16;
                        _context2.next = 19;
                        return _user2.default.loginWithCode({
                            noAutoGoToLogin: true
                        });

                      case 19:
                        (0, _track.trackApm)({
                            action: LAUNCH_TRACK_APM_ACTION,
                            property: "auto_login_success"
                        });
                        trueOpenid = _user2.default.getUserInfo().openid;
                        if (isNewWxmpUser) {
                            userInfo.isNewWxmpUser = false;
                            _user2.default.setUserInfo(userInfo);
                        }
                        _context2.next = 28;
                        break;

                      case 24:
                        _context2.prev = 24;
                        _context2.t0 = _context2["catch"](16);
                        // 失效了
                                                (0, _track.trackApm)({
                            action: LAUNCH_TRACK_APM_ACTION,
                            property: "login_with_code_fail",
                            label: _context2.t0
                        });
                        console.error("loginWithCode", _context2.t0);

                        // eslint-disable-line
                                              case 28:
                        _context2.prev = 28;
                        _context2.next = 31;
                        return _abTest2.default.init({
                            openid: trueOpenid
                        });

                      case 31:
                        (0, _track.trackApm)({
                            action: LAUNCH_TRACK_APM_ACTION,
                            property: "get_ab_data_success"
                        });
                        _result = _user2.default.getEagletUserInfo();
                        wx.$eaglet.resetABInfo(_result);
                        _context2.next = 40;
                        break;

                      case 36:
                        _context2.prev = 36;
                        _context2.t1 = _context2["catch"](28);
                        // 失效了
                                                (0, _track.trackApm)({
                            action: LAUNCH_TRACK_APM_ACTION,
                            property: "get_ab_data_fail",
                            label: _context2.t1
                        });
                        console.error("abtest init", _context2.t1);

                        // eslint-disable-line
                                              case 40:
                        (0, _track.trackApm)({
                            action: "miniprogram_launch_end",
                            sourceRoute: path,
                            sourceScene: scene
                        });
                        // 检测小程序版本,并触发更新提示
                                                updateProgram();

                      case 42:
                      case "end":
                        return _context2.stop();
                    }
                }
            }, _callee2, _this2, [ [ 16, 24 ], [ 28, 36 ] ]);
        }))();
    },
    onError: function onError(msg) {
        (0, _track.trackError)(msg);
    },
    onShow: function onShow(ops) {
        this.globalData.launchOps = ops;
        var _ref3 = ops || {}, scene = _ref3.scene;
        this.globalData.scene = scene;
        // can launch xhs app ?
                this.globalData.canLaunchApp = canLaunchApp(scene, this.globalData.canLaunchApp);
        // 设置防爬开关缓存字段
                try {
            _verify2.default.setAvailableVerifyPage();
            wx.$eaglet.app.startFlushInterval();
        } catch (e) {
            console.log(e);
            // eslint-disable-line
                }
        (0, _track.trackApm)({
            action: "miniprogram_show",
            sourceRoute: ops.path,
            sourceScene: ops.scene
        });
        _usageTime2.default.start();
        this.checkWeixinCaptcha(ops);
    },
    onHide: function onHide() {
        wx.$eaglet.app.stopFlushInterval();
        (0, _track.trackApm)({
            action: "miniprogram_hide"
        });
        if (_usageTime2.default.isHealthy()) {
            (0, _track.trackApm)({
                action: "session",
                label: "timespent",
                property: _usageTime2.default.getUsageTime()
            });
        }
        _usageTime2.default.close();
    }
});