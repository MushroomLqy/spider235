Object.defineProperty(exports, "__esModule", {
    value: true
});

var _API_LIST;

function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}

//  development: 'https://t48.b.xiaohongshu.com',
var config = exports.config = {
    BASE_URL: {
        development: "https://www.xiaohongshu.com",
        production: "https://www.xiaohongshu.com"
    },
    API_LIST: (_API_LIST = {
        // 通过code判断用户是否曾经登录过小程序,登录过则直接登录返回登录态,未登录则需用户授权信息再登录
        LOGIN: "/fe_api/burdock/weixin/v2/login/code",
        LOGOUT: "/weixin_mp/thor/logout",
        // 发送授权得到的用户微信信息判断是否注册过APP,注册过直接登录APP,未注册过可传参数强制注册
        USER_INFO: "/fe_api/burdock/weixin/v2/login/update_weixin_userinfo",
        CHECK_AUTH_VALIDATE: "/fe_api/burdock/weixin/v2/login/authorization_validate",
        MOBILE_LOGIN: "/fe_api/burdock/weixin/v2/login/mobile",
        GET_PHONE_ZONES: "https://pages.xiaohongshu.com/data/sns/mp_phone_number_zone",
        // 通过授权得到的用户微信绑定手机号登录app或者直接手机号&验证码登录app
        WX_MOBILE_LOGIN: "/fe_api/burdock/weixin/v2/login/weixin_mobile",
        VFC_CODE: "/fe_api/burdock/weixin/v2/login/identifyCode/send",
        // 社区首页
        COMMUNITY_HOMEFEEDS: "/fe_api/burdock/weixin/v2/homefeed/personalNotes",
        COMMUNITY_CATEGORIES: "/fe_api/burdock/weixin/v2/homefeed/categories",
        // 收藏
        FOLLOW: "/fe_api/burdock/weixin/v2/user/${userId}/follow",
        UNFOLLOW: "/fe_api/burdock/weixin/v2/user/${userId}/unfollow",
        AUTHORFAVED: "/fe_api/burdock/weixin/v2/user/${userId}/collectedNotes",
        // 个人页
        SNS_USER_INFO: "/fe_api/burdock/weixin/v2/user/${userId}",
        SNS_NOTE_USER: "/fe_api/burdock/weixin/v2/user/${userId}/notes",
        SNS_OTHER_NOTE_USER: "/fe_api/burdock/weixin/v2/user/${userId}/other/notes",
        SNS_ATTA_NOTE: "/fe_api/burdock/weixin/v2/user/${userId}/atUserNotes",
        SNS_USER_FOLLOWINGS: "/fe_api/burdock/weixin/v2/user/${id}/followings",
        SNS_USER_FOLLOWERS: "/fe_api/burdock/weixin/v2/user/${id}/followers",
        // 个人资料页
        MINE_INFO_DETAIL: "/wx_mp_api/sns/v1/user/me",
        EDIT_MINE_INFO: "/wx_mp_api/sns/v1/user/info",
        // 笔详页
        VIDEO_NOTE_FEED: "/fe_api/burdock/baidu/v1/notes/${noteId}/videofeed",
        LIKE_NOTE: "/fe_api/burdock/weixin/v2/note/${noteId}/like",
        COLLECT_NOTE: "/fe_api/burdock/weixin/v2/note/${noteId}/collect",
        NOTE_COMMENT_DETAIL: "/fe_api/burdock/weixin/v2/notes/${noteId}/comments",
        SEND_COMMENT: "/fe_api/burdock/weixin/v2/comment",
        SINGLE_FEED: "/fe_api/burdock/weixin/v2/note/${noteId}/single_feed",
        IMAGE_STICKERS: "/fe_api/burdock/weixin/v2/note/${id}/image_stickers",
        RELATED_NOTES: "/fe_api/burdock/weixin/v2/note/${noteId}/related",
        RELATED_NOTE_FEEDS: "/fe_api/burdock/weixin/v2/note/${noteId}/feed",
        NOTE_TAGS: "/fe_api/burdock/weixin/v2/note/${noteId}/tags",
        // 笔记搜索
        NOTES_HOT_SEARCH: "/fe_api/burdock/weixin/v2/search/trending",
        SEARCH_NOTES_FROM_KEYWORD: "/fe_api/burdock/weixin/v2/search/notes",
        SEARCH_NOTES_AUTO_COMPLETE: "/fe_api/burdock/weixin/v2/search/recommend",
        SEARCH_NOTES_PLACEHOLDER: "/wx_mp_api/sns/v1/search/placeholder",
        SEARCH_TOPIC: "/fe_api/burdock/weixin/v2/search/one_box",
        // 搜索
        GOODS_HOT_SEARCH: "/api/sns/v1/wx_mp/search/trending",
        SEARCH_FROM_KEYWORD: "/api/store/ps/products",
        SEARCH_AUTO_COMPLETE: "/api/sns/v1/wx_mp/search/recommend",
        // 商城推荐
        HOMEFEEDS: "/api/store/hf/feeds",
        SEARCH_USERS_FROM_KEYWORD: "/fe_api/burdock/weixin/v2/search/users",
        CHECK_IF_NEW_USER: "/api/store/mc/type/v1",
        // 商城首页
        FULISHE_CATEGORIES_BANNERS: "/api/store/hf/banners/v4",
        // 商城首页领券
        CLAIM_COUPON: "/api/store/cs/promo/acqn/${couponId}",
        // 意見反饋
        FEEDBACK: "/api/v2/feedback/send",
        CI_TOKEN: "/api/cs/v2/images/tokens",
        // 小程序隐私政策
        PRIVACY_POLICY: "https://pages.xiaohongshu.com/data/sns/wx_mp_privacy_policy",
        // CI_TOKEN: 'https://picasso.xiaohongshu.com/admin_api/v1/image_upload_info',
        // 商品详情页
        PRODUCT_DETAIL: "/api/store/pd/${id}",
        PRODUCT_DETAIL_STATIC: "/api/store/pd/${id}/static",
        GOODS_DETAIL_RELATED_NOTES: "/api/store/hf/items/${id}/notes",
        // 支付
        PAY: "/api/1/order/pay",
        PAY_CHECKOUT: "/api/store/oc/checkout",
        // 订单详情
        ORDER_DOWN: "/api/group_order",
        ORDER_ADDRESS: "/api/store/mc/addresses/v1",
        // ok
        ORDER_INFO: "/api/order/detail_package/${id}",
        // ok
        ORDER_LOGISTICS: "/api/store/logistics/tracking_records/${packageId}",
        // 地址
        ZONE_LEVEL: "/api/zone",
        ADDRESS: "/api/store/mc/addresses/v1",
        SAVE_ADDRESS: "/api/store/mc/address/v1",
        EDIT_ADDRESS: "/api/store/mc/address/v1/${aid}",
        DEFAULT_ADDRESS: "/api/store/mc/address/default/v1/${id}",
        ID_CARD_VERIFY: "/api/id_number/verify",
        // 确认订单
        CHECKOUT: "/api/store/oc/checkout",
        CREATE_ORDER: "/api/group_order",
        ORDER_LIST: "/api/store/oc/orders/v1",
        CREATE_ORDER_FROM_ITEM: "/group_order/instant_buy",
        // 支付
        PAYMENT: "/api/1/order/pay",
        PAYMENT_STATUS: "/api/1/order/infopay",
        // 消息通知
        MSG_SEND: "/api/sns/v1/wx_mp/template/send",
        // 打点
        TRACKING: "https://t.xiaohongshu.com/api/collect",
        // 测试打点
        TRACKING_TEST: "https://spltest.xiaohongshu.com/api/collect",
        // 兴趣页
        INTEREST_TAGS: "/api/sns/v1/wx_mp/user/tag_recommend",
        // 获取qr的path
        QR_LINK: "/wx_mp_api/sns/v1/qrcode_route_url",
        // 获取小程序广告qr的path
        ADS_QR_LINK: "https://pages.xiaohongshu.com/data/sns/mp_ads_qr_code_link",
        // system
        AB_TEST: "/fe_api/burdock/v2/experiment/mp/flag",
        COLLECT_FORM_ID: "/wx_mp_api/sns/v1/user/record_form",
        // activity 捏脸
        ACTIVITY_PINCH_GET_LAST_ITEM: "/api/sns/v1/wx_mp/pinch_face/latest",
        ACTIVITY_PINCH_ITEM_INFO: "/api/sns/v1/wx_mp/pinch_face/item/${itemId}",
        ACTIVITY_PINCH_UPDATE_ITEM: "/api/sns/v1/wx_mp/pinch_face/pinch_item/${itemId}",
        ACTIVITY_PINCH_CREATE_ITEM: "/api/sns/v1/wx_mp/pinch_face/item",
        ACTIVITY_PINCH_ACQUIRE_ITEM: "/api/sns/v1/wx_mp/pinch_face/acquire_pinch/${itemId}",
        ACTIVITY_PINCH_PART_LIST: "/api/sns/v1/wx_mp/pinch_face/part_list",
        ACTIVITY_PINCH_UPDATE_WEIXIN_INFO: "/api/sns/v1/wx_mp/pinch_face/update_user_info",
        ACTIVITY_PINCH_QR_CODE: "/api/sns/v1/wx_mp/pinch_face/gen_qrcode_url",
        ACTIVITY_PINCH_DEFAULT_INFO: "/api/sns/v1/wx_mp/pinch_face/get_default_face",
        ACTIVITY_BANNER_ENTRY: "https://pages.xiaohongshu.com/data/sns/lucky_packet",
        ACTIVITY_BANNER_INFO: "https://pages.xiaohongshu.com/data/sns/mp_activity_banner",
        // 微信通用接口
        ACTIVITY_QR_CODE: "/api/sns/v1/wx_mp/activity/gen_qrcode_url",
        ACTIVITY_UPDATE_SESSION_KEY: "/api/sns/v1/wx_mp/activity/update_session_key",
        ACTIVITY_UPDATE_WEIXIN_INFO: "/api/sns/v1/wx_mp/activity/update_user_info",
        // video-packet
        VIDEO_PACKET_OPEN: "/wx_mp_api/sns/v1/cny2019/video_packet",
        VIDEO_PACKET_CHECK_RED_PACKET: "/wx_mp_api/sns/v1/cny2019/${noteId}/check_red_packet",
        // hey活动
        ACTIVITY_HEY: "/fe_api/burdock/v1/hey/${id}",
        ACTIVITY_HEY_INVITE_VIEWER: "/fe_api/burdock/v1/hey/invite",
        // brand-video-packet
        BRAND_PACKET_OPEN: "https://www.xiaohongshu.com/wx_mp_api/sns/v1/cny2019/brand_packet",
        BRAND_PACKET_PREPARE: "https://www.xiaohongshu.com/wx_mp_api/sns/v1/cny2019/brand_packet/prepare",
        BRAND_PACKET_FOLLOW: "https://www.xiaohongshu.com/wx_mp_api/sns/v1/cny2019/brand_packet/follow",
        INDEX_ACTIVITY_SWITCH: "https://pages.xiaohongshu.com/data/sns/mp_activity_switch",
        NOTE_DETAIL_ACTIVITY_SWITCH: "https://pages.xiaohongshu.com/data/sns/mp_note_detail_switch",
        // 体验会员
        REVIEW_MEMBER_INVITATION: "/api/store/mc/invitation/${invitationId}",
        JOIN_MEMBER_INVITATION: "/api/store/mc/join_invitation/${invitationId}",
        MEMBER_GOODS_IDS: "https://pages.xiaohongshu.com/data/fantasy/member_treasure_share/items",
        // 黑卡会员
        MEMBER_ORDER_CHECKOUT: "/api/store/mc/checkout",
        MEMBER_ORDER_CREATE: "/api/store/mc/orders",
        MEMBER_INFO: "/api/store/mc/landing",
        MEMBER_EVENT_POPUPS: "/api/store/mc/bullets",
        GOODS_SHARE: "/fe_api/sns/v1/wx_store/goods_share_info",
        // 滑块验证码
        VERTIFICATION_CODE: "/fe_api/burdock/weixin/v2/shield/captchaV2",
        // 直播分享
        LIVE: "/fe_api/burdock/v2/activity/live/${roomId}/info"
    }, _defineProperty(_API_LIST, "PRODUCT_DETAIL", "/api/store/experience_center/product/${productId}/detail"), 
    _defineProperty(_API_LIST, "PRODUCT_APPLY", "/api/store/experience_center/product/${productId}/user"), 
    _defineProperty(_API_LIST, "PRODUCT_APPLICANTS", "/api/store/experience_center/product/${productId}/applicants"), 
    _defineProperty(_API_LIST, "PRODUCT_NOTES", "/api/store/experience_center/product/${productId}/notes"), 
    _defineProperty(_API_LIST, "SINGER_INFO", "https://pages.xiaohongshu.com/data/sns/mp_singer_albums_v2"), 
    _defineProperty(_API_LIST, "SONGS_INFO", "https://pages.xiaohongshu.com/data/sns/mp_singer_songs"), 
    _defineProperty(_API_LIST, "SONGS_RECOMMEND", "https://pages.xiaohongshu.com/data/sns/mp_singer_songs"), 
    _defineProperty(_API_LIST, "GER_MP_QRCODE_URL", "/wx_mp_api/sns/v1/qrcode_image_url"), 
    _defineProperty(_API_LIST, "GET_BRAND_LOTTERY_INFO", "/api/store/nb/lottery/info"), 
    _defineProperty(_API_LIST, "GET_ACTIVITY_BANNER", "/fe_api/burdock/weixin/v2/banner"), 
    _defineProperty(_API_LIST, "RECORD_PLATFORM_SOURCE", "/fe_api/burdock/weixin/v2/device/record"), 
    _defineProperty(_API_LIST, "INIT_GEETEST", "/fe_api/burdock/weixin/v2/shield/registerGee"), 
    _defineProperty(_API_LIST, "GET_SHARE_CODE", "/fe_api/burdock/weixin/v2/share/code"), 
    _API_LIST)
};

var NO_SID_API_LIST = exports.NO_SID_API_LIST = [ config.API_LIST.LOGIN, config.API_LIST.LOGOUT, config.API_LIST.MLOGIN, config.API_LIST.MOBILE_LOGIN, config.API_LIST.WX_MOBILE_LOGIN, config.API_LIST.TRACKING, config.API_LIST.TRACKING_TEST ];